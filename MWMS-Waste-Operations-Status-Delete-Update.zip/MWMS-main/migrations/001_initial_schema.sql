-- ==========================================================
-- Municipal Waste Management System (MWMS) - Database Schema
-- Version: 1.0.0
-- Dialect: PostgreSQL 14+
-- ==========================================================

-- Enable UUID extension if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Waste Collection Zones (Five Initial Municipal Zones)
CREATE TABLE IF NOT EXISTS zones (
    id VARCHAR(50) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    coverage_area VARCHAR(255),
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. System Users and Roles
CREATE TYPE user_role_enum AS ENUM (
    'admin',
    'finance_officer',
    'cashier',
    'collection_manager',
    'field_collector'
);

CREATE TABLE IF NOT EXISTS app_users (
    id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role user_role_enum NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    department VARCHAR(100),
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Fee Configuration
CREATE TYPE property_type_enum AS ENUM ('residential', 'commercial');
CREATE TYPE fee_status_enum AS ENUM ('draft', 'pending_approval', 'approved', 'superseded');

CREATE TABLE IF NOT EXISTS fee_rates (
    id VARCHAR(50) PRIMARY KEY,
    property_type property_type_enum NOT NULL,
    monthly_fee NUMERIC(10, 2) NOT NULL CHECK (monthly_fee >= 0),
    currency VARCHAR(3) DEFAULT 'USD',
    effective_date DATE NOT NULL,
    status fee_status_enum DEFAULT 'draft',
    proposed_by VARCHAR(50) REFERENCES app_users(id),
    approved_by VARCHAR(50) REFERENCES app_users(id),
    approved_at TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Property Registry
CREATE TYPE service_status_enum AS ENUM ('active', 'suspended', 'inactive');

CREATE TABLE IF NOT EXISTS properties (
    id VARCHAR(50) PRIMARY KEY,
    property_number VARCHAR(50) UNIQUE NOT NULL,
    owner_name VARCHAR(150) NOT NULL,
    occupant_name VARCHAR(150),
    phone VARCHAR(30) NOT NULL,
    address TEXT NOT NULL,
    zone_id VARCHAR(50) NOT NULL REFERENCES zones(id) ON UPDATE CASCADE,
    property_type property_type_enum NOT NULL DEFAULT 'residential',
    service_status service_status_enum NOT NULL DEFAULT 'active',
    notes TEXT,
    registered_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_properties_zone ON properties(zone_id);
CREATE INDEX idx_properties_type ON properties(property_type);

-- 5. Monthly Billing and Invoices
CREATE TYPE invoice_status_enum AS ENUM ('unpaid', 'partially_paid', 'paid', 'overdue');

CREATE TABLE IF NOT EXISTS invoices (
    id VARCHAR(50) PRIMARY KEY,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    property_id VARCHAR(50) NOT NULL REFERENCES properties(id) ON DELETE RESTRICT,
    billing_month VARCHAR(7) NOT NULL, -- Format: YYYY-MM
    rate_applied NUMERIC(10, 2) NOT NULL CHECK (rate_applied >= 0),
    amount_due NUMERIC(10, 2) NOT NULL CHECK (amount_due >= 0),
    amount_paid NUMERIC(10, 2) DEFAULT 0.00 CHECK (amount_paid >= 0),
    balance_due NUMERIC(10, 2) NOT NULL CHECK (balance_due >= 0),
    status invoice_status_enum DEFAULT 'unpaid',
    due_date DATE NOT NULL,
    created_by VARCHAR(50) REFERENCES app_users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    -- CRITICAL INTEGRITY RULE: PREVENT DUPLICATE BILLS FOR SAME PROPERTY & MONTH
    CONSTRAINT uq_property_billing_month UNIQUE (property_id, billing_month)
);

CREATE INDEX idx_invoices_month ON invoices(billing_month);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_invoices_property ON invoices(property_id);

-- 6. Payments and Receipts Ledger
CREATE TYPE payment_method_enum AS ENUM ('cash', 'digital');
CREATE TYPE verification_status_enum AS ENUM ('pending', 'confirmed', 'rejected');

CREATE TABLE IF NOT EXISTS payments (
    id VARCHAR(50) PRIMARY KEY,
    receipt_number VARCHAR(50) UNIQUE NOT NULL,
    invoice_id VARCHAR(50) NOT NULL REFERENCES invoices(id) ON DELETE RESTRICT,
    property_id VARCHAR(50) NOT NULL REFERENCES properties(id) ON DELETE RESTRICT,
    amount NUMERIC(10, 2) NOT NULL CHECK (amount > 0),
    payment_method payment_method_enum NOT NULL,
    digital_reference VARCHAR(100),
    digital_provider VARCHAR(50),
    verification_status verification_status_enum NOT NULL DEFAULT 'pending',
    recorded_by VARCHAR(50) NOT NULL REFERENCES app_users(id),
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    verified_by VARCHAR(50) REFERENCES app_users(id),
    verified_at TIMESTAMP WITH TIME ZONE,
    verification_notes TEXT,
    is_reversed BOOLEAN DEFAULT FALSE,
    reversal_reason TEXT,
    reversed_at TIMESTAMP WITH TIME ZONE,
    reversed_by VARCHAR(50) REFERENCES app_users(id),
    -- CRITICAL INTEGRITY RULE: DUPLICATE DIGITAL REFERENCES MUST BE REJECTED
    CONSTRAINT uq_digital_reference UNIQUE (digital_reference)
);

CREATE INDEX idx_payments_invoice ON payments(invoice_id);
CREATE INDEX idx_payments_verification ON payments(verification_status);

-- 7. Waste Collection Operations (Trucks, Routes, Schedules)
CREATE TABLE IF NOT EXISTS trucks (
    id VARCHAR(50) PRIMARY KEY,
    plate_number VARCHAR(30) UNIQUE NOT NULL,
    model VARCHAR(100) NOT NULL,
    capacity_tons NUMERIC(4, 1) NOT NULL,
    status VARCHAR(20) DEFAULT 'active', -- active, maintenance, deputed
    assigned_zone_id VARCHAR(50) REFERENCES zones(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS routes (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    zone_id VARCHAR(50) NOT NULL REFERENCES zones(id),
    start_point VARCHAR(150),
    end_point VARCHAR(150),
    estimated_stops INT DEFAULT 50,
    frequency VARCHAR(50) DEFAULT 'Twice weekly'
);

CREATE TABLE IF NOT EXISTS collection_schedules (
    id VARCHAR(50) PRIMARY KEY,
    date DATE NOT NULL,
    zone_id VARCHAR(50) NOT NULL REFERENCES zones(id),
    route_id VARCHAR(50) NOT NULL REFERENCES routes(id),
    truck_id VARCHAR(50) NOT NULL REFERENCES trucks(id),
    collector_id VARCHAR(50) NOT NULL REFERENCES app_users(id),
    status VARCHAR(20) DEFAULT 'scheduled', -- scheduled, in_progress, completed, delayed
    stops_completed INT DEFAULT 0,
    total_stops INT DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS collection_records (
    id VARCHAR(50) PRIMARY KEY,
    schedule_id VARCHAR(50) NOT NULL REFERENCES collection_schedules(id) ON DELETE CASCADE,
    property_id VARCHAR(50) NOT NULL REFERENCES properties(id),
    status VARCHAR(20) NOT NULL, -- collected, missed
    missed_reason TEXT,
    notes TEXT,
    waste_weight_kg NUMERIC(6, 2),
    recorded_by VARCHAR(50) NOT NULL REFERENCES app_users(id),
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. Customer Complaints
CREATE TABLE IF NOT EXISTS complaints (
    id VARCHAR(50) PRIMARY KEY,
    complaint_number VARCHAR(50) UNIQUE NOT NULL,
    property_id VARCHAR(50) NOT NULL REFERENCES properties(id),
    complainant_name VARCHAR(150) NOT NULL,
    phone VARCHAR(30),
    category VARCHAR(50) NOT NULL, -- missed_collection, damaged_bin, illegal_dumping, staff_conduct, billing_query, other
    description TEXT NOT NULL,
    priority VARCHAR(20) DEFAULT 'medium', -- low, medium, high, urgent
    status VARCHAR(20) DEFAULT 'open', -- open, in_progress, resolved
    resolution_notes TEXT,
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolved_by VARCHAR(50) REFERENCES app_users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. Complete Audit Trail
CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(50) PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    user_id VARCHAR(50) NOT NULL,
    user_name VARCHAR(100) NOT NULL,
    user_role VARCHAR(30) NOT NULL,
    action VARCHAR(50) NOT NULL, -- RATE_CHANGE, INVOICE_GENERATE, PAYMENT_CONFIRM, PAYMENT_REVERSE, etc.
    entity_type VARCHAR(50) NOT NULL,
    entity_id VARCHAR(50) NOT NULL,
    details TEXT NOT NULL
);

CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp DESC);
CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
