import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { db } from './server/db.js';
import { authMiddleware, clearAuthCookie, issueToken, login, setAuthCookie } from './server/auth.js';
import { initializeMySqlStore, loadSnapshot, persistSnapshot } from './server/mysql-store.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// ==========================================
// 1. Authentication (individual, cookie-backed sessions)
// ==========================================
app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (typeof username !== 'string' || typeof password !== 'string' || !username || !password) {
      return res.status(400).json({ error: 'Username and password are required.' });
    }
    const user = await login(username, password);
    if (!user) {
      db.logAudit('LOGIN_FAILED', 'AUTH', username.slice(0, 80), 'Failed sign-in attempt');
      return res.status(401).json({ error: 'Invalid username or password, or account is suspended.' });
    }
    setAuthCookie(res, issueToken(user));
    db.logAudit('LOGIN_SUCCESS', 'AUTH', user.id, `Signed in: ${user.fullName}`);
    return res.json({ user });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'Sign-in failed. Check server configuration.' });
  }
});
app.post('/api/auth/logout', (_req, res) => { clearAuthCookie(res); res.json({ success: true }); });

// Every application API below this point requires a valid, unexpired session.
app.use('/api', (req, res, next) => {
  if (req.path === '/auth/login' || req.path === '/auth/logout') return next();
  return authMiddleware(req, res, next);
});
app.get('/api/auth/users', (_req, res) => {
  res.json({ users: db.getUsers().map(({ ...user }) => user) });
});
app.get('/api/auth/current', (_req, res) => { res.json({ user: db.getCurrentUser() }); });

app.get('/api/users', (_req, res) => {
  res.json({ users: db.getUsers() });
});

app.post('/api/users', (req, res) => {
  try {
    const currentUser = db.getCurrentUser();
    if (currentUser.role !== 'admin') {
      return res.status(403).json({ error: 'Permission denied: Only System Administrators can register new personnel and assign roles.' });
    }
    const { username, fullName, role, email, phone, department, status, assignedDistrictId, assignedZoneId } = req.body;
    if (!username || !fullName || !role || !email) {
      return res.status(400).json({ error: 'Username, Full Name, Email, and Role are mandatory.' });
    }
    const newUser = db.addUser({
      username,
      fullName,
      role,
      email,
      phone,
      department: department || 'Municipal Administration',
      status: status || 'active',
      assignedDistrictId,
      assignedZoneId,
    });
    res.status(201).json({ user: newUser });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.patch('/api/users/:id', (req, res) => {
  try {
    const currentUser = db.getCurrentUser();
    if (currentUser.role !== 'admin') {
      return res.status(403).json({ error: 'Permission denied: Only System Administrators can modify staff credentials or change roles.' });
    }
    const updated = db.updateUser(req.params.id, req.body);
    res.json({ user: updated });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/api/users/:id', (req, res) => {
  try {
    const currentUser = db.getCurrentUser();
    if (currentUser.role !== 'admin') {
      return res.status(403).json({ error: 'Permission denied: Only System Administrators can remove user accounts.' });
    }
    db.deleteUser(req.params.id);
    res.json({ success: true, message: 'User account removed.' });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/roles', (_req, res) => {
  res.json({
    roles: db.getRoleDefinitions(),
    permissions: db.getPermissionsMatrix(),
  });
});

// ==========================================
// 2. Dashboard KPIs & Aggregates
// ==========================================
app.get('/api/dashboard/stats', (_req, res) => {
  try {
    const stats = db.getDashboardStats();
    res.json(stats);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ==========================================
// 3. Mogadishu Districts & Sub-Districts Management
// ==========================================
app.get('/api/districts', (_req, res) => {
  res.json({ districts: db.getDistricts() });
});

app.post('/api/districts', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Administrator can register new Mogadishu districts.' });
    }
    const { code, name, somaliName, description } = req.body;
    if (!code || !name) {
      return res.status(400).json({ error: 'District code and name are required.' });
    }
    const dist = db.addDistrict({
      code,
      name,
      somaliName: somaliName || name,
      description: description || '',
    });
    res.status(201).json({ district: dist });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/api/properties/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin') return res.status(403).json({ error: 'Only an administrator can permanently delete properties.' });
    db.deleteProperty(req.params.id);
    res.json({ success: true });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});

app.get('/api/sub-districts', (req, res) => {
  const { districtId } = req.query;
  res.json({ subDistricts: db.getSubDistricts(districtId as string) });
});

app.post('/api/sub-districts', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') {
      return res.status(403).json({ error: 'Unauthorized to add sub-districts (waax).' });
    }
    const { districtId, code, name, somaliName, description } = req.body;
    if (!districtId || !code || !name) {
      return res.status(400).json({ error: 'District ID, code, and name are required.' });
    }
    const sd = db.addSubDistrict({
      districtId,
      code,
      name,
      somaliName: somaliName || name,
      description: description || '',
    });
    res.status(201).json({ subDistrict: sd });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/api/sub-districts/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Unauthorized to delete sub-districts (waax).' });
    db.deleteSubDistrict(req.params.id);
    res.json({ success: true });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});

app.get('/api/zones', (req, res) => {
  const { districtId, subDistrictId } = req.query;
  const zones = db.getZones(districtId as string, subDistrictId as string);
  res.json({ zones });
});

app.post('/api/zones', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') {
      return res.status(403).json({ error: 'Unauthorized to create collection zones.' });
    }
    const { code, name, districtId, subDistrictId, description, coverageArea, active } = req.body;
    if (!code || !name || !districtId || !subDistrictId) {
      return res.status(400).json({ error: 'Zone code, name, district, and sub-district are required.' });
    }
    const newZone = db.addZone({
      code,
      name,
      districtId,
      subDistrictId,
      description: description || '',
      coverageArea: coverageArea || 'Standard Urban Sector',
      active: active !== undefined ? active : true,
    });
    res.status(201).json({ zone: newZone });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/api/zones/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Unauthorized to delete collection zones.' });
    db.deleteZone(req.params.id);
    res.json({ success: true });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});

// ==========================================
// 4. Property Registry
// ==========================================
app.get('/api/properties', (req, res) => {
  try {
    let properties = db.getProperties();
    const { districtId, subDistrictId, zoneId, type, status, search } = req.query;

    if (districtId && districtId !== 'all') {
      properties = properties.filter((p) => p.districtId === districtId);
    }
    if (subDistrictId && subDistrictId !== 'all') {
      properties = properties.filter((p) => p.subDistrictId === subDistrictId);
    }
    if (zoneId && zoneId !== 'all') {
      properties = properties.filter((p) => p.zoneId === zoneId);
    }
    if (type && type !== 'all') {
      properties = properties.filter((p) => p.propertyType === type);
    }
    if (status && status !== 'all') {
      properties = properties.filter((p) => p.serviceStatus === status);
    }
    if (search && typeof search === 'string') {
      const q = search.toLowerCase();
      properties = properties.filter(
        (p) =>
          p.propertyNumber.toLowerCase().includes(q) ||
          p.ownerName.toLowerCase().includes(q) ||
          p.address.toLowerCase().includes(q) ||
          p.phone.toLowerCase().includes(q) ||
          (p.districtName && p.districtName.toLowerCase().includes(q)) ||
          (p.subDistrictName && p.subDistrictName.toLowerCase().includes(q))
      );
    }

    res.json({ properties });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/properties', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role === 'field_collector') {
      return res.status(403).json({ error: 'Field collectors do not have permission to register properties.' });
    }

    const {
      propertyNumber,
      ownerName,
      occupantName,
      phone,
      address,
      districtId,
      subDistrictId,
      zoneId,
      propertyType,
      serviceStatus,
      notes,
    } = req.body;

    if (!propertyNumber || !ownerName || !phone || !address || !zoneId || !propertyType) {
      return res.status(400).json({ error: 'Please provide all required property details.' });
    }

    const newProp = db.addProperty({
      propertyNumber,
      ownerName,
      occupantName: occupantName || ownerName,
      phone,
      address,
      districtId: districtId || '',
      subDistrictId: subDistrictId || '',
      zoneId,
      propertyType,
      serviceStatus: serviceStatus || 'active',
      notes,
    });

    res.status(201).json({ property: newProp });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.patch('/api/properties/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role === 'field_collector' || user.role === 'cashier') {
      return res.status(403).json({ error: 'Insufficient permissions to modify property records.' });
    }
    const updated = db.updateProperty(req.params.id, req.body);
    res.json({ property: updated });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// ==========================================
// 5. Fee Configuration
// ==========================================
app.get('/api/fees', (_req, res) => {
  res.json({ feeRates: db.getFeeRates() });
});

app.post('/api/fees/propose', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'finance_officer') {
      return res.status(403).json({ error: 'Permission denied: Only System Administrator or Finance Officer can propose fee rates.' });
    }
    const { propertyType, monthlyFee, effectiveDate, notes } = req.body;
    if (!propertyType || monthlyFee === undefined || !effectiveDate) {
      return res.status(400).json({ error: 'Missing required fee proposal attributes.' });
    }
    const proposed = db.proposeFeeRate({
      propertyType,
      monthlyFee: Number(monthlyFee),
      effectiveDate,
      notes,
    });
    res.status(201).json({ feeRate: proposed });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/fees/:id/approve', (req, res) => {
  try {
    const approved = db.approveFeeRate(req.params.id);
    res.json({ feeRate: approved });
  } catch (error: any) {
    res.status(403).json({ error: error.message });
  }
});

// ==========================================
// 6. Billing and Invoices
// ==========================================
app.get('/api/invoices', (req, res) => {
  let invoices = db.getInvoices();
  const { month, zoneId, districtId, status, search } = req.query;

  if (month && month !== 'all') {
    invoices = invoices.filter((i) => i.billingMonth === month);
  }
  if (districtId && districtId !== 'all') {
    invoices = invoices.filter((i) => i.districtId === districtId);
  }
  if (zoneId && zoneId !== 'all') {
    invoices = invoices.filter((i) => i.zoneId === zoneId);
  }
  if (status && status !== 'all') {
    invoices = invoices.filter((i) => i.status === status);
  }
  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    invoices = invoices.filter(
      (i) =>
        i.invoiceNumber.toLowerCase().includes(q) ||
        i.propertyNumber.toLowerCase().includes(q) ||
        i.ownerName.toLowerCase().includes(q) ||
        (i.districtName && i.districtName.toLowerCase().includes(q))
    );
  }

  // Sort newest first
  invoices.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ invoices });
});

app.post('/api/invoices/generate-batch', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'finance_officer') {
      return res.status(403).json({ error: 'Permission denied: Only System Administrator or Finance Officer can run batch billing.' });
    }
    const { billingMonth, zoneId, districtId } = req.body;
    if (!billingMonth) {
      return res.status(400).json({ error: 'Billing month is required (YYYY-MM).' });
    }
    const result = db.generateMonthlyBilling(billingMonth, zoneId, districtId);
    res.json({
      success: true,
      generatedCount: result.generated.length,
      skippedDuplicates: result.skippedDuplicates,
      invoices: result.generated,
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/invoices/single', (req, res) => {
  try {
    const { propertyId, billingMonth } = req.body;
    if (!propertyId || !billingMonth) {
      return res.status(400).json({ error: 'Property ID and billing month required.' });
    }
    const invoice = db.createSingleInvoice({ propertyId, billingMonth });
    res.status(201).json({ invoice });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// ==========================================
// 7. Payments & Receipts Ledger
// ==========================================
app.get('/api/payments', (req, res) => {
  let payments = db.getPayments();
  const { method, verificationStatus, search } = req.query;

  if (method && method !== 'all') {
    payments = payments.filter((p) => p.paymentMethod === method);
  }
  if (verificationStatus && verificationStatus !== 'all') {
    payments = payments.filter((p) => p.verificationStatus === verificationStatus);
  }
  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    payments = payments.filter(
      (p) =>
        p.receiptNumber.toLowerCase().includes(q) ||
        p.invoiceNumber.toLowerCase().includes(q) ||
        p.propertyNumber.toLowerCase().includes(q) ||
        p.ownerName.toLowerCase().includes(q) ||
        (p.digitalReference && p.digitalReference.toLowerCase().includes(q))
    );
  }

  // Sort newest first
  payments.sort((a, b) => new Date(b.recordedAt).getTime() - new Date(a.recordedAt).getTime());
  res.json({ payments });
});

app.post('/api/payments/record', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role === 'field_collector') {
      return res.status(403).json({ error: 'Permission denied: Sanitation field collectors are not authorized to collect or record payments.' });
    }
    const { invoiceId, amount, paymentMethod, digitalReference, digitalProvider, notes } = req.body;
    if (!invoiceId || amount === undefined || !paymentMethod) {
      return res.status(400).json({ error: 'Missing invoiceId, amount, or paymentMethod.' });
    }

    const result = db.recordPayment({
      invoiceId,
      amount: Number(amount),
      paymentMethod,
      digitalReference,
      digitalProvider,
      notes,
    });

    res.status(201).json(result);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/payments/:id/verify', (req, res) => {
  try {
    const { action, notes } = req.body; // action: 'approve' | 'reject'
    if (!action || !['approve', 'reject'].includes(action)) {
      return res.status(400).json({ error: "Action must be 'approve' or 'reject'." });
    }

    const result = db.verifyDigitalPayment(req.params.id, action, notes);
    res.json(result);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/payments/:id/reverse', (req, res) => {
  try {
    const { reason } = req.body;
    if (!reason || !reason.trim()) {
      return res.status(400).json({ error: 'Audit reversal reason is mandatory.' });
    }
    const result = db.reversePayment(req.params.id, reason);
    res.json(result);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// ==========================================
// 8. Waste Operations (Trucks, Routes, Dispatch, Field Logs, Complaints)
// ==========================================
app.get('/api/operations/all', (_req, res) => {
  res.json({
    trucks: db.getTrucks(),
    routes: db.getRoutes(),
    schedules: db.getSchedules(),
    records: db.getCollectionRecords(),
    complaints: db.getComplaints(),
  });
});

app.post('/api/operations/trucks', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') {
      return res.status(403).json({ error: 'Unauthorized to manage fleet trucks.' });
    }
    const truck = db.addTruck(req.body);
    res.status(201).json({ truck });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.patch('/api/operations/trucks/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Unauthorized to update fleet trucks.' });
    const truck = db.updateTruck(req.params.id, req.body);
    res.json({ truck });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});
app.delete('/api/operations/trucks/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Unauthorized to delete fleet trucks.' });
    db.deleteTruck(req.params.id); res.json({ success: true });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});

app.post('/api/operations/routes', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') {
      return res.status(403).json({ error: 'Unauthorized to create collection routes.' });
    }
    const route = db.addRoute(req.body);
    res.status(201).json({ route });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.patch('/api/operations/routes/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Unauthorized to update routes.' });
    const route = db.updateRoute(req.params.id, req.body); res.json({ route });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});
app.delete('/api/operations/routes/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Unauthorized to delete routes.' });
    db.deleteRoute(req.params.id); res.json({ success: true });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});
app.patch('/api/operations/schedules/:id/status', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Unauthorized to update schedules.' });
    const schedule = db.updateScheduleStatus(req.params.id, req.body.status); res.json({ schedule });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});
app.delete('/api/operations/schedules/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Unauthorized to delete schedules.' });
    db.deleteSchedule(req.params.id); res.json({ success: true });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});
app.patch('/api/operations/records/:id/status', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Unauthorized to update collection logs.' });
    const record = db.updateCollectionRecordStatus(req.params.id, req.body.status); res.json({ record });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});
app.delete('/api/operations/records/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Unauthorized to delete collection logs.' });
    db.deleteCollectionRecord(req.params.id); res.json({ success: true });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});

app.post('/api/operations/schedules', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') {
      return res.status(403).json({ error: 'Unauthorized to schedule collection dispatches.' });
    }
    const schedule = db.createSchedule(req.body);
    res.status(201).json({ schedule });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/operations/records', (req, res) => {
  try {
    const record = db.recordCollectionLog(req.body);
    res.status(201).json({ record });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/operations/complaints', (req, res) => {
  try {
    const complaint = db.addComplaint(req.body);
    res.status(201).json({ complaint });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.patch('/api/operations/complaints/:id/status', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Permission denied to update complaint status.' });
    const complaint = db.updateComplaintStatus(req.params.id, req.body.status); res.json({ complaint });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});
app.delete('/api/operations/complaints/:id', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') return res.status(403).json({ error: 'Permission denied to delete complaints.' });
    db.deleteComplaint(req.params.id); res.json({ success: true });
  } catch (error: any) { res.status(400).json({ error: error.message }); }
});

app.post('/api/operations/complaints/:id/resolve', (req, res) => {
  try {
    const user = db.getCurrentUser();
    if (user.role !== 'admin' && user.role !== 'collection_manager') {
      return res.status(403).json({ error: 'Permission denied: Only Collection Manager or System Administrator can resolve customer complaints.' });
    }
    const { resolutionNotes } = req.body;
    if (!resolutionNotes) {
      return res.status(400).json({ error: 'Resolution notes are required.' });
    }
    const complaint = db.resolveComplaint(req.params.id, resolutionNotes);
    res.json({ complaint });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// ==========================================
// 9. Audit Logs
// ==========================================
app.get('/api/audit-logs', (_req, res) => {
  res.json({ logs: db.getAuditLogs() });
});

// ==========================================
// 10. Automated Invariant Verification Tests
// ==========================================
app.get('/api/system/tests', (_req, res) => {
  const results = db.runFinancialRuleTests();
  res.json({
    suite: 'MWMS Financial & Operational Invariants Test Suite',
    executedAt: new Date().toISOString(),
    results,
    allPassed: results.every((r) => r.passed),
  });
});

// ==========================================
// Dev & Production Frontend Serving
// ==========================================
async function startServer() {
  await initializeMySqlStore();
  const savedSnapshot = await loadSnapshot();
  if (savedSnapshot) db.importSnapshot(savedSnapshot);
  else persistSnapshot(db.exportSnapshot());
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MWMS Server operational on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
});
