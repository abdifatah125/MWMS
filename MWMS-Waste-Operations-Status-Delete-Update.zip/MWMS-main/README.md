# Municipal Waste Management System (MWMS)

MWMS is a full-stack municipal web application designed for city governments and local sanitation authorities to administer waste collection operations, property registrations, monthly fee billing, cash and digital payments, printable official receipts, and audit governance.

## Key Modules & Features

1. **Dashboard**: Executive KPIs (Total properties, confirmed revenue, arrears, pending digital count & value, collection coverage %, and open complaints).
2. **Property Registry**: Maintains property records, unique property numbers (e.g., `PROP-Z1-001`), owner/occupant names, phone numbers, addresses, property categories (Residential vs Commercial), and service statuses (Active, Suspended, Inactive).
3. **5 Initial Collection Zones**:
   - Zone 1: Central Business & Civic District (`ZONE-01`)
   - Zone 2: North Riverside Borough (`ZONE-02`)
   - Zone 3: East Valley Heights (`ZONE-03`)
   - Zone 4: West Garden Suburbs (`ZONE-04`)
   - Zone 5: South Logistics & Commercial Park (`ZONE-05`)
4. **Approved Fee Configurations**:
   - **Residential Monthly Fee**: $6.00 per property per month (fixed by municipal ordinance).
   - **Commercial Monthly Fee**: Configurable by authorized administrator with formal Finance Officer approval controls.
5. **Monthly Billing Invoices**:
   - Batch and single invoice generation for cycles (e.g. `2026-10`, `2026-11`).
   - **Enforced Invariant**: Strict database and API prevention of duplicate bills for the same property and billing month.
   - Historical invoice rates preserved upon fee adjustments.
6. **Payments & Official Printable Receipts**:
   - **Cash Payments**: Recorded and confirmed immediately by cashiers, balance updated, unique receipt issued (`REC-2026-XXXX`).
   - **Digital Payments**: Requires unique transaction reference; duplicate references strictly rejected; transactions remain in `Pending` status until manually verified.
   - **Pending Revenue Exclusion**: Pending or rejected digital payments are segregated and excluded from confirmed municipal revenue totals.
   - **Overpayment Prevention**: Balance locking strictly prevents payments exceeding outstanding amounts.
   - **Audited Financial Reversals**: Confirmed transactions are corrected through audited reversals rather than silent deletion.
   - **Printable Vector Receipts**: Includes municipal seal, payer details, cashier stamp, and verification code.
7. **Waste Operations Logistics**:
   - Compactor truck fleet management (Plate numbers, capacity in tons, operational status).
   - Collection routes and stops management across the 5 zones.
   - Daily dispatch scheduling with assigned field collectors and trucks.
   - Field collection recording (marking completed vs missed collections with reasons and scale weight).
   - Citizen complaints registry with ticket assignment, priority levels, and resolution notes.
8. **Financial Reports & Cashier Reconciliation**:
   - Revenue breakdown by zone and method.
   - Arrears aging analysis (Current, 1–30 days, 31–60 days, 60+ days).
   - Cashier shift reconciliation ledger.
   - One-click export to CSV.
9. **Role-Based Access Control (RBAC)**:
   - System Administrator (`admin`)
   - Finance Officer (`finance_officer`)
   - Cashier (`cashier`)
   - Collection Manager (`collection_manager`)
   - Field Collector (`field_collector`)
   - Interactive role switcher in header for reviewing role permissions.
10. **Automated Test Suite**:
   - Executable from the UI and `/api/system/tests` to verify duplicate bill blocking, overpayment locks, reference uniqueness, pending revenue exclusion, and audited reversals.

## Local Development & Zero-Cost Architecture

In accordance with Section 10 of the MWMS requirements, the application is built to run entirely in local development mode without provisioning paid cloud services or incurring AWS charges.

- **Frontend**: React 19 + TypeScript + Tailwind CSS.
- **Backend**: Express + Node.js with Vite middleware.
- **Database**:
  - Out of the box: Self-contained transactional storage in `data/mwms_data.json`.
  - Production PostgreSQL: DDL migration provided in `migrations/001_initial_schema.sql`.
- **Environment**: Configure via `.env` using `.env.example` as a template.


## Property and zone deletion
- Administrators can delete properties from Property Registry. Permanent deletion is blocked when a property has invoices, payments, collection records, or complaints; set it to inactive instead.
- Administrators and collection managers can delete a Waax (sub-district) or collection zone only when it has no dependent records.
- Deletion actions require confirmation and are written to the audit log.
