import 'dotenv/config';
import { initializeMySqlStore, loadSnapshot, persistSnapshot, flushMySqlWrites } from '../server/mysql-store.js';
import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), 'data', 'mwms_data.json');
const local = JSON.parse(fs.readFileSync(file, 'utf8'));
await initializeMySqlStore();
const existing = await loadSnapshot();
if (existing) {
  console.error('MySQL already contains an MWMS snapshot. Refusing to overwrite it. Back up both stores and choose a deliberate migration strategy.');
  process.exitCode = 2;
} else {
  persistSnapshot(local);
  await flushMySqlWrites();
  console.log('Imported existing JSON data into MySQL table mwms_app_state (primary). Original JSON file was preserved.');
}
