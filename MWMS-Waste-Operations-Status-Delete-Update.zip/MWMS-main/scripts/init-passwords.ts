import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
import bcrypt from 'bcryptjs';
import { db } from '../server/db.js';
import { setPassword } from '../server/auth.js';

const rl = readline.createInterface({ input, output });
try {
  console.log('Set an individual password for each existing MWMS account. Passwords are never printed or stored in plain text.');
  for (const user of db.getUsers()) {
    const password = await rl.question(`${user.fullName} (@${user.username}) — enter initial password (min 12 chars): `);
    if (password.length < 12) throw new Error('Password must be at least 12 characters. Re-run the script to continue.');
    const confirmation = await rl.question('Confirm password: ');
    if (password !== confirmation) throw new Error('Passwords did not match. Re-run the script to continue.');
    setPassword(user.id, await bcrypt.hash(password, 12));
    console.log(`Password initialized for @${user.username}.`);
  }
  console.log('Password initialization complete. Keep data/auth_credentials.json private and backed up securely.');
} finally { rl.close(); }
