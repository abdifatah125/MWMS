import mysql from 'mysql2/promise';

let pool: mysql.Pool | null = null;
let ready = false;
let writeChain: Promise<unknown> = Promise.resolve();

export async function initializeMySqlStore() {
  const required = ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD'];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length) throw new Error(`Missing MySQL configuration: ${missing.join(', ')}. Configure .env before starting MWMS.`);
  pool = mysql.createPool({
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT || 3306),
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    waitForConnections: true,
    connectionLimit: 10,
    charset: 'utf8mb4',
    timezone: 'Z',
  });
  await pool.query(`CREATE TABLE IF NOT EXISTS mwms_app_state (
    state_key VARCHAR(64) PRIMARY KEY,
    payload JSON NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
  ready = true;
}

export async function loadSnapshot(): Promise<unknown | null> {
  if (!pool || !ready) return null;
  const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT payload FROM mwms_app_state WHERE state_key = ?', ['primary']);
  if (!rows.length) return null;
  const value = rows[0].payload;
  return typeof value === 'string' ? JSON.parse(value) : value;
}

export function persistSnapshot(payload: unknown) {
  if (!pool || !ready) return;
  const serialized = JSON.stringify(payload);
  writeChain = writeChain.then(async () => {
    await pool!.execute(
      'INSERT INTO mwms_app_state (state_key, payload) VALUES (?, ?) ON DUPLICATE KEY UPDATE payload = VALUES(payload)',
      ['primary', serialized],
    );
  }).catch(err => console.error('MySQL snapshot persistence failed:', err));
}

export async function flushMySqlWrites() { await writeChain; }
export async function closeMySqlStore() { if (pool) await pool.end(); pool = null; ready = false; }
