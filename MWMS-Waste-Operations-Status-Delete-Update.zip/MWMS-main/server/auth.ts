import type { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import fs from 'node:fs';
import path from 'node:path';
import bcrypt from 'bcryptjs';
import { db, requestUserContext } from './db.js';
import type { AppUser } from '../src/types/index.js';

const CREDENTIALS_FILE = path.resolve(process.cwd(), 'data', 'auth_credentials.json');
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.warn('SECURITY WARNING: Set JWT_SECRET to a random value of at least 32 characters in .env before using MWMS.');
}
const secret = JWT_SECRET || 'INSECURE-LOCAL-DEVELOPMENT-ONLY-CHANGE-ME-000000';
const TOKEN_TTL_SECONDS = 8 * 60 * 60;
type Credential = { userId: string; passwordHash: string };
function credentials(): Credential[] {
  try { return JSON.parse(fs.readFileSync(CREDENTIALS_FILE, 'utf8')) as Credential[]; }
  catch { return []; }
}
export function setPassword(userId: string, passwordHash: string) {
  const all = credentials();
  const next = all.filter(c => c.userId !== userId);
  next.push({ userId, passwordHash });
  fs.writeFileSync(CREDENTIALS_FILE, JSON.stringify(next, null, 2), { mode: 0o600 });
}
export async function login(username: string, password: string): Promise<AppUser | null> {
  const user = db.getUsers().find(u => u.username.toLowerCase() === username.trim().toLowerCase());
  if (!user || user.status === 'suspended') return null;
  const credential = credentials().find(c => c.userId === user.id);
  if (!credential || !(await bcrypt.compare(password, credential.passwordHash))) return null;
  return user;
}
export function issueToken(user: AppUser) {
  return jwt.sign({ sub: user.id, role: user.role }, secret, { expiresIn: TOKEN_TTL_SECONDS, issuer: 'mwms', audience: 'mwms-web' });
}
export function setAuthCookie(res: Response, token: string) {
  const secure = process.env.NODE_ENV === 'production';
  res.setHeader('Set-Cookie', `mwms_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${TOKEN_TTL_SECONDS}${secure ? '; Secure' : ''}`);
}
export function clearAuthCookie(res: Response) {
  res.setHeader('Set-Cookie', 'mwms_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
}
export function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const raw = req.headers.cookie?.split(';').map(v => v.trim()).find(v => v.startsWith('mwms_session='))?.slice('mwms_session='.length);
  if (!raw) return res.status(401).json({ error: 'Please sign in.' });
  try {
    const payload = jwt.verify(decodeURIComponent(raw), secret, { issuer: 'mwms', audience: 'mwms-web' }) as jwt.JwtPayload;
    const user = typeof payload.sub === 'string' ? db.getUserById(payload.sub) : undefined;
    if (!user || user.status === 'suspended') { clearAuthCookie(res); return res.status(401).json({ error: 'Session is no longer valid. Please sign in again.' }); }
    requestUserContext.run(user, () => next());
  } catch {
    clearAuthCookie(res);
    return res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
  }
}
