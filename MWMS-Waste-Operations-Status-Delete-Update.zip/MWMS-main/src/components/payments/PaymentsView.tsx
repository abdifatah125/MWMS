import React, { useState } from 'react';
import { Payment, Invoice, AppUser } from '../../types/index.js';
import {
  Receipt,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  XCircle,
  RotateCcw,
  Printer,
  ShieldAlert,
  AlertTriangle,
  X,
  CreditCard,
  Banknote,
  DollarSign,
  Lock,
} from 'lucide-react';

interface PaymentsViewProps {
  payments: Payment[];
  invoices: Invoice[];
  currentUser: AppUser | null;
  onRecordPayment: (payload: {
    invoiceId: string;
    amount: number;
    paymentMethod: 'cash' | 'digital';
    digitalReference?: string;
    digitalProvider?: string;
    notes?: string;
  }) => Promise<{ payment: Payment; invoice: Invoice }>;
  onVerifyPayment: (
    id: string,
    action: 'approve' | 'reject',
    notes?: string
  ) => Promise<{ payment: Payment; invoice: Invoice }>;
  onReversePayment: (
    id: string,
    reason: string
  ) => Promise<{ payment: Payment; invoice: Invoice }>;
  onOpenReceipt: (payment: Payment) => void;
  initialInvoiceForPayment?: Invoice | null;
  onClearInitialInvoice?: () => void;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  payments,
  invoices,
  currentUser,
  onRecordPayment,
  onVerifyPayment,
  onReversePayment,
  onOpenReceipt,
  initialInvoiceForPayment,
  onClearInitialInvoice,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'pending' | 'reversed'>('all');
  const [search, setSearch] = useState('');
  const [methodFilter, setMethodFilter] = useState('all');

  // Record payment modal
  const [isRecordModalOpen, setIsRecordModalOpen] = useState(!!initialInvoiceForPayment);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState(
    initialInvoiceForPayment?.id || (invoices.find((i) => i.balanceDue > 0)?.id || '')
  );
  const [payAmount, setPayAmount] = useState<number>(initialInvoiceForPayment?.balanceDue || 6.0);
  const [payMethod, setPayMethod] = useState<'cash' | 'digital'>('cash');
  const [digitalRef, setDigitalRef] = useState('');
  const [digitalProvider, setDigitalProvider] = useState('Municipal Bank Portal');
  const [payNotes, setPayNotes] = useState('');
  const [recordError, setRecordError] = useState('');
  const [recording, setRecording] = useState(false);

  // Digital verification modal
  const [verifyingPayment, setVerifyingPayment] = useState<Payment | null>(null);
  const [verifyNotes, setVerifyNotes] = useState('');
  const [verifyingAction, setVerifyingAction] = useState<'approve' | 'reject'>('approve');
  const [verifyingSubmitting, setVerifyingSubmitting] = useState(false);
  const [verifyError, setVerifyError] = useState('');

  // Reversal modal
  const [reversingPayment, setReversingPayment] = useState<Payment | null>(null);
  const [reversalReason, setReversalReason] = useState('');
  const [reversalError, setReversalError] = useState('');
  const [reversingSubmitting, setReversingSubmitting] = useState(false);

  // Active target invoice lookup for payment form
  const currentSelectedInvoice = invoices.find((i) => i.id === selectedInvoiceId);

  // Pending payments count
  const pendingPayments = payments.filter(
    (p) => p.verificationStatus === 'pending' && !p.isReversed
  );

  const canVerify = currentUser?.role === 'admin' || currentUser?.role === 'finance_officer';
  const canReverse = currentUser?.role === 'admin' || currentUser?.role === 'finance_officer';
  const canRecord = currentUser?.role === 'admin' || currentUser?.role === 'finance_officer' || currentUser?.role === 'cashier';

  // Filter payments
  const filtered = payments.filter((p) => {
    if (activeTab === 'pending' && (p.verificationStatus !== 'pending' || p.isReversed)) return false;
    if (activeTab === 'reversed' && !p.isReversed) return false;
    if (methodFilter !== 'all' && p.paymentMethod !== methodFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        p.receiptNumber.toLowerCase().includes(q) ||
        p.invoiceNumber.toLowerCase().includes(q) ||
        p.propertyNumber.toLowerCase().includes(q) ||
        p.ownerName.toLowerCase().includes(q) ||
        (p.digitalReference && p.digitalReference.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleOpenRecord = (inv?: Invoice) => {
    const target = inv || invoices.find((i) => i.balanceDue > 0);
    if (target) {
      setSelectedInvoiceId(target.id);
      setPayAmount(target.balanceDue);
    }
    setPayMethod('cash');
    setDigitalRef('');
    setRecordError('');
    setIsRecordModalOpen(true);
  };

  const handleSelectInvoice = (id: string) => {
    setSelectedInvoiceId(id);
    const inv = invoices.find((i) => i.id === id);
    if (inv) {
      setPayAmount(inv.balanceDue);
    }
  };

  const handleSubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setRecordError('');

    if (!selectedInvoiceId) {
      setRecordError('Please select a target invoice.');
      return;
    }

    if (currentSelectedInvoice && payAmount > currentSelectedInvoice.balanceDue) {
      setRecordError(
        `Overpayment prevented: Amount cannot exceed invoice balance ($${currentSelectedInvoice.balanceDue.toFixed(2)})`
      );
      return;
    }

    if (payMethod === 'digital' && !digitalRef.trim()) {
      setRecordError('Digital payments require a valid unique transaction reference code.');
      return;
    }

    setRecording(true);
    try {
      const result = await onRecordPayment({
        invoiceId: selectedInvoiceId,
        amount: Number(payAmount),
        paymentMethod: payMethod,
        digitalReference: payMethod === 'digital' ? digitalRef.trim() : undefined,
        digitalProvider: payMethod === 'digital' ? digitalProvider : undefined,
        notes: payNotes,
      });

      setIsRecordModalOpen(false);
      if (onClearInitialInvoice) onClearInitialInvoice();

      // If CASH: auto-open receipt!
      if (result.payment.verificationStatus === 'confirmed') {
        onOpenReceipt(result.payment);
      }
    } catch (err: any) {
      setRecordError(err.message || 'Payment recording failed');
    } finally {
      setRecording(false);
    }
  };

  const handleConfirmVerification = async () => {
    if (!verifyingPayment) return;
    setVerifyError('');
    setVerifyingSubmitting(true);
    try {
      const result = await onVerifyPayment(
        verifyingPayment.id,
        verifyingAction,
        verifyNotes
      );
      setVerifyingPayment(null);
      if (verifyingAction === 'approve') {
        onOpenReceipt(result.payment);
      }
    } catch (err: any) {
      setVerifyError(err.message || 'Verification failed');
    } finally {
      setVerifyingSubmitting(false);
    }
  };

  const handleExecuteReversal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reversingPayment) return;
    if (!reversalReason.trim()) {
      setReversalError('Municipal audit rules require a specific reversal justification.');
      return;
    }

    setReversalError('');
    setReversingSubmitting(true);
    try {
      await onReversePayment(reversingPayment.id, reversalReason.trim());
      setReversingPayment(null);
      setReversalReason('');
    } catch (err: any) {
      setReversalError(err.message || 'Reversal failed');
    } finally {
      setReversingSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Receipt className="w-5 h-5 text-emerald-700" />
            Payments & Official Receipts Ledger
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Record cash and digital entries, verify digital settlements, issue receipts, and track audited reversals
          </p>
        </div>

        {canRecord ? (
          <button
            onClick={() => handleOpenRecord()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            Record New Payment
          </button>
        ) : (
          <div
            title="Field sanitation collectors are restricted from cash counter intake"
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-100 text-slate-500 text-xs border border-slate-200 cursor-not-allowed self-start sm:self-auto"
          >
            <Lock className="w-3.5 h-3.5 text-slate-400" />
            <span>Payment Intake Restricted (Cashiers/Finance/Admin Only)</span>
          </div>
        )}
      </div>

      {!canVerify && (
        <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-lg text-xs text-blue-900 flex items-center gap-2">
          <Receipt className="w-4 h-4 text-blue-600 shrink-0" />
          <span>
            <strong>Role Separation (Subration):</strong> Logged in as <em>{currentUser?.fullName} ({currentUser?.role})</em>. You can record customer cash receipts. Digital transaction approval and audited reversals require a Treasury Finance Officer or System Administrator.
          </span>
        </div>
      )}

      {/* Tabs Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'all'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            All Transactions ({payments.length})
          </button>
          <button
            onClick={() => setActiveTab('pending')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeTab === 'pending'
                ? 'bg-amber-600 text-white'
                : 'text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Pending Verification ({pendingPayments.length})
          </button>
          <button
            onClick={() => setActiveTab('reversed')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'reversed'
                ? 'bg-rose-900 text-white'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Audited Reversals ({payments.filter((p) => p.isReversed).length})
          </button>
        </div>

        {/* Filter / Search */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Receipt, inv, ref, owner..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8 pr-2.5 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <select
            value={methodFilter}
            onChange={(e) => setMethodFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
          >
            <option value="all">All Methods</option>
            <option value="cash">Cash Only</option>
            <option value="digital">Digital Only</option>
          </select>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
              <tr>
                <th className="px-4 py-3">Receipt / ID</th>
                <th className="px-4 py-3">Invoice & Property</th>
                <th className="px-4 py-3">Payer / Owner</th>
                <th className="px-4 py-3">Method & Details</th>
                <th className="px-4 py-3 text-right">Amount (USD)</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3">Recorded By</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                    No transactions found in this view.
                  </td>
                </tr>
              ) : (
                filtered.map((pay) => (
                  <tr key={pay.id} className={pay.isReversed ? 'bg-rose-50/30' : 'hover:bg-slate-50/50'}>
                    <td className="px-4 py-3">
                      <div className="font-mono font-bold text-slate-900">{pay.receiptNumber}</div>
                      <div className="text-[10px] text-slate-400">
                        {new Date(pay.recordedAt).toLocaleString([], {
                          dateStyle: 'short',
                          timeStyle: 'short',
                        })}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-mono text-slate-900">{pay.invoiceNumber}</div>
                      <div className="text-[11px] font-mono text-slate-500">{pay.propertyNumber}</div>
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-900">
                      {pay.ownerName}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 font-medium capitalize text-slate-900">
                        {pay.paymentMethod === 'cash' ? (
                          <Banknote className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <CreditCard className="w-3.5 h-3.5 text-blue-600" />
                        )}
                        <span>{pay.paymentMethod}</span>
                      </div>
                      {pay.digitalReference && (
                        <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                          Ref: <span className="font-semibold text-slate-700">{pay.digitalReference}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-slate-900">
                      ${pay.amount.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {pay.isReversed ? (
                        <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-100 text-rose-800 border border-rose-300">
                          Reversed
                        </span>
                      ) : (
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                            pay.verificationStatus === 'confirmed'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : pay.verificationStatus === 'pending'
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-rose-50 text-rose-800 border-rose-200'
                          }`}
                        >
                          {pay.verificationStatus}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-slate-600 text-[11px]">
                      <div>{pay.recordedByName}</div>
                      {pay.verifiedByName && (
                        <div className="text-emerald-700 text-[10px]">
                          ✓ {pay.verifiedByName}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Printable Receipt button */}
                        {pay.verificationStatus === 'confirmed' && !pay.isReversed && (
                          <button
                            onClick={() => onOpenReceipt(pay)}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-[11px] transition-colors"
                            title="Print official municipal receipt"
                          >
                            <Printer className="w-3 h-3 text-emerald-700" />
                            Receipt
                          </button>
                        )}

                        {/* Verify button for pending digital */}
                        {pay.verificationStatus === 'pending' && !pay.isReversed && (
                          <button
                            onClick={() => {
                              setVerifyingPayment(pay);
                              setVerifyingAction('approve');
                              setVerifyNotes('');
                              setVerifyError('');
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-700 text-white font-semibold text-[11px] shadow-xs transition-colors"
                          >
                            <Clock className="w-3 h-3" />
                            Verify
                          </button>
                        )}

                        {/* Reverse button for confirmed payment */}
                        {pay.verificationStatus === 'confirmed' && !pay.isReversed && canReverse && (
                          <button
                            onClick={() => {
                              setReversingPayment(pay);
                              setReversalReason('');
                              setReversalError('');
                            }}
                            className="p-1 text-slate-400 hover:text-rose-700 hover:bg-rose-50 rounded"
                            title="Audited reversal"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Payment Modal */}
      {isRecordModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm">Record Municipal Fee Payment</h3>
              </div>
              <button
                onClick={() => {
                  setIsRecordModalOpen(false);
                  if (onClearInitialInvoice) onClearInitialInvoice();
                }}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitPayment} className="p-6 space-y-4 text-xs">
              {recordError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg">
                  {recordError}
                </div>
              )}

              {/* Target Invoice Selector */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Target Invoice (Outstanding Balance) *
                </label>
                <select
                  value={selectedInvoiceId}
                  onChange={(e) => handleSelectInvoice(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                >
                  <option value="">Select Invoice to settle...</option>
                  {invoices
                    .filter((inv) => inv.balanceDue > 0)
                    .map((inv) => (
                      <option key={inv.id} value={inv.id}>
                        {inv.invoiceNumber} · {inv.propertyNumber} ({inv.ownerName}) — Balance: ${inv.balanceDue.toFixed(2)}
                      </option>
                    ))}
                </select>
              </div>

              {currentSelectedInvoice && (
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold block">Invoice Period & Rate</span>
                    <span className="font-semibold text-slate-900">{currentSelectedInvoice.billingMonth} ({currentSelectedInvoice.propertyType})</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-500 uppercase font-semibold block">Outstanding Balance</span>
                    <span className="font-mono font-bold text-rose-700 text-sm">${currentSelectedInvoice.balanceDue.toFixed(2)}</span>
                  </div>
                </div>
              )}

              {/* Payment Amount & Method */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Payment Amount (USD) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    max={currentSelectedInvoice?.balanceDue || 1000}
                    required
                    value={payAmount}
                    onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Max: ${currentSelectedInvoice?.balanceDue.toFixed(2) || '0.00'} (Overpayment locked)
                  </span>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Payment Method *
                  </label>
                  <select
                    value={payMethod}
                    onChange={(e) => setPayMethod(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                  >
                    <option value="cash">Cash (Confirmed immediately)</option>
                    <option value="digital">Digital (Requires reference)</option>
                  </select>
                </div>
              </div>

              {/* Digital Reference Input */}
              {payMethod === 'digital' && (
                <div className="space-y-3 p-3 bg-blue-50/70 rounded-lg border border-blue-200">
                  <div className="flex items-center gap-1.5 font-bold text-blue-950">
                    <CreditCard className="w-4 h-4 text-blue-700" />
                    Digital Payment Reference Verification
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Transaction Reference Number *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. TXN-WIRE-99214 or EVC-38192"
                      value={digitalRef}
                      onChange={(e) => setDigitalRef(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                    />
                    <span className="text-[10px] text-slate-500 mt-0.5 block">
                      Must be globally unique. Reused transaction references will be rejected.
                    </span>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Provider / Channel
                    </label>
                    <input
                      type="text"
                      value={digitalProvider}
                      onChange={(e) => setDigitalProvider(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                    />
                  </div>

                  <p className="text-[11px] text-amber-900 bg-amber-50 p-2 rounded border border-amber-200">
                    <strong>Rule:</strong> Digital transactions remain in <em>Pending</em> status and are <em>excluded</em> from confirmed municipal revenue until formally verified by a Finance Officer.
                  </p>
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Notes / Cashier Memo</label>
                <input
                  type="text"
                  value={payNotes}
                  onChange={(e) => setPayNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  placeholder="e.g. Paid in full at Central Municipal Desk"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsRecordModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={recording}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {recording ? 'Recording...' : payMethod === 'cash' ? 'Confirm Cash & Issue Receipt' : 'Submit Pending Digital Payment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Verify Digital Payment Modal */}
      {verifyingPayment && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <h3 className="font-bold text-sm">Verify Digital Transaction</h3>
              <button
                onClick={() => setVerifyingPayment(null)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              {verifyError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg">
                  {verifyError}
                </div>
              )}

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Transaction Reference:</span>
                  <span className="font-mono font-bold text-slate-900">{verifyingPayment.digitalReference}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Invoice Reference:</span>
                  <span className="font-mono text-slate-800">{verifyingPayment.invoiceNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Property & Owner:</span>
                  <span className="font-medium text-slate-800">{verifyingPayment.propertyNumber} ({verifyingPayment.ownerName})</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-slate-200">
                  <span className="font-bold text-slate-900">Payment Amount:</span>
                  <span className="font-mono font-bold text-emerald-700 text-sm">${verifyingPayment.amount.toFixed(2)}</span>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Verification Action</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setVerifyingAction('approve')}
                    className={`p-2.5 rounded-lg border text-center font-semibold transition-all ${
                      verifyingAction === 'approve'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    ✓ Approve & Confirm
                  </button>
                  <button
                    type="button"
                    onClick={() => setVerifyingAction('reject')}
                    className={`p-2.5 rounded-lg border text-center font-semibold transition-all ${
                      verifyingAction === 'reject'
                        ? 'bg-rose-50 border-rose-500 text-rose-800 shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    ✕ Reject Transaction
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Verification Note / Bank Transit Match
                </label>
                <textarea
                  rows={2}
                  value={verifyNotes}
                  onChange={(e) => setVerifyNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  placeholder={
                    verifyingAction === 'approve'
                      ? 'Verified on daily bank statement batch'
                      : 'Reference does not appear in municipal gateway feed'
                  }
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setVerifyingPayment(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmVerification}
                  disabled={verifyingSubmitting}
                  className={`px-4 py-2 rounded-lg font-semibold text-white shadow-xs ${
                    verifyingAction === 'approve'
                      ? 'bg-emerald-700 hover:bg-emerald-800'
                      : 'bg-rose-700 hover:bg-rose-800'
                  }`}
                >
                  {verifyingSubmitting ? 'Processing...' : verifyingAction === 'approve' ? 'Confirm & Issue Receipt' : 'Reject Transaction'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Audited Payment Reversal Modal */}
      {reversingPayment && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-rose-900 text-white">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-rose-300" />
                <h3 className="font-bold text-sm">Audited Financial Transaction Reversal</h3>
              </div>
              <button
                onClick={() => setReversingPayment(null)}
                className="p-1 text-rose-300 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleExecuteReversal} className="p-6 space-y-4 text-xs">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-950 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-amber-700" />
                  Audited Reversal Protocol
                </div>
                <p className="text-[11px] text-amber-900 leading-relaxed">
                  Pursuant to municipal financial regulations, confirmed transactions cannot be deleted.
                  Reversing this payment will restore the outstanding invoice balance and log an immutable audit event.
                </p>
              </div>

              {reversalError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg">
                  {reversalError}
                </div>
              )}

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1 text-slate-800">
                <div>Receipt: <strong className="font-mono">{reversingPayment.receiptNumber}</strong></div>
                <div>Amount: <strong className="font-mono text-rose-700">${reversingPayment.amount.toFixed(2)}</strong></div>
                <div>Invoice: <span className="font-mono">{reversingPayment.invoiceNumber}</span></div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Audit Justification / Correction Reason *
                </label>
                <textarea
                  required
                  rows={3}
                  value={reversalReason}
                  onChange={(e) => setReversalReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-rose-500"
                  placeholder="e.g. Duplicate cashier key-in error; customer made duplicate payment via bank"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setReversingPayment(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={reversingSubmitting}
                  className="px-4 py-2 bg-rose-800 hover:bg-rose-900 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {reversingSubmitting ? 'Reversing...' : 'Execute Audited Reversal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
