import React from 'react';
import { Payment, Invoice } from '../../types/index.js';
import { Printer, X, CheckCircle2, ShieldCheck, Building, Download } from 'lucide-react';

interface PrintableReceiptModalProps {
  payment: Payment | null;
  invoice?: Invoice;
  onClose: () => void;
}

export const PrintableReceiptModal: React.FC<PrintableReceiptModalProps> = ({
  payment,
  invoice,
  onClose,
}) => {
  if (!payment) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        {/* Modal Controls (Hidden in print) */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-800 text-white print:hidden">
          <div className="flex items-center gap-2">
            <ReceiptIcon className="w-5 h-5 text-emerald-400" />
            <span className="font-semibold text-sm">Official Municipal Receipt</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium transition-colors shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              Print Receipt
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* The Printable Receipt Body */}
        <div className="p-8 text-slate-900 space-y-6 printable-receipt">
          {/* Header & Municipal Seal */}
          <div className="text-center pb-6 border-b border-dashed border-slate-300">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-slate-900 text-emerald-400 mb-2 font-bold text-xl shadow-xs">
              <Building className="w-6 h-6" />
            </div>
            <h2 className="text-lg font-bold text-slate-900 uppercase tracking-tight">
              Metropolitan City Sanitation Authority
            </h2>
            <p className="text-xs text-slate-500">
              Department of Waste Management & Municipal Revenue
            </p>
            <p className="text-[11px] text-slate-400">
              Official Waste Collection Service Fee Receipt
            </p>
          </div>

          {/* Receipt Meta Banner */}
          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-semibold">Receipt Number</span>
              <span className="font-mono font-bold text-slate-900 text-sm">
                {payment.receiptNumber}
              </span>
            </div>
            <div className="text-right">
              <span className="text-slate-500 block text-[10px] uppercase font-semibold">Issue Date & Time</span>
              <span className="font-medium text-slate-800">
                {new Date(payment.verifiedAt || payment.recordedAt).toLocaleString('en-US', {
                  dateStyle: 'medium',
                  timeStyle: 'short',
                })}
              </span>
            </div>
          </div>

          {/* Property & Payer Info */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-semibold">Property Number</span>
              <span className="font-mono font-semibold text-slate-900">{payment.propertyNumber}</span>
              <span className="text-slate-500 block text-[10px] uppercase font-semibold mt-2">Owner / Occupant</span>
              <span className="font-medium text-slate-800">{payment.ownerName}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] uppercase font-semibold">Invoice Reference</span>
              <span className="font-mono font-semibold text-slate-900">{payment.invoiceNumber}</span>
              <span className="text-slate-500 block text-[10px] uppercase font-semibold mt-2">Payment Method</span>
              <span className="font-medium text-slate-800 capitalize">
                {payment.paymentMethod === 'cash' ? 'Cash Settlement' : `Digital: ${payment.digitalReference || 'Pending'}`}
              </span>
            </div>
          </div>

          {/* Line item breakdown */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-slate-100 text-slate-700 border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2 text-left font-semibold">Description</th>
                  <th className="px-3 py-2 text-right font-semibold">Amount (USD)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                <tr>
                  <td className="px-3 py-2.5">
                    Municipal Solid Waste Collection Fee
                    <span className="block text-[11px] text-slate-500">
                      Property: {payment.propertyNumber} · Status: {payment.verificationStatus.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-right font-semibold">
                    ${payment.amount.toFixed(2)}
                  </td>
                </tr>
              </tbody>
              <tfoot className="bg-slate-50 border-t border-slate-200 text-xs">
                <tr>
                  <td className="px-3 py-2 font-bold text-slate-900">Total Paid (USD)</td>
                  <td className="px-3 py-2 text-right font-bold text-emerald-700 text-base">
                    ${payment.amount.toFixed(2)}
                  </td>
                </tr>
                {invoice && (
                  <tr>
                    <td className="px-3 py-1.5 text-slate-600">Remaining Balance on Invoice</td>
                    <td className="px-3 py-1.5 text-right font-mono font-medium text-slate-800">
                      ${invoice.balanceDue.toFixed(2)}
                    </td>
                  </tr>
                )}
              </tfoot>
            </table>
          </div>

          {/* Verification & Staff signature */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-xs">
            <div>
              <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Verified by {payment.verifiedByName || payment.recordedByName}</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Verification ID: MWMS-{payment.id.slice(-6).toUpperCase()}
              </p>
            </div>

            {/* Simulating QR Verification Box */}
            <div className="text-right">
              <div className="w-16 h-16 border-2 border-slate-800 p-1 rounded inline-block bg-white text-center">
                <div className="w-full h-full bg-slate-900 flex items-center justify-center text-[9px] text-white font-mono leading-none">
                  SECURE<br />SEAL
                </div>
              </div>
              <p className="text-[9px] text-slate-400 mt-0.5">Scannable Audit QR</p>
            </div>
          </div>

          {/* Footer note */}
          <p className="text-[10px] text-center text-slate-400 italic">
            This is an official computer-generated receipt issued pursuant to Municipal Waste Administration Bylaws.
            Retain this document for accounting and dispute verification.
          </p>
        </div>
      </div>
    </div>
  );
};

function ReceiptIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z" />
      <path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8" />
      <path d="M12 17V7" />
    </svg>
  );
}
