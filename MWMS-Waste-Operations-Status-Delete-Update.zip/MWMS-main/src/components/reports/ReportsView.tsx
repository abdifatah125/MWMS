import React, { useState } from 'react';
import { DashboardStats, Payment, Invoice, Zone, AppUser } from '../../types/index.js';
import {
  BarChart3,
  Download,
  DollarSign,
  TrendingUp,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Calendar,
  Layers,
} from 'lucide-react';

interface ReportsViewProps {
  stats: DashboardStats | null;
  payments: Payment[];
  invoices: Invoice[];
  zones: Zone[];
  currentUser: AppUser | null;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  stats,
  payments,
  invoices,
  zones,
  currentUser,
}) => {
  const [reportType, setReportType] = useState<
    'revenue' | 'arrears' | 'cashier' | 'performance'
  >('revenue');

  // Export CSV handler
  const exportCsv = (filename: string, rows: string[][]) => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      rows.map((e) => e.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExport = () => {
    if (reportType === 'revenue') {
      const rows = [
        ['Zone Name', 'Registered Properties', 'Total Invoiced (USD)', 'Confirmed Revenue (USD)', 'Outstanding Balance (USD)', 'Recovery %'],
        ...(stats?.zoneStats.map((z) => [
          z.zoneName,
          String(z.propertyCount),
          z.billed.toFixed(2),
          z.collected.toFixed(2),
          z.outstanding.toFixed(2),
          z.billed > 0 ? `${((z.collected / z.billed) * 100).toFixed(1)}%` : '0%',
        ]) || []),
      ];
      exportCsv('MWMS_Revenue_By_Zone', rows);
    } else if (reportType === 'arrears') {
      const rows = [
        ['Invoice Number', 'Property Number', 'Owner', 'Billing Month', 'Due Date', 'Amount Due (USD)', 'Balance Due (USD)', 'Status'],
        ...invoices
          .filter((i) => i.balanceDue > 0)
          .map((i) => [
            i.invoiceNumber,
            i.propertyNumber,
            i.ownerName,
            i.billingMonth,
            i.dueDate,
            i.amountDue.toFixed(2),
            i.balanceDue.toFixed(2),
            i.status,
          ]),
      ];
      exportCsv('MWMS_Arrears_Ledger', rows);
    } else if (reportType === 'cashier') {
      const rows = [
        ['Receipt Number', 'Invoice Number', 'Property', 'Amount (USD)', 'Method', 'Verification Status', 'Recorded By', 'Recorded Time'],
        ...payments.map((p) => [
          p.receiptNumber,
          p.invoiceNumber,
          p.propertyNumber,
          p.amount.toFixed(2),
          p.paymentMethod,
          p.verificationStatus,
          p.recordedByName,
          p.recordedAt,
        ]),
      ];
      exportCsv('MWMS_Cashier_Reconciliation', rows);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-emerald-700" />
            Financial & Operational Reports
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Exportable municipal revenue summaries, arrears aging, cashier reconciliation, and collection recovery
          </p>
        </div>

        <button
          onClick={handleExport}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          Export Report to CSV
        </button>
      </div>

      {/* Report Type Selector Tabs */}
      <div className="flex border-b border-slate-200 gap-2 overflow-x-auto pb-1 text-xs">
        <button
          onClick={() => setReportType('revenue')}
          className={`px-3.5 py-2 font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
            reportType === 'revenue'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          Revenue by Zone & Method
        </button>

        <button
          onClick={() => setReportType('arrears')}
          className={`px-3.5 py-2 font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
            reportType === 'arrears'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          Arrears Aging & Default Risk
        </button>

        <button
          onClick={() => setReportType('cashier')}
          className={`px-3.5 py-2 font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
            reportType === 'cashier'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          Cashier Shift Reconciliation
        </button>
      </div>

      {/* Content for Revenue Report */}
      {reportType === 'revenue' && stats && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] uppercase font-bold text-slate-500 block mb-1">
                Total Confirmed Municipal Collections
              </span>
              <span className="text-2xl font-black text-slate-900 font-mono">
                ${stats.confirmedRevenue.toFixed(2)}
              </span>
              <p className="text-[11px] text-emerald-700 mt-1">
                Verified through cash desk & bank transaction reconciliation
              </p>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] uppercase font-bold text-slate-500 block mb-1">
                Pending Digital Settlements (Excluded)
              </span>
              <span className="text-2xl font-black text-amber-700 font-mono">
                ${stats.revenueByMethod.digitalPending.toFixed(2)}
              </span>
              <p className="text-[11px] text-amber-800 mt-1">
                {stats.pendingDigitalCount} transactions in verification queue
              </p>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] uppercase font-bold text-slate-500 block mb-1">
                Overall Recovery Efficiency
              </span>
              <span className="text-2xl font-black text-cyan-700 font-mono">
                {stats.monthlyBilledTotal > 0
                  ? ((stats.confirmedRevenue / stats.monthlyBilledTotal) * 100).toFixed(1)
                  : 0}
                %
              </span>
              <p className="text-[11px] text-slate-500 mt-1">
                Of total invoiced fee amounts recovered
              </p>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 font-bold text-sm text-slate-900">
              Zone Performance Ledger
            </div>
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="px-4 py-3">Municipal Zone</th>
                  <th className="px-4 py-3 text-center">Properties</th>
                  <th className="px-4 py-3 text-right">Invoiced (USD)</th>
                  <th className="px-4 py-3 text-right">Confirmed Collected</th>
                  <th className="px-4 py-3 text-right">Outstanding Arrears</th>
                  <th className="px-4 py-3 text-right">Collection %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {stats.zoneStats.map((z) => (
                  <tr key={z.zoneId} className="hover:bg-slate-50/50">
                    <td className="px-4 py-3 font-semibold text-slate-900">{z.zoneName}</td>
                    <td className="px-4 py-3 text-center font-mono text-slate-600">
                      {z.propertyCount}
                    </td>
                    <td className="px-4 py-3 text-right font-mono">${z.billed.toFixed(2)}</td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-emerald-700">
                      ${z.collected.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-rose-700">
                      ${z.outstanding.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-right font-medium">
                      {z.billed > 0 ? ((z.collected / z.billed) * 100).toFixed(1) : '0'}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Content for Arrears Report */}
      {reportType === 'arrears' && stats && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[10px] uppercase font-bold text-slate-500 block">Current</span>
              <span className="text-xl font-bold font-mono text-slate-900 mt-1 block">
                ${stats.arrearsAging.current.toFixed(2)}
              </span>
              <span className="text-[10px] text-slate-400">Within payment due window</span>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[10px] uppercase font-bold text-amber-600 block">1–30 Days Overdue</span>
              <span className="text-xl font-bold font-mono text-amber-700 mt-1 block">
                ${stats.arrearsAging.days30.toFixed(2)}
              </span>
              <span className="text-[10px] text-slate-400">First notice stage</span>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[10px] uppercase font-bold text-orange-600 block">31–60 Days Overdue</span>
              <span className="text-xl font-bold font-mono text-orange-700 mt-1 block">
                ${stats.arrearsAging.days60.toFixed(2)}
              </span>
              <span className="text-[10px] text-slate-400">Secondary warning</span>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[10px] uppercase font-bold text-rose-600 block">60+ Days (Arrears)</span>
              <span className="text-xl font-bold font-mono text-rose-700 mt-1 block">
                ${stats.arrearsAging.days90Plus.toFixed(2)}
              </span>
              <span className="text-[10px] text-slate-400">Suspension review candidate</span>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 font-bold text-sm text-slate-900">
              Outstanding Invoices Requiring Municipal Follow-up
            </div>
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="px-4 py-3">Invoice #</th>
                  <th className="px-4 py-3">Property</th>
                  <th className="px-4 py-3">Owner / Occupant</th>
                  <th className="px-4 py-3">Billing Cycle</th>
                  <th className="px-4 py-3">Due Date</th>
                  <th className="px-4 py-3 text-right">Invoiced (USD)</th>
                  <th className="px-4 py-3 text-right">Balance Due</th>
                  <th className="px-4 py-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {invoices
                  .filter((i) => i.balanceDue > 0)
                  .map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50/50">
                      <td className="px-4 py-3 font-mono font-bold">{inv.invoiceNumber}</td>
                      <td className="px-4 py-3 font-mono">{inv.propertyNumber}</td>
                      <td className="px-4 py-3 font-medium text-slate-900">{inv.ownerName}</td>
                      <td className="px-4 py-3 font-mono">{inv.billingMonth}</td>
                      <td className="px-4 py-3 font-mono text-slate-600">{inv.dueDate}</td>
                      <td className="px-4 py-3 text-right font-mono">${inv.amountDue.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-rose-700">
                        ${inv.balanceDue.toFixed(2)}
                      </td>
                      <td className="px-4 py-3 text-center uppercase text-[10px] font-bold text-amber-800">
                        {inv.status}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Content for Cashier Reconciliation */}
      {reportType === 'cashier' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900">Municipal Cashier Shift Ledger</h3>
            <span className="text-xs text-slate-500">
              Audit log of all cashier window & digital transaction recordings
            </span>
          </div>

          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
              <tr>
                <th className="px-4 py-3">Receipt / ID</th>
                <th className="px-4 py-3">Invoice</th>
                <th className="px-4 py-3">Property</th>
                <th className="px-4 py-3">Cashier Staff</th>
                <th className="px-4 py-3">Method & Details</th>
                <th className="px-4 py-3 text-right">Intake Amount</th>
                <th className="px-4 py-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {payments.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 font-mono font-bold text-slate-900">
                    {p.receiptNumber}
                  </td>
                  <td className="px-4 py-3 font-mono text-slate-700">{p.invoiceNumber}</td>
                  <td className="px-4 py-3 font-medium text-slate-900">{p.propertyNumber}</td>
                  <td className="px-4 py-3 text-slate-700">{p.recordedByName}</td>
                  <td className="px-4 py-3">
                    <span className="capitalize font-medium">{p.paymentMethod}</span>
                    {p.digitalReference && (
                      <span className="block font-mono text-[11px] text-slate-400">
                        {p.digitalReference}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold text-slate-900">
                    ${p.amount.toFixed(2)}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                        p.verificationStatus === 'confirmed'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : p.verificationStatus === 'pending'
                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                          : 'bg-rose-50 text-rose-800 border-rose-200'
                      }`}
                    >
                      {p.verificationStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
