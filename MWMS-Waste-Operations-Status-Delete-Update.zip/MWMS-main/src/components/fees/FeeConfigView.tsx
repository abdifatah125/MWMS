import React, { useState } from 'react';
import { FeeRate, AppUser } from '../../types/index.js';
import { CircleDollarSign, CheckCircle2, Clock, AlertTriangle, Plus, ShieldCheck, Check, Calendar } from 'lucide-react';

interface FeeConfigViewProps {
  feeRates: FeeRate[];
  currentUser: AppUser | null;
  onProposeFee: (payload: {
    propertyType: 'residential' | 'commercial';
    monthlyFee: number;
    effectiveDate: string;
    notes: string;
  }) => Promise<void>;
  onApproveFee: (id: string) => Promise<void>;
}

export const FeeConfigView: React.FC<FeeConfigViewProps> = ({
  feeRates,
  currentUser,
  onProposeFee,
  onApproveFee,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formType, setFormType] = useState<'residential' | 'commercial'>('commercial');
  const [formFee, setFormFee] = useState<number>(30.0);
  const [formDate, setFormDate] = useState('2026-11-01');
  const [formNotes, setFormNotes] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [approvingId, setApprovingId] = useState<string | null>(null);

  const residentialFee = feeRates
    .filter((f) => f.propertyType === 'residential' && f.status === 'approved')
    .sort((a, b) => new Date(b.effectiveDate).getTime() - new Date(a.effectiveDate).getTime())[0];

  const commercialFee = feeRates
    .filter((f) => f.propertyType === 'commercial' && f.status === 'approved')
    .sort((a, b) => new Date(b.effectiveDate).getTime() - new Date(a.effectiveDate).getTime())[0];

  const pendingFees = feeRates.filter((f) => f.status === 'pending_approval');

  const canApprove = currentUser?.role === 'admin' || currentUser?.role === 'finance_officer';
  const canPropose = currentUser?.role === 'admin' || currentUser?.role === 'finance_officer';

  const handlePropose = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canPropose) {
      setError('Permission denied: Only System Administrator or Finance Officer can propose rates.');
      return;
    }
    setError('');
    setSubmitting(true);
    try {
      await onProposeFee({
        propertyType: formType,
        monthlyFee: Number(formFee),
        effectiveDate: formDate,
        notes: formNotes,
      });
      setIsModalOpen(false);
    } catch (err: any) {
      setError(err.message || 'Failed to submit proposal');
    } finally {
      setSubmitting(false);
    }
  };

  const handleApprove = async (id: string) => {
    if (!canApprove) {
      alert('Permission denied: Only System Administrator or Finance Officer can approve rates.');
      return;
    }
    setApprovingId(id);
    try {
      await onApproveFee(id);
    } catch (err: any) {
      alert(err.message || 'Approval failed');
    } finally {
      setApprovingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <CircleDollarSign className="w-5 h-5 text-emerald-700" />
            Approved Municipal Fee Configurations
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Maintain residential and commercial rates with effective dates and approval controls
          </p>
        </div>

        {canPropose ? (
          <button
            onClick={() => {
              setFormType('commercial');
              setFormFee(30.0);
              setFormDate('2026-11-01');
              setFormNotes('');
              setError('');
              setIsModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            Propose Commercial Rate Change
          </button>
        ) : (
          <div
            title="Only System Administrator and Finance Officer have tariff proposal authority"
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-100 text-slate-500 text-xs border border-slate-200 cursor-not-allowed self-start sm:self-auto"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
            <span>Tariff Proposals Restricted (Finance/Admin Only)</span>
          </div>
        )}
      </div>

      {!canApprove && (
        <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg text-xs text-slate-600 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-slate-500 shrink-0" />
          <span>
            <strong>Role Separation (Subration):</strong> As <em>{currentUser?.fullName} ({currentUser?.role})</em>, your role is job-based. Only Finance Officers and System Administrators have permission to propose or ratify waste fee tariffs.
          </span>
        </div>
      )}

      {/* 2 Primary Active Fee Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Residential Card */}
        <div className="bg-white rounded-xl border-2 border-emerald-500/60 p-6 shadow-xs relative overflow-hidden">
          <div className="absolute top-0 right-0 bg-emerald-600 text-white text-[10px] uppercase font-bold px-3 py-1 rounded-bl-lg">
            Statutory Council Fixed Rate
          </div>
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
            Residential Monthly Waste Fee
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-mono">
              ${residentialFee ? residentialFee.monthlyFee.toFixed(2) : '6.00'}
            </span>
            <span className="text-xs text-slate-500 font-medium">/ property / month</span>
          </div>

          <p className="text-xs text-slate-600 mt-3 leading-relaxed">
            Standard residential collection rate approved by Municipal Ordinance. Mandated at exactly $6.00 per property per month for all 5 collection zones.
          </p>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Status: <strong className="text-emerald-700">Active & Ratified</strong></span>
            <span>Effective Date: 2026-01-01</span>
          </div>
        </div>

        {/* Commercial Card */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs relative">
          <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
            Commercial Monthly Waste Fee
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 font-mono">
              ${commercialFee ? commercialFee.monthlyFee.toFixed(2) : '25.00'}
            </span>
            <span className="text-xs text-slate-500 font-medium">/ property / month</span>
          </div>

          <p className="text-xs text-slate-600 mt-3 leading-relaxed">
            Configurable by an authorized administrator with formal Finance Officer approval. Applied automatically to commercial enterprises during monthly bill generation.
          </p>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Status: <strong className="text-emerald-700 font-semibold">{commercialFee?.status.toUpperCase() || 'APPROVED'}</strong></span>
            <span>Approved by: {commercialFee?.approvedBy || 'admin.marcus'}</span>
          </div>
        </div>
      </div>

      {/* Pending Approval Section */}
      {pendingFees.length > 0 && (
        <div className="bg-amber-50 rounded-xl border border-amber-200 p-5 shadow-xs space-y-3">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-700" />
            <h3 className="font-bold text-sm text-amber-950">
              Pending Fee Proposals Awaiting Formal Approval
            </h3>
          </div>
          <div className="divide-y divide-amber-200/70 text-xs">
            {pendingFees.map((fee) => (
              <div key={fee.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">
                      ${fee.monthlyFee.toFixed(2)}/mo
                    </span>
                    <span className="px-2 py-0.5 rounded font-semibold uppercase text-[10px] bg-amber-100 text-amber-900 border border-amber-300">
                      {fee.propertyType}
                    </span>
                    <span className="text-slate-500">
                      Effective: {fee.effectiveDate}
                    </span>
                  </div>
                  <p className="text-slate-600 mt-1">{fee.notes}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Proposed by: {fee.proposedBy}
                  </p>
                </div>

                {canApprove ? (
                  <button
                    onClick={() => handleApprove(fee.id)}
                    disabled={approvingId === fee.id}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs shadow-xs transition-colors self-start sm:self-auto"
                  >
                    <Check className="w-3.5 h-3.5" />
                    {approvingId === fee.id ? 'Approving...' : 'Ratify & Approve Rate'}
                  </button>
                ) : (
                  <span className="text-[11px] text-slate-500 italic">
                    Requires Admin or Finance Officer approval
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Historical Rates Audit Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-bold text-sm text-slate-900">Historical Fee Rate Decisions</h3>
          <span className="text-xs text-slate-500">
            Historical invoice rates remain unchanged upon fee adjustments
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
              <tr>
                <th className="px-4 py-3">Property Category</th>
                <th className="px-4 py-3 text-right">Approved Rate (USD)</th>
                <th className="px-4 py-3">Effective Date</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Proposed By</th>
                <th className="px-4 py-3">Approved By</th>
                <th className="px-4 py-3">Ordinance Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {feeRates.map((f) => (
                <tr key={f.id} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 font-semibold uppercase text-slate-900">
                    {f.propertyType}
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold text-slate-900">
                    ${f.monthlyFee.toFixed(2)}
                  </td>
                  <td className="px-4 py-3 font-mono">{f.effectiveDate}</td>
                  <td className="px-4 py-3">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        f.status === 'approved'
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : f.status === 'pending_approval'
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {f.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">{f.proposedBy}</td>
                  <td className="px-4 py-3">{f.approvedBy || '—'}</td>
                  <td className="px-4 py-3 text-slate-500 max-w-xs truncate">{f.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Propose Rate Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <h3 className="font-bold text-sm">Propose New Fee Rate</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handlePropose} className="p-6 space-y-4 text-xs">
              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg">
                  {error}
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Property Category
                </label>
                <select
                  value={formType}
                  onChange={(e) => setFormType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="commercial">Commercial (Configurable rate)</option>
                  <option value="residential">Residential ($6.00 standard rate)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Proposed Monthly Fee (USD) *
                </label>
                <input
                  type="number"
                  step="0.50"
                  min="1"
                  required
                  value={formFee}
                  onChange={(e) => setFormFee(parseFloat(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Effective Date *
                </label>
                <input
                  type="date"
                  required
                  value={formDate}
                  onChange={(e) => setFormDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Justification / Council Rationale
                </label>
                <textarea
                  rows={3}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  placeholder="e.g. Revised commercial index for logistics heavy zones"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {submitting ? 'Submitting...' : 'Submit for Approval'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
