import React, { useState } from 'react';
import { Property, District, SubDistrict, Zone, Invoice, Payment, AppUser } from '../../types/index.js';
import {
  Building2,
  Search,
  Filter,
  Plus,
  Edit2,
  FileText,
  MapPin,
  Phone,
  User,
  CheckCircle,
  AlertTriangle,
  X,
  History,
  Eye,
  Layers,
  Trash2,
} from 'lucide-react';

interface PropertiesViewProps {
  properties: Property[];
  districts: District[];
  subDistricts: SubDistrict[];
  zones: Zone[];
  currentUser: AppUser | null;
  onAddProperty: (prop: Omit<Property, 'id' | 'registeredAt'>) => Promise<void>;
  onUpdateProperty: (id: string, updates: Partial<Property>) => Promise<void>;
  onDeleteProperty: (id: string) => Promise<void>;
  allInvoices: Invoice[];
  allPayments: Payment[];
  onOpenRecordPaymentWithInvoice?: (invoice: Invoice) => void;
}

export const PropertiesView: React.FC<PropertiesViewProps> = ({
  properties,
  districts,
  subDistricts,
  zones,
  currentUser,
  onAddProperty,
  onUpdateProperty,
  onDeleteProperty,
  allInvoices,
  allPayments,
  onOpenRecordPaymentWithInvoice,
}) => {
  const [search, setSearch] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('all');
  const [selectedSubDistrict, setSelectedSubDistrict] = useState('all');
  const [selectedZone, setSelectedZone] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [viewHistoryProp, setViewHistoryProp] = useState<Property | null>(null);

  // Form states
  const [formPropNumber, setFormPropNumber] = useState('');
  const [formOwner, setFormOwner] = useState('');
  const [formOccupant, setFormOccupant] = useState('');
  const [formPhone, setFormPhone] = useState('+252 61 ');
  const [formAddress, setFormAddress] = useState('');
  const [formDistrictId, setFormDistrictId] = useState(districts[0]?.id || 'dist-hodan');
  const [formSubDistrictId, setFormSubDistrictId] = useState('');
  const [formZoneId, setFormZoneId] = useState('');
  const [formType, setFormType] = useState<'residential' | 'commercial'>('residential');
  const [formStatus, setFormStatus] = useState<'active' | 'suspended' | 'inactive'>('active');
  const [formNotes, setFormNotes] = useState('');
  const [formError, setFormError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Filter properties
  const filtered = properties.filter((p) => {
    if (selectedDistrict !== 'all' && p.districtId !== selectedDistrict) return false;
    if (selectedSubDistrict !== 'all' && p.subDistrictId !== selectedSubDistrict) return false;
    if (selectedZone !== 'all' && p.zoneId !== selectedZone) return false;
    if (selectedType !== 'all' && p.propertyType !== selectedType) return false;
    if (selectedStatus !== 'all' && p.serviceStatus !== selectedStatus) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        p.propertyNumber.toLowerCase().includes(q) ||
        p.ownerName.toLowerCase().includes(q) ||
        p.address.toLowerCase().includes(q) ||
        p.phone.toLowerCase().includes(q) ||
        (p.districtName && p.districtName.toLowerCase().includes(q)) ||
        (p.subDistrictName && p.subDistrictName.toLowerCase().includes(q)) ||
        (p.zoneCode && p.zoneCode.toLowerCase().includes(q))
      );
    }
    return true;
  });

  // Cascading helpers for Form
  const handleDistrictChange = (dId: string) => {
    setFormDistrictId(dId);
    const availableSubs = subDistricts.filter((s) => s.districtId === dId);
    const nextSubId = availableSubs[0]?.id || '';
    setFormSubDistrictId(nextSubId);

    const availableZones = zones.filter((z) => (nextSubId ? z.subDistrictId === nextSubId : z.districtId === dId));
    setFormZoneId(availableZones[0]?.id || zones[0]?.id || '');
  };

  const handleSubDistrictChange = (subId: string) => {
    setFormSubDistrictId(subId);
    const availableZones = zones.filter((z) => z.subDistrictId === subId);
    setFormZoneId(availableZones[0]?.id || zones[0]?.id || '');
  };

  const openAddModal = () => {
    const dId = districts[0]?.id || 'dist-hodan';
    setFormDistrictId(dId);
    const availableSubs = subDistricts.filter((s) => s.districtId === dId);
    const nextSubId = availableSubs[0]?.id || '';
    setFormSubDistrictId(nextSubId);
    const availableZones = zones.filter((z) => (nextSubId ? z.subDistrictId === nextSubId : z.districtId === dId));
    setFormZoneId(availableZones[0]?.id || zones[0]?.id || '');

    setFormPropNumber(`PROP-MOG-${String(properties.length + 1).padStart(3, '0')}`);
    setFormOwner('');
    setFormOccupant('');
    setFormPhone('+252 61 ');
    setFormAddress('');
    setFormType('residential');
    setFormStatus('active');
    setFormNotes('');
    setFormError('');
    setIsAddModalOpen(true);
  };

  const openEditModal = (prop: Property) => {
    setSelectedProperty(prop);
    setFormPropNumber(prop.propertyNumber);
    setFormOwner(prop.ownerName);
    setFormOccupant(prop.occupantName);
    setFormPhone(prop.phone);
    setFormAddress(prop.address);
    setFormDistrictId(prop.districtId);
    setFormSubDistrictId(prop.subDistrictId);
    setFormZoneId(prop.zoneId);
    setFormType(prop.propertyType);
    setFormStatus(prop.serviceStatus);
    setFormNotes(prop.notes || '');
    setFormError('');
    setIsEditModalOpen(true);
  };

  const handleDelete = async (prop: Property) => {
    const confirmed = window.confirm(`Permanently delete ${prop.propertyNumber} — ${prop.ownerName}? This cannot be undone. Properties with billing or collection history cannot be deleted.`);
    if (!confirmed) return;
    try { await onDeleteProperty(prop.id); }
    catch (err: any) { window.alert(err.message || 'Failed to delete property'); }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSubmitting(true);
    try {
      await onAddProperty({
        propertyNumber: formPropNumber,
        ownerName: formOwner,
        occupantName: formOccupant || formOwner,
        phone: formPhone,
        address: formAddress,
        districtId: formDistrictId,
        subDistrictId: formSubDistrictId,
        zoneId: formZoneId,
        propertyType: formType,
        serviceStatus: formStatus,
        notes: formNotes,
      });
      setIsAddModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to create property');
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProperty) return;
    setFormError('');
    setSubmitting(true);
    try {
      await onUpdateProperty(selectedProperty.id, {
        propertyNumber: formPropNumber,
        ownerName: formOwner,
        occupantName: formOccupant,
        phone: formPhone,
        address: formAddress,
        districtId: formDistrictId,
        subDistrictId: formSubDistrictId,
        zoneId: formZoneId,
        propertyType: formType,
        serviceStatus: formStatus,
        notes: formNotes,
      });
      setIsEditModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to update property');
    } finally {
      setSubmitting(false);
    }
  };

  const availableSubsForFilter = selectedDistrict !== 'all'
    ? subDistricts.filter((s) => s.districtId === selectedDistrict)
    : subDistricts;

  const availableZonesForFilter = selectedSubDistrict !== 'all'
    ? zones.filter((z) => z.subDistrictId === selectedSubDistrict)
    : selectedDistrict !== 'all'
    ? zones.filter((z) => z.districtId === selectedDistrict)
    : zones;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Building2 className="w-5 h-5 text-emerald-700" />
            Mogadishu Municipal Property Registry
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Registry of properties categorized by Mogadishu Districts, Sub-Districts (Waaxyaha), and Collection Zones
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Register New Property
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          {/* Search box */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search property #, owner, address, street..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* District filter */}
          <div>
            <select
              value={selectedDistrict}
              onChange={(e) => {
                setSelectedDistrict(e.target.value);
                setSelectedSubDistrict('all');
                setSelectedZone('all');
              }}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
            >
              <option value="all">All 20 Mogadishu Districts</option>
              {districts.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.somaliName})
                </option>
              ))}
            </select>
          </div>

          {/* Sub-District filter */}
          <div>
            <select
              value={selectedSubDistrict}
              onChange={(e) => {
                setSelectedSubDistrict(e.target.value);
                setSelectedZone('all');
              }}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
            >
              <option value="all">All Sub-Districts (Waax)</option>
              {availableSubsForFilter.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Property Type Filter */}
          <div>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
            >
              <option value="all">All Property Types</option>
              <option value="residential">Residential ($6/mo)</option>
              <option value="commercial">Commercial (Configured rate)</option>
            </select>
          </div>

          {/* Service Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
            >
              <option value="all">All Service Statuses</option>
              <option value="active">Active Service</option>
              <option value="suspended">Suspended</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
          <span>
            Showing <strong className="text-slate-800">{filtered.length}</strong> of{' '}
            <strong className="text-slate-800">{properties.length}</strong> registered Mogadishu properties
          </span>
          {(search || selectedDistrict !== 'all' || selectedSubDistrict !== 'all' || selectedZone !== 'all' || selectedType !== 'all' || selectedStatus !== 'all') && (
            <button
              onClick={() => {
                setSearch('');
                setSelectedDistrict('all');
                setSelectedSubDistrict('all');
                setSelectedZone('all');
                setSelectedType('all');
                setSelectedStatus('all');
              }}
              className="text-emerald-700 hover:text-emerald-800 font-medium"
            >
              Reset filters
            </button>
          )}
        </div>
      </div>

      {/* Properties Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
              <tr>
                <th className="px-4 py-3">Property No.</th>
                <th className="px-4 py-3">Owner / Occupant</th>
                <th className="px-4 py-3">District & Sub-District</th>
                <th className="px-4 py-3">Collection Zone</th>
                <th className="px-4 py-3">Type</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Balance Due</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                    No properties match your filter selection.
                  </td>
                </tr>
              ) : (
                filtered.map((prop) => (
                  <tr key={prop.id} className="hover:bg-slate-50/50">
                    <td className="px-4 py-3 font-mono font-bold text-slate-900">
                      {prop.propertyNumber}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-slate-900">{prop.ownerName}</div>
                      <div className="text-[11px] text-slate-500">{prop.address}</div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {prop.phone}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-emerald-800">{prop.districtName || 'Mogadishu'}</div>
                      <div className="text-[11px] text-slate-500">{prop.subDistrictName || 'General Waax'}</div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-[11px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                        {prop.zoneCode || 'ZONE'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          prop.propertyType === 'residential'
                            ? 'bg-blue-50 text-blue-800 border border-blue-200'
                            : 'bg-purple-50 text-purple-800 border border-purple-200'
                        }`}
                      >
                        {prop.propertyType}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-medium ${
                          prop.serviceStatus === 'active'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-amber-50 text-amber-800 border border-amber-200'
                        }`}
                      >
                        {prop.serviceStatus}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold">
                      <span
                        className={
                          (prop.currentBalance || 0) > 0 ? 'text-rose-700' : 'text-emerald-700'
                        }
                      >
                        ${(prop.currentBalance || 0).toFixed(2)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setViewHistoryProp(prop)}
                          className="p-1 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded"
                          title="View property dossier"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openEditModal(prop)}
                          className="p-1 text-slate-500 hover:text-blue-700 hover:bg-slate-100 rounded"
                          title="Edit property details"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {currentUser?.role === 'admin' && (
                          <button
                            onClick={() => handleDelete(prop)}
                            className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded"
                            title="Delete property"
                            aria-label={`Delete ${prop.propertyNumber}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Property Modal with Cascading Dropdowns */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <h3 className="font-bold text-sm">Register New Property (Mogadishu)</h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="p-6 space-y-4 text-xs">
              {formError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                  {formError}
                </div>
              )}

              {/* 3-Tier Cascading Selector: District ➔ Sub-District ➔ Zone */}
              <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-lg space-y-3">
                <span className="font-bold text-emerald-950 block text-[11px] uppercase tracking-wider">
                  Mogadishu Territorial Assignment
                </span>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    1. District (Degmada) *
                  </label>
                  <select
                    value={formDistrictId}
                    onChange={(e) => handleDistrictChange(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                  >
                    {districts.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.somaliName})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      2. Sub-District (Waaxda) *
                    </label>
                    <select
                      value={formSubDistrictId}
                      onChange={(e) => handleSubDistrictChange(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                    >
                      {subDistricts
                        .filter((s) => s.districtId === formDistrictId)
                        .map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name}
                          </option>
                        ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      3. Collection Zone (Aagga) *
                    </label>
                    <select
                      value={formZoneId}
                      onChange={(e) => setFormZoneId(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                    >
                      {zones
                        .filter((z) => (formSubDistrictId ? z.subDistrictId === formSubDistrictId : z.districtId === formDistrictId))
                        .map((z) => (
                          <option key={z.id} value={z.id}>
                            {z.code}: {z.name}
                          </option>
                        ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Property Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={formPropNumber}
                    onChange={(e) => setFormPropNumber(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-1 focus:ring-emerald-500"
                    placeholder="e.g. PROP-MOG-HOD-010"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Property Type *</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="residential">Residential ($6.00/mo)</option>
                    <option value="commercial">Commercial (Configured rate)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Owner Name *</label>
                  <input
                    type="text"
                    required
                    value={formOwner}
                    onChange={(e) => setFormOwner(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                    placeholder="Full owner name"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Occupant / Tenant</label>
                  <input
                    type="text"
                    value={formOccupant}
                    onChange={(e) => setFormOccupant(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                    placeholder="Same as owner or tenant"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone Number *</label>
                  <input
                    type="text"
                    required
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                    placeholder="+252 61..."
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Service Status</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Street Address *</label>
                <input
                  type="text"
                  required
                  value={formAddress}
                  onChange={(e) => setFormAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  placeholder="Street name, landmark, gate number"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {submitting ? 'Registering...' : 'Complete Registration'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Property Modal */}
      {isEditModalOpen && selectedProperty && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <h3 className="font-bold text-sm">
                Edit Property {selectedProperty.propertyNumber}
              </h3>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdate} className="p-6 space-y-4 text-xs">
              {formError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                  {formError}
                </div>
              )}

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">District</label>
                  <select
                    value={formDistrictId}
                    onChange={(e) => handleDistrictChange(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                  >
                    {districts.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.somaliName})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Sub-District</label>
                    <select
                      value={formSubDistrictId}
                      onChange={(e) => handleSubDistrictChange(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                    >
                      {subDistricts
                        .filter((s) => s.districtId === formDistrictId)
                        .map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name}
                          </option>
                        ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Collection Zone</label>
                    <select
                      value={formZoneId}
                      onChange={(e) => setFormZoneId(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                    >
                      {zones
                        .filter((z) => (formSubDistrictId ? z.subDistrictId === formSubDistrictId : z.districtId === formDistrictId))
                        .map((z) => (
                          <option key={z.id} value={z.id}>
                            {z.code}: {z.name}
                          </option>
                        ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Owner Name *</label>
                  <input
                    type="text"
                    required
                    value={formOwner}
                    onChange={(e) => setFormOwner(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone *</label>
                  <input
                    type="text"
                    required
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Address *</label>
                <input
                  type="text"
                  required
                  value={formAddress}
                  onChange={(e) => setFormAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Property Type</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="residential">Residential ($6.00/mo)</option>
                    <option value="commercial">Commercial</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Service Status</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {submitting ? 'Saving...' : 'Update Property'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Property Dossier Modal */}
      {viewHistoryProp && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div>
                <h3 className="font-bold text-sm">
                  Property Dossier: {viewHistoryProp.propertyNumber}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {viewHistoryProp.ownerName} · District: {viewHistoryProp.districtName} · Waaxda: {viewHistoryProp.subDistrictName}
                </p>
              </div>
              <button
                onClick={() => setViewHistoryProp(null)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-5 text-xs">
              <div className="grid grid-cols-3 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-semibold">Total Invoiced</span>
                  <span className="font-bold text-sm font-mono text-slate-900">
                    ${(viewHistoryProp.totalBilled || 0).toFixed(2)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-semibold">Total Paid</span>
                  <span className="font-bold text-sm font-mono text-emerald-700">
                    ${(viewHistoryProp.totalPaid || 0).toFixed(2)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-semibold">Current Balance</span>
                  <span className="font-bold text-sm font-mono text-rose-700">
                    ${(viewHistoryProp.currentBalance || 0).toFixed(2)}
                  </span>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 mb-2">Monthly Invoices</h4>
                <div className="border border-slate-200 rounded-lg overflow-hidden">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-100 text-slate-700">
                      <tr>
                        <th className="px-3 py-1.5">Invoice #</th>
                        <th className="px-3 py-1.5">Month</th>
                        <th className="px-3 py-1.5 text-right">Amount</th>
                        <th className="px-3 py-1.5 text-right">Paid</th>
                        <th className="px-3 py-1.5 text-right">Balance</th>
                        <th className="px-3 py-1.5 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {allInvoices.filter((i) => i.propertyId === viewHistoryProp.id).length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-3 py-3 text-center text-slate-400">
                            No billing invoices recorded yet.
                          </td>
                        </tr>
                      ) : (
                        allInvoices
                          .filter((i) => i.propertyId === viewHistoryProp.id)
                          .map((inv) => (
                            <tr key={inv.id}>
                              <td className="px-3 py-1.5 font-mono">{inv.invoiceNumber}</td>
                              <td className="px-3 py-1.5">{inv.billingMonth}</td>
                              <td className="px-3 py-1.5 text-right font-mono">${inv.amountDue.toFixed(2)}</td>
                              <td className="px-3 py-1.5 text-right font-mono text-emerald-700">${inv.amountPaid.toFixed(2)}</td>
                              <td className="px-3 py-1.5 text-right font-mono font-bold text-rose-700">${inv.balanceDue.toFixed(2)}</td>
                              <td className="px-3 py-1.5 text-center uppercase text-[10px] font-semibold">{inv.status}</td>
                            </tr>
                          ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 mb-2">Payments & Receipts</h4>
                <div className="border border-slate-200 rounded-lg overflow-hidden">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-100 text-slate-700">
                      <tr>
                        <th className="px-3 py-1.5">Receipt #</th>
                        <th className="px-3 py-1.5">Date</th>
                        <th className="px-3 py-1.5">Method</th>
                        <th className="px-3 py-1.5 text-right">Amount</th>
                        <th className="px-3 py-1.5 text-center">Verification</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {allPayments.filter((p) => p.propertyId === viewHistoryProp.id).length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-3 py-3 text-center text-slate-400">
                            No payments recorded yet.
                          </td>
                        </tr>
                      ) : (
                        allPayments
                          .filter((p) => p.propertyId === viewHistoryProp.id)
                          .map((pay) => (
                            <tr key={pay.id}>
                              <td className="px-3 py-1.5 font-mono">{pay.receiptNumber}</td>
                              <td className="px-3 py-1.5">{new Date(pay.recordedAt).toLocaleDateString()}</td>
                              <td className="px-3 py-1.5 capitalize">{pay.paymentMethod}</td>
                              <td className="px-3 py-1.5 text-right font-mono font-bold text-emerald-700">${pay.amount.toFixed(2)}</td>
                              <td className="px-3 py-1.5 text-center uppercase text-[10px] font-semibold">{pay.verificationStatus}</td>
                            </tr>
                          ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setViewHistoryProp(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
