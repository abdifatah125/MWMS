import React, { useState, useEffect } from 'react';
import {
  AppUser,
  AuditLog,
  District,
  PermissionItem,
  RoleDefinition,
  UserRole,
  UserStatus,
  Zone,
} from '../../types/index.js';
import {
  Users,
  ShieldCheck,
  UserPlus,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  KeyRound,
  Edit2,
  Trash2,
  ShieldAlert,
  Building,
  Phone,
  Mail,
  Layers,
  MapPin,
  Lock,
  Unlock,
  ArrowRight,
  Info,
  Clock,
  Briefcase,
  X,
  Sparkles,
} from 'lucide-react';

interface UsersViewProps {
  users: AppUser[];
  currentUser: AppUser | null;
  districts: District[];
  zones: Zone[];
  auditLogs: AuditLog[];
  onCreateUser: (userData: Omit<AppUser, 'id'>) => Promise<void>;
  onUpdateUser: (id: string, updates: Partial<AppUser>) => Promise<void>;
  onDeleteUser: (id: string) => Promise<void>;
}

export const UsersView: React.FC<UsersViewProps> = ({
  users,
  currentUser,
  districts,
  zones,
  auditLogs,
  onCreateUser,
  onUpdateUser,
  onDeleteUser,
}) => {
  const [activeTab, setActiveTab] = useState<'directory' | 'roles' | 'logs'>('directory');
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<AppUser | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  // Form states for creation
  const [formData, setFormData] = useState({
    username: '',
    fullName: '',
    email: '',
    phone: '+252 61 ',
    department: 'Banaadir Regional Administration (BRA)',
    role: 'cashier' as UserRole,
    status: 'active' as UserStatus,
    assignedDistrictId: '',
    assignedZoneId: '',
  });

  const isAdmin = currentUser?.role === 'admin';

  // Role Definitions & Matrix
  const roleDefinitions: RoleDefinition[] = [
    {
      role: 'admin',
      title: 'System Administrator',
      department: 'Banaadir Regional Administration (BRA) / Municipal ICT',
      description:
        'Executive administrator with supreme governance privileges over staff identity, security privileges, district borders, and system diagnostics.',
      badgeColor: 'bg-amber-100 text-amber-900 border-amber-300',
      scopeSummary:
        'Full administrative access across all 20 Mogadishu districts, financial configs, and audit logs.',
      level: 5,
      responsibilities: [
        'Register municipal personnel and configure role privileges',
        'Create and maintain the 20 Mogadishu districts & sub-districts (waaxyo)',
        'Review immutable municipal governance audit logs',
        'Run automated financial and database invariant tests',
        'Perform system database backups and data reset controls',
      ],
      restrictedActions: [
        'Direct cash desk intake without counter cashier shift audit',
      ],
    },
    {
      role: 'finance_officer',
      title: 'Finance & Revenue Officer',
      department: 'Department of Revenue & Municipal Treasury',
      description:
        'Treasury authority responsible for proposing & approving waste tariffs, executing monthly property billing batches, verifying mobile/bank transactions, and authorizing audited reversals.',
      badgeColor: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      scopeSummary:
        'Fee rate approvals, monthly invoicing, payment validation, and financial reporting.',
      level: 4,
      responsibilities: [
        'Propose and ratify residential ($6.00 locked) and commercial waste fees',
        'Execute monthly property billing batches and due-date dispatch',
        'Inspect pending digital transactions (EVC Plus, Premier Wallet) and approve or reject receipts',
        'Authorize audited ledger payment reversals with formal justification',
        'Export zone revenue breakdowns and arrears aging analysis',
      ],
      restrictedActions: [
        'Cannot create staff user accounts or assign system roles',
        'Cannot delete or modify sanitation routes and vehicle fleets',
      ],
    },
    {
      role: 'cashier',
      title: 'Municipal Cashier',
      department: 'Mogadishu Central Cash & EVC Desk',
      description:
        'Front-counter revenue collector accepting cash payments from property owners, printing official receipts with QR codes, and querying balances.',
      badgeColor: 'bg-blue-100 text-blue-900 border-blue-300',
      scopeSummary:
        'Point-of-sale cash collection, receipt printing, and taxpayer ledger inquiry.',
      level: 2,
      responsibilities: [
        'Record verified cash payments for open property invoices',
        'Print official Mogadishu Municipal receipts with QR validation',
        'Search properties, owners, and check current outstanding balances',
        'Submit end-of-day cashier reconciliation logs to Treasury',
      ],
      restrictedActions: [
        'Strictly blocked from modifying or proposing municipal fee rates',
        'Strictly blocked from executing batch monthly billing runs',
        'Cannot verify digital transactions without finance officer credentials',
        'Cannot reverse payments or alter historical financial ledgers',
      ],
    },
    {
      role: 'collection_manager',
      title: 'Collection Operations Manager',
      department: 'Waste Operations & Fleet Logistics (Waaxda Nadaafadda)',
      description:
        'Logistics coordinator managing the compactor truck fleet, collection route stops, driver schedules, and customer complaint resolution.',
      badgeColor: 'bg-purple-100 text-purple-900 border-purple-300',
      scopeSummary:
        'Fleet maintenance, route design, collection schedule dispatch, and ticket resolution.',
      level: 3,
      responsibilities: [
        'Manage municipal compactor truck fleet records and service statuses',
        'Map and configure operational waste collection routes and stops',
        'Create daily collection schedules and assign field collectors',
        'Monitor scheduled versus completed pickup stops',
        'Triage, assign, and resolve customer missed-pickup complaints',
      ],
      restrictedActions: [
        'Cannot alter financial fee tariffs or approve billing rates',
        'Cannot access payment verification or revenue reversal functions',
        'Cannot manage administrative staff credentials',
      ],
    },
    {
      role: 'field_collector',
      title: 'Sanitation Field Collector',
      department: 'Sanitation Field Crew / Waste Drivers',
      description:
        'Frontline sanitation personnel operating compactor trucks, recording property pickup completion, and logging missed pickups with reasons.',
      badgeColor: 'bg-orange-100 text-orange-900 border-orange-300',
      scopeSummary:
        'Daily schedule execution, stop completion check-off, and waste weight reporting.',
      level: 1,
      responsibilities: [
        'View daily assigned waste collection route and property stops',
        'Check off collected stops and record waste weight (kg)',
        'Log missed pickups with standardized reasons (gate locked, bin not out, road blocked)',
        'View assigned zone and sub-district boundaries',
      ],
      restrictedActions: [
        'No access to municipal fee configuration or billing engines',
        'Cannot collect over-the-counter payments or issue official receipts',
        'Cannot modify system records or resolve administrative complaints',
      ],
    },
  ];

  const permissionsMatrix: PermissionItem[] = [
    {
      id: 'perm-user-mgmt',
      name: 'Staff & Role Management',
      description: 'Register staff users, modify credentials, assign roles, and toggle account activation',
      category: 'Identity & Governance',
      allowedRoles: ['admin'],
    },
    {
      id: 'perm-audit-view',
      name: 'Immutable Audit Trail',
      description: 'Inspect chronological system events, financial reversals, and rate approvals',
      category: 'Identity & Governance',
      allowedRoles: ['admin', 'finance_officer'],
    },
    {
      id: 'perm-tests-run',
      name: 'System Invariants Diagnostics',
      description: 'Execute automated regression tests for overpayment locks and duplicate bill prevention',
      category: 'Identity & Governance',
      allowedRoles: ['admin'],
    },
    {
      id: 'perm-districts-create',
      name: 'District & Waax Creation',
      description: 'Establish new Mogadishu districts and municipal sub-districts (waaxyaha)',
      category: 'Geographic Administration',
      allowedRoles: ['admin'],
    },
    {
      id: 'perm-zones-create',
      name: 'Waste Collection Zones',
      description: 'Partition operational micro-zones under sub-districts and set coverage areas',
      category: 'Geographic Administration',
      allowedRoles: ['admin', 'collection_manager'],
    },
    {
      id: 'perm-properties-crud',
      name: 'Property Registry Maintenance',
      description: 'Register and update commercial and residential properties across Mogadishu',
      category: 'Geographic Administration',
      allowedRoles: ['admin', 'finance_officer', 'collection_manager'],
    },
    {
      id: 'perm-fees-propose',
      name: 'Propose Fee Rates',
      description: 'Submit new commercial fee rates or residential rate adjustments for review',
      category: 'Financial & Tariffs',
      allowedRoles: ['admin', 'finance_officer'],
    },
    {
      id: 'perm-fees-approve',
      name: 'Ratify & Approve Fees',
      description: 'Officially ratify municipal fee rate schedules into active law',
      category: 'Financial & Tariffs',
      allowedRoles: ['admin', 'finance_officer'],
    },
    {
      id: 'perm-billing-batch',
      name: 'Generate Batch Invoices',
      description: 'Run monthly billing engines across 20 districts with duplicate prevention',
      category: 'Financial & Tariffs',
      allowedRoles: ['admin', 'finance_officer'],
    },
    {
      id: 'perm-pay-cash',
      name: 'Record Cash Payments',
      description: 'Accept cash at counter desks and issue official printed receipts with QR codes',
      category: 'Revenue & Treasury',
      allowedRoles: ['admin', 'finance_officer', 'cashier'],
    },
    {
      id: 'perm-pay-digital-verify',
      name: 'Verify Digital Payments',
      description: 'Inspect incoming mobile payments (EVC Plus, Premier) and approve/reject',
      category: 'Revenue & Treasury',
      allowedRoles: ['admin', 'finance_officer'],
    },
    {
      id: 'perm-pay-reversal',
      name: 'Audited Financial Reversals',
      description: 'Reverse incorrect payments with formal justification and restore invoice balances',
      category: 'Revenue & Treasury',
      allowedRoles: ['admin', 'finance_officer'],
    },
    {
      id: 'perm-reports-export',
      name: 'Financial Reports & Exports',
      description: 'Access arrears aging, zone collection rates, and export CSV audit ledgers',
      category: 'Revenue & Treasury',
      allowedRoles: ['admin', 'finance_officer'],
    },
    {
      id: 'perm-fleet-mgmt',
      name: 'Fleet & Compactor Trucks',
      description: 'Register and update municipal compactor trucks and maintenance statuses',
      category: 'Waste Logistics',
      allowedRoles: ['admin', 'collection_manager'],
    },
    {
      id: 'perm-routes-mgmt',
      name: 'Collection Routes Design',
      description: 'Design collection paths, waypoint stops, and zone frequency intervals',
      category: 'Waste Logistics',
      allowedRoles: ['admin', 'collection_manager'],
    },
    {
      id: 'perm-schedules-dispatch',
      name: 'Schedule Collection Dispatches',
      description: 'Dispatch daily collection schedules and assign drivers and field collectors',
      category: 'Waste Logistics',
      allowedRoles: ['admin', 'collection_manager'],
    },
    {
      id: 'perm-field-logging',
      name: 'Log Pickup Stops & Weights',
      description: 'Mark scheduled stops as collected or missed with reason and log waste weight',
      category: 'Waste Logistics',
      allowedRoles: ['admin', 'collection_manager', 'field_collector'],
    },
    {
      id: 'perm-complaints-resolve',
      name: 'Resolve Customer Complaints',
      description: 'Investigate missed collection tickets and document resolution notes',
      category: 'Waste Logistics',
      allowedRoles: ['admin', 'collection_manager'],
    },
  ];

  // Filtered users
  const filteredUsers = users.filter((u) => {
    if (roleFilter !== 'all' && u.role !== roleFilter) return false;
    if (statusFilter !== 'all' && (u.status || 'active') !== statusFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        u.fullName.toLowerCase().includes(q) ||
        u.username.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        (u.phone && u.phone.toLowerCase().includes(q)) ||
        u.department.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Filtered User audit logs
  const userLogs = auditLogs.filter(
    (l) => l.entityType === 'USER' || l.action.includes('USER') || l.action.includes('AUTH')
  );

  const getRoleBadgeClasses = (role: UserRole) => {
    switch (role) {
      case 'admin':
        return 'bg-amber-100 text-amber-900 border-amber-300';
      case 'finance_officer':
        return 'bg-emerald-100 text-emerald-900 border-emerald-300';
      case 'cashier':
        return 'bg-blue-100 text-blue-900 border-blue-300';
      case 'collection_manager':
        return 'bg-purple-100 text-purple-900 border-purple-300';
      case 'field_collector':
        return 'bg-orange-100 text-orange-900 border-orange-300';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const formatRoleTitle = (role: UserRole) => {
    switch (role) {
      case 'admin':
        return 'System Administrator';
      case 'finance_officer':
        return 'Finance Officer';
      case 'cashier':
        return 'Municipal Cashier';
      case 'collection_manager':
        return 'Collection Manager';
      case 'field_collector':
        return 'Field Collector';
      default:
        return role;
    }
  };

  // Handlers
  const handleOpenCreateModal = () => {
    setFormData({
      username: '',
      fullName: '',
      email: '',
      phone: '+252 61 ',
      department: 'Mogadishu Central Cash & EVC Desk',
      role: 'cashier',
      status: 'active',
      assignedDistrictId: districts[0]?.id || '',
      assignedZoneId: '',
    });
    setFormError('');
    setIsCreateModalOpen(true);
  };

  const handleOpenEditModal = (u: AppUser) => {
    setEditingUser(u);
    setFormError('');
  };

  const handleSaveNewUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    if (!formData.fullName.trim() || !formData.username.trim() || !formData.email.trim()) {
      setFormError('Please fill in Full Name, Username, and Email.');
      return;
    }

    setSubmitting(true);
    try {
      await onCreateUser({
        username: formData.username.trim().toLowerCase(),
        fullName: formData.fullName.trim(),
        email: formData.email.trim().toLowerCase(),
        phone: formData.phone.trim(),
        department: formData.department.trim(),
        role: formData.role,
        status: formData.status,
        assignedDistrictId: formData.assignedDistrictId || undefined,
        assignedZoneId: formData.assignedZoneId || undefined,
      });
      setIsCreateModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to create user');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSaveEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setFormError('');

    setSubmitting(true);
    try {
      await onUpdateUser(editingUser.id, {
        fullName: editingUser.fullName,
        username: editingUser.username,
        email: editingUser.email,
        phone: editingUser.phone,
        department: editingUser.department,
        role: editingUser.role,
        status: editingUser.status,
        assignedDistrictId: editingUser.assignedDistrictId || undefined,
        assignedZoneId: editingUser.assignedZoneId || undefined,
      });
      setEditingUser(null);
    } catch (err: any) {
      setFormError(err.message || 'Failed to update user profile');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleStatus = async (user: AppUser) => {
    if (!isAdmin) return;
    const newStatus: UserStatus = (user.status || 'active') === 'active' ? 'suspended' : 'active';
    try {
      await onUpdateUser(user.id, { status: newStatus });
    } catch (err: any) {
      alert(err.message || 'Failed to toggle status');
    }
  };

  const handleDelete = async (user: AppUser) => {
    if (!isAdmin) return;
    if (confirm(`Are you sure you want to delete user account '${user.fullName}' (@${user.username})?`)) {
      try {
        await onDeleteUser(user.id);
      } catch (err: any) {
        alert(err.message || 'Failed to delete user');
      }
    }
  };

  // Group permissions by category
  const categories = Array.from(new Set(permissionsMatrix.map((p) => p.category)));

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-700" />
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              User & Role Management
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Role-Based Access Control (RBAC), municipal staff credentials, and strict separation of duties (Subration)
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isAdmin ? (
            <button
              onClick={handleOpenCreateModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors"
            >
              <UserPlus className="w-3.5 h-3.5" />
              Register Staff User
            </button>
          ) : (
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 text-slate-600 text-xs border border-slate-200">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>Admin Rights Required to Create Users</span>
            </div>
          )}
        </div>
      </div>

      {/* KPI Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            Total Personnel
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-slate-900">{users.length}</span>
            <span className="text-xs text-emerald-700 font-medium">Mogadishu Staff</span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            System Admins
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-amber-700">
              {users.filter((u) => u.role === 'admin').length}
            </span>
            <span className="text-[11px] text-slate-400 font-mono">BRA Gov</span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            Finance Officers
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-emerald-700">
              {users.filter((u) => u.role === 'finance_officer').length}
            </span>
            <span className="text-[11px] text-slate-400 font-mono">Treasury</span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            Desk Cashiers
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-blue-700">
              {users.filter((u) => u.role === 'cashier').length}
            </span>
            <span className="text-[11px] text-slate-400 font-mono">Counter Desk</span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            Ops & Field Crew
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-purple-700">
              {users.filter((u) => u.role === 'collection_manager' || u.role === 'field_collector').length}
            </span>
            <span className="text-[11px] text-slate-400 font-mono">Sanitation</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('directory')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeTab === 'directory'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            Staff Directory ({filteredUsers.length})
          </button>

          <button
            onClick={() => setActiveTab('roles')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeTab === 'roles'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            Role Separation Matrix (Subration)
          </button>

          <button
            onClick={() => setActiveTab('logs')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              activeTab === 'logs'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Account Governance Logs ({userLogs.length})
          </button>
        </div>

        {activeTab === 'directory' && (
          <div className="flex items-center gap-2">
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg text-xs border border-slate-300 bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">All Roles</option>
              <option value="admin">System Administrator</option>
              <option value="finance_officer">Finance Officer</option>
              <option value="cashier">Municipal Cashier</option>
              <option value="collection_manager">Collection Manager</option>
              <option value="field_collector">Field Collector</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg text-xs border border-slate-300 bg-white text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active Accounts</option>
              <option value="suspended">Suspended Accounts</option>
            </select>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Search staff..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500 w-44 sm:w-56"
              />
            </div>
          </div>
        )}
      </div>

      {/* TAB 1: Staff Directory */}
      {activeTab === 'directory' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="px-4 py-3">Staff Member & Handle</th>
                  <th className="px-4 py-3">Assigned Role & Level</th>
                  <th className="px-4 py-3">Department</th>
                  <th className="px-4 py-3">Contact</th>
                  <th className="px-4 py-3">Assigned Territory</th>
                  <th className="px-4 py-3 text-center">Status</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-4 py-8 text-center text-xs text-slate-400">
                      No staff members match the selected filters.
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((u) => {
                    const isCurrentUser = currentUser?.id === u.id;
                    const district = districts.find((d) => d.id === u.assignedDistrictId);
                    const zone = zones.find((z) => z.id === u.assignedZoneId);

                    return (
                      <tr
                        key={u.id}
                        className={`hover:bg-slate-50/70 transition-colors ${
                          isCurrentUser ? 'bg-emerald-50/40' : ''
                        }`}
                      >
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-slate-800 text-emerald-400 font-bold flex items-center justify-center text-xs shrink-0">
                              {u.fullName.charAt(0)}
                            </div>
                            <div>
                              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                                <span>{u.fullName}</span>
                                {isCurrentUser && (
                                  <span className="text-[10px] bg-emerald-100 text-emerald-800 border border-emerald-300 px-1.5 py-0.2 rounded font-semibold">
                                    Current Session
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-slate-500 font-mono">
                                @{u.username}
                              </div>
                            </div>
                          </div>
                        </td>

                        <td className="px-4 py-3">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold border ${getRoleBadgeClasses(
                              u.role
                            )}`}
                          >
                            <ShieldCheck className="w-3 h-3" />
                            {formatRoleTitle(u.role)}
                          </span>
                        </td>

                        <td className="px-4 py-3 text-slate-600 max-w-xs truncate">
                          {u.department}
                        </td>

                        <td className="px-4 py-3 space-y-0.5">
                          <div className="flex items-center gap-1 text-[11px] text-slate-600">
                            <Mail className="w-3 h-3 text-slate-400 shrink-0" />
                            <span className="truncate">{u.email}</span>
                          </div>
                          {u.phone && (
                            <div className="flex items-center gap-1 text-[11px] text-slate-500 font-mono">
                              <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                              <span>{u.phone}</span>
                            </div>
                          )}
                        </td>

                        <td className="px-4 py-3 text-[11px]">
                          {district ? (
                            <div>
                              <span className="font-semibold text-slate-800 flex items-center gap-1">
                                <MapPin className="w-3 h-3 text-slate-400" />
                                {district.name}
                              </span>
                              {zone && (
                                <span className="text-slate-500 text-[10px] font-mono block">
                                  Zone: {zone.code}
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-slate-400 italic">Banaadir Central</span>
                          )}
                        </td>

                        <td className="px-4 py-3 text-center">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              (u.status || 'active') === 'active'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                (u.status || 'active') === 'active' ? 'bg-emerald-600' : 'bg-rose-600'
                              }`}
                            />
                            {(u.status || 'active').toUpperCase()}
                          </span>
                        </td>

                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Edit user button (admin only) */}
                            {isAdmin && (
                              <button
                                onClick={() => handleOpenEditModal(u)}
                                title="Edit user profile & change role"
                                className="p-1 rounded text-slate-500 hover:text-slate-800 hover:bg-slate-100"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                            )}

                            {/* Status toggle button (admin only) */}
                            {isAdmin && !isCurrentUser && (
                              <button
                                onClick={() => handleToggleStatus(u)}
                                title={
                                  (u.status || 'active') === 'active'
                                    ? 'Suspend staff account'
                                    : 'Reactivate staff account'
                                }
                                className={`p-1 rounded ${
                                  (u.status || 'active') === 'active'
                                    ? 'text-amber-600 hover:bg-amber-50'
                                    : 'text-emerald-600 hover:bg-emerald-50'
                                }`}
                              >
                                {(u.status || 'active') === 'active' ? (
                                  <Lock className="w-3.5 h-3.5" />
                                ) : (
                                  <Unlock className="w-3.5 h-3.5" />
                                )}
                              </button>
                            )}

                            {/* Delete button (admin only) */}
                            {isAdmin && !isCurrentUser && (
                              <button
                                onClick={() => handleDelete(u)}
                                title="Delete user"
                                className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: Role Separation Matrix (Subration & Access Separation) */}
      {activeTab === 'roles' && (
        <div className="space-y-6">
          {/* Explanatory Policy Banner */}
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-950 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2 font-bold text-emerald-900">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>Mogadishu Municipal Role Separation Policy (Subration & Separation of Duties)</span>
              </div>
              <p className="text-[11px] text-emerald-800">
                To prevent financial fraud, tariff tampering, and conflict of interest, system powers are partitioned strictly across five roles. Cashiers collect payments but cannot approve rates; Finance Officers approve billing but cannot manipulate driver routes.
              </p>
            </div>
            <div className="text-right shrink-0">
              <span className="font-mono text-xs font-bold px-2 py-1 rounded bg-white text-emerald-800 border border-emerald-300">
                5 Active Municipal Roles
              </span>
            </div>
          </div>

          {/* Role Cards Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {roleDefinitions.map((rd) => (
              <div
                key={rd.role}
                className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded border ${rd.badgeColor}`}
                    >
                      Level {rd.level} Authority
                    </span>
                    <span className="font-mono text-[10px] text-slate-500 uppercase font-semibold">
                      {rd.role}
                    </span>
                  </div>

                  <h3 className="font-bold text-sm text-slate-900">{rd.title}</h3>
                  <div className="text-[11px] font-medium text-emerald-700">
                    {rd.department}
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {rd.description}
                  </p>

                  <div className="pt-2 border-t border-slate-100">
                    <span className="text-[11px] font-bold text-slate-800 block mb-1">
                      Key Mandates:
                    </span>
                    <ul className="space-y-1 text-[11px] text-slate-600">
                      {rd.responsibilities.map((r, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{r}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-2 border-t border-slate-100">
                    <span className="text-[11px] font-bold text-rose-800 block mb-1">
                      Strict Security Restrictions:
                    </span>
                    <ul className="space-y-1 text-[11px] text-rose-700">
                      {rd.restrictedActions.map((ra, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <XCircle className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                          <span>{ra}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-medium">Active Staff:</span>
                  <span className="font-bold text-slate-900 font-mono">
                    {users.filter((u) => u.role === rd.role).length} assigned
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Granular Permissions Matrix Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-4 bg-slate-50 border-b border-slate-200">
              <h3 className="font-bold text-sm text-slate-900">
                Granular System Capabilities & Subration Matrix
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Exact privilege delegation table enforced at both backend API and frontend layers
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100/70 text-slate-700 border-b border-slate-200 font-semibold">
                  <tr>
                    <th className="px-4 py-3">Permission & Operation</th>
                    <th className="px-3 py-3 text-center">Admin (L5)</th>
                    <th className="px-3 py-3 text-center">Finance (L4)</th>
                    <th className="px-3 py-3 text-center">Cashier (L2)</th>
                    <th className="px-3 py-3 text-center">Ops Mgr (L3)</th>
                    <th className="px-3 py-3 text-center">Collector (L1)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-800">
                  {categories.map((cat) => {
                    const catPerms = permissionsMatrix.filter((p) => p.category === cat);
                    return (
                      <React.Fragment key={cat}>
                        <tr className="bg-slate-50/90 font-bold text-[11px] text-slate-600 uppercase tracking-wider">
                          <td colSpan={6} className="px-4 py-2">
                            {cat}
                          </td>
                        </tr>
                        {catPerms.map((perm) => (
                          <tr key={perm.id} className="hover:bg-slate-50/50">
                            <td className="px-4 py-3">
                              <div className="font-semibold text-slate-900">{perm.name}</div>
                              <div className="text-[11px] text-slate-500">{perm.description}</div>
                            </td>

                            {/* Admin */}
                            <td className="px-3 py-3 text-center">
                              {perm.allowedRoles.includes('admin') ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                              ) : (
                                <span className="text-slate-300 font-bold">—</span>
                              )}
                            </td>

                            {/* Finance Officer */}
                            <td className="px-3 py-3 text-center">
                              {perm.allowedRoles.includes('finance_officer') ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                              ) : (
                                <span className="text-slate-300 font-bold">—</span>
                              )}
                            </td>

                            {/* Cashier */}
                            <td className="px-3 py-3 text-center">
                              {perm.allowedRoles.includes('cashier') ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                              ) : (
                                <span className="text-slate-300 font-bold">—</span>
                              )}
                            </td>

                            {/* Collection Manager */}
                            <td className="px-3 py-3 text-center">
                              {perm.allowedRoles.includes('collection_manager') ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                              ) : (
                                <span className="text-slate-300 font-bold">—</span>
                              )}
                            </td>

                            {/* Field Collector */}
                            <td className="px-3 py-3 text-center">
                              {perm.allowedRoles.includes('field_collector') ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                              ) : (
                                <span className="text-slate-300 font-bold">—</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Account Governance Audit Trail */}
      {activeTab === 'logs' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-5 py-4 bg-slate-50 border-b border-slate-200">
            <h3 className="font-bold text-sm text-slate-900">
              Staff Lifecycle & Role Governance Logs
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Chronological log of staff creation, role assignments, profile edits, and session role-switches
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-700 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="px-4 py-3">Timestamp</th>
                  <th className="px-4 py-3">Action Event</th>
                  <th className="px-4 py-3">Initiated By</th>
                  <th className="px-4 py-3">Target Entity</th>
                  <th className="px-4 py-3">Audit Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {userLogs.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-xs text-slate-400">
                      No staff governance logs recorded yet.
                    </td>
                  </tr>
                ) : (
                  userLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/50">
                      <td className="px-4 py-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 font-semibold text-slate-900">
                        <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-slate-800">
                          {log.action}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-800">
                        {log.userName} ({log.userRole})
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-500 text-[11px]">
                        {log.entityId}
                      </td>
                      <td className="px-4 py-3 text-slate-600">{log.details}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL 1: Register New Staff User */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-base">Register Staff Personnel</h3>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewUser} className="p-6 space-y-4">
              {formError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Hassan Nur Adan"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    System Username *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. cashier.hassan"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Official Email *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="h.adan@mogadishu.gov.so"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Phone Contact
                  </label>
                  <input
                    type="text"
                    placeholder="+252 61 555 8899"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Assign Municipal Role *
                </label>
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 bg-white font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="admin">System Administrator (Level 5 — BRA Full Admin)</option>
                  <option value="finance_officer">Finance Officer (Level 4 — Treasury & Rates)</option>
                  <option value="cashier">Municipal Cashier (Level 2 — Cash & Receipts)</option>
                  <option value="collection_manager">Collection Operations Manager (Level 3 — Fleet & Routes)</option>
                  <option value="field_collector">Sanitation Field Collector (Level 1 — Field Crew)</option>
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Role determines which views, operations, and verification tools the staff member can execute.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Department / Directorate
                </label>
                <input
                  type="text"
                  value={formData.department}
                  onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                  placeholder="e.g. Mogadishu Central Cash & EVC Desk"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Assigned Mogadishu District
                  </label>
                  <select
                    value={formData.assignedDistrictId}
                    onChange={(e) => setFormData({ ...formData, assignedDistrictId: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="">Central / All Districts</option>
                    {districts.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Account Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as UserStatus })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="active">Active (Access Allowed)</option>
                    <option value="suspended">Suspended (Access Blocked)</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 rounded-lg shadow-xs transition-colors"
                >
                  {submitting ? 'Registering...' : 'Register User'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Edit Staff User & Role */}
      {editingUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Edit2 className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-base">Edit Staff User & Role</h3>
              </div>
              <button
                onClick={() => setEditingUser(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditUser} className="p-6 space-y-4">
              {formError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={editingUser.fullName}
                    onChange={(e) => setEditingUser({ ...editingUser, fullName: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Username
                  </label>
                  <input
                    type="text"
                    required
                    value={editingUser.username}
                    onChange={(e) => setEditingUser({ ...editingUser, username: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Official Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={editingUser.email}
                    onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Phone Contact
                  </label>
                  <input
                    type="text"
                    value={editingUser.phone || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, phone: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 font-mono focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Assigned Municipal Role *
                </label>
                <select
                  value={editingUser.role}
                  onChange={(e) =>
                    setEditingUser({ ...editingUser, role: e.target.value as UserRole })
                  }
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 bg-white font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
                >
                  <option value="admin">System Administrator (Level 5 — BRA Full Admin)</option>
                  <option value="finance_officer">Finance Officer (Level 4 — Treasury & Rates)</option>
                  <option value="cashier">Municipal Cashier (Level 2 — Cash & Receipts)</option>
                  <option value="collection_manager">Collection Operations Manager (Level 3 — Fleet & Routes)</option>
                  <option value="field_collector">Sanitation Field Collector (Level 1 — Field Crew)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Department
                </label>
                <input
                  type="text"
                  value={editingUser.department}
                  onChange={(e) => setEditingUser({ ...editingUser, department: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Assigned Mogadishu District
                  </label>
                  <select
                    value={editingUser.assignedDistrictId || ''}
                    onChange={(e) =>
                      setEditingUser({ ...editingUser, assignedDistrictId: e.target.value || undefined })
                    }
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="">Central / All Districts</option>
                    {districts.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Account Status
                  </label>
                  <select
                    value={editingUser.status || 'active'}
                    onChange={(e) =>
                      setEditingUser({ ...editingUser, status: e.target.value as UserStatus })
                    }
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  >
                    <option value="active">Active (Access Allowed)</option>
                    <option value="suspended">Suspended (Access Blocked)</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 rounded-lg shadow-xs transition-colors"
                >
                  {submitting ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
