import React from 'react';
import {
  LayoutDashboard,
  Building2,
  MapPin,
  CircleDollarSign,
  FileText,
  Receipt,
  Truck,
  BarChart3,
  ShieldCheck,
  AlertCircle,
  Users,
} from 'lucide-react';
import { AppUser } from '../../types/index.js';

export type NavTab =
  | 'dashboard'
  | 'properties'
  | 'zones'
  | 'fees'
  | 'billing'
  | 'payments'
  | 'operations'
  | 'reports'
  | 'audit'
  | 'users';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  pendingDigitalCount: number;
  openComplaintsCount: number;
  currentUser: AppUser | null;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  pendingDigitalCount,
  openComplaintsCount,
  currentUser,
}) => {
  interface NavItem {
    id: NavTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
    badgeColor?: string;
  }

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'properties', label: 'Property Registry', icon: Building2 },
    { id: 'zones', label: 'Zones Management', icon: MapPin },
    { id: 'fees', label: 'Fee Configuration', icon: CircleDollarSign },
    { id: 'billing', label: 'Monthly Billing', icon: FileText },
    {
      id: 'payments',
      label: 'Payments & Receipts',
      icon: Receipt,
      badge: pendingDigitalCount > 0 ? `${pendingDigitalCount} Pending` : undefined,
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
    },
    {
      id: 'operations',
      label: 'Waste Operations',
      icon: Truck,
      badge: openComplaintsCount > 0 ? `${openComplaintsCount} Alerts` : undefined,
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    },
    { id: 'reports', label: 'Financial Reports', icon: BarChart3 },
    { id: 'audit', label: 'Audit Trail', icon: ShieldCheck },
    {
      id: 'users',
      label: 'Users & Roles',
      icon: Users,
      badge: currentUser?.role === 'admin' ? 'L5 Admin' : 'Subration',
      badgeColor:
        currentUser?.role === 'admin'
          ? 'bg-amber-100 text-amber-800 border-amber-300'
          : 'bg-slate-200 text-slate-700 border-slate-300',
    },
  ];

  const getAuthorityLabel = (role?: string) => {
    switch (role) {
      case 'admin':
        return 'Level 5 · Full System Admin';
      case 'finance_officer':
        return 'Level 4 · Treasury & Tariffs';
      case 'collection_manager':
        return 'Level 3 · Ops & Logistics';
      case 'cashier':
        return 'Level 2 · Counter Cashier';
      case 'field_collector':
        return 'Level 1 · Sanitation Field';
      default:
        return 'Personnel';
    }
  };

  return (
    <aside className="w-64 bg-slate-50 border-r border-slate-200 flex-shrink-0 flex flex-col justify-between p-4 min-h-[calc(100vh-4rem)]">
      <div className="space-y-6">
        {/* Navigation List */}
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 px-3 mb-2 flex items-center justify-between">
            <span>Administration Modules</span>
            <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
              RBAC Active
            </span>
          </div>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id as NavTab)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all text-left ${
                    isActive
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'text-slate-750 hover:bg-slate-200/70 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                        isActive
                          ? 'bg-white/20 text-white border-white/30'
                          : item.badgeColor
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Operational Context Box */}
        <div className="p-3 bg-white rounded-lg border border-slate-200 text-xs text-slate-600 space-y-1.5">
          <div className="font-semibold text-slate-800 flex items-center gap-1.5 text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Operational Constraints
          </div>
          <p className="text-[11px] text-slate-500 leading-relaxed">
            Residential: <strong className="text-slate-750">$6.00/mo</strong> (fixed)
            <br />
            Commercial: <strong className="text-slate-750">Configurable rate</strong>
            <br />
            Subration: <span className="text-emerald-700 font-medium">Job-Based Least Privilege</span>
          </p>
        </div>
      </div>

      {/* User profile footer */}
      <div className="pt-4 border-t border-slate-200">
        <div className="flex items-center gap-3 px-2">
          <div className="w-9 h-9 rounded-full bg-slate-900 text-emerald-400 font-bold flex items-center justify-center text-xs shrink-0 shadow-xs border border-slate-700">
            {currentUser?.fullName.charAt(0) || 'U'}
          </div>
          <div className="truncate flex-1">
            <div className="flex items-center justify-between gap-1">
              <p className="text-xs font-bold text-slate-900 truncate">{currentUser?.fullName}</p>
            </div>
            <p className="text-[10px] font-semibold text-emerald-700 truncate">
              {getAuthorityLabel(currentUser?.role)}
            </p>
            <p className="text-[10px] text-slate-400 font-mono">
              {currentUser?.role === 'admin' ? '● Full Permitted' : '○ Job-Based Access'}
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
};
