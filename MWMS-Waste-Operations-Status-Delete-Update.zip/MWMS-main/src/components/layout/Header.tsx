import React from 'react';
import { AppUser } from '../../types/index.js';
import {
  ShieldAlert,
  CheckCircle,
  Database,
  Building,
  UserCheck,
  RefreshCw,
  Sun,
  Moon,
} from 'lucide-react';

interface HeaderProps {
  currentUser: AppUser | null;
  users: AppUser[];
  onLogout: () => void;
  onOpenTests: () => void;
  onOpenArchitecture: () => void;
  onRefreshData: () => void;
  isRefreshing?: boolean;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  users,
  onLogout,
  onOpenTests,
  onOpenArchitecture,
  onRefreshData,
  isRefreshing,
  theme,
  onToggleTheme,
}) => {
  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-amber-100 text-amber-900 border border-amber-300';
      case 'finance_officer':
        return 'bg-emerald-100 text-emerald-900 border border-emerald-300';
      case 'cashier':
        return 'bg-blue-100 text-blue-900 border border-blue-300';
      case 'collection_manager':
        return 'bg-purple-100 text-purple-900 border border-purple-300';
      case 'field_collector':
        return 'bg-orange-100 text-orange-900 border border-orange-300';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const formatRoleName = (role: string) => {
    switch (role) {
      case 'admin':
        return 'System Administrator';
      case 'finance_officer':
        return 'Finance Officer';
      case 'cashier':
        return 'Cashier';
      case 'collection_manager':
        return 'Collection Manager';
      case 'field_collector':
        return 'Field Collector';
      default:
        return role;
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-slate-900 text-white border-b border-slate-800 shadow-md">
      <div className="w-full px-3 sm:px-4 lg:px-5 h-16 flex items-center justify-between">
        {/* Brand / Municipality identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center text-white shadow-sm font-bold text-lg">
            <Building className="w-5 h-5 text-emerald-100" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-base sm:text-lg text-white">
                MWMS
              </span>
              <span className="text-xs uppercase font-semibold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                Municipal Portal
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Banaadir Regional Administration · 20 Mogadishu Districts · Multi-Role RBAC
            </p>
          </div>
        </div>

        {/* Right side controls: Role switch + Invariants test + System docs */}
        <div className="flex items-center gap-2 sm:gap-4">
          <button
            type="button"
            onClick={onToggleTheme}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
            title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
            aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
          >
            {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            <span className="hidden sm:inline">{theme === 'light' ? 'Dark mode' : 'Light mode'}</span>
          </button>
          <button
            onClick={onRefreshData}
            title="Refresh latest data"
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`} />
          </button>

          <button
            onClick={onOpenTests}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors shadow-xs"
            title="Run financial validation tests"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline">Run Financial Tests</span>
            <span className="md:hidden">Tests</span>
          </button>

          <button
            onClick={onOpenArchitecture}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors shadow-xs"
            title="View database schema & roadmap"
          >
            <Database className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">DB & Architecture</span>
            <span className="md:hidden">Docs</span>
          </button>

          {/* Authenticated account; no client-side persona switching */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            <UserCheck className="w-4 h-4 text-emerald-400 hidden sm:block" />
            <div className="text-right">
              <div className="text-xs font-semibold text-slate-200">{currentUser?.fullName}</div>
              <div className="text-[10px] text-slate-400">{currentUser ? formatRoleName(currentUser.role) : ''}</div>
            </div>
            <button onClick={onLogout} className="bg-slate-800 border border-slate-700 text-white text-xs rounded-lg px-2.5 py-1.5 hover:bg-slate-700">Sign out</button>
          </div>
        </div>
      </div>
    </header>
  );
};
