import React, { useState } from 'react';
import { AuditLog, AppUser } from '../../types/index.js';
import { ShieldCheck, Search, Filter, Clock, UserCheck, Shield } from 'lucide-react';

interface AuditLogsViewProps {
  logs: AuditLog[];
  currentUser: AppUser | null;
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({ logs, currentUser }) => {
  const [search, setSearch] = useState('');
  const [selectedAction, setSelectedAction] = useState('all');

  // Unique actions
  const actions = Array.from(new Set(logs.map((l) => l.action))).sort();

  const filtered = logs.filter((log) => {
    if (selectedAction !== 'all' && log.action !== selectedAction) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        log.action.toLowerCase().includes(q) ||
        log.userName.toLowerCase().includes(q) ||
        log.details.toLowerCase().includes(q) ||
        log.entityId.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const getActionColor = (action: string) => {
    if (action.includes('REVERSE') || action.includes('REJECT')) {
      return 'bg-rose-100 text-rose-800 border-rose-200';
    }
    if (action.includes('PAYMENT') || action.includes('CONFIRM') || action.includes('APPROVE')) {
      return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
    if (action.includes('BILL') || action.includes('INVOICE')) {
      return 'bg-blue-100 text-blue-800 border-blue-200';
    }
    if (action.includes('RATE')) {
      return 'bg-purple-100 text-purple-800 border-purple-200';
    }
    return 'bg-slate-100 text-slate-800 border-slate-200';
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-700" />
            Immutable Municipal Audit Trail & Governance Logs
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Traceable chronological history of rate ratifications, batch billings, payment verifications, and reversals
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-emerald-700 font-semibold bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
          <Shield className="w-4 h-4" />
          <span>Audit Log Integrity: Append-Only Immutable Ledger</span>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex flex-1 items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search action, staff member, details, entity ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <select
            value={selectedAction}
            onChange={(e) => setSelectedAction(e.target.value)}
            className="px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
          >
            <option value="all">All Action Types</option>
            {actions.map((act) => (
              <option key={act} value={act}>
                {act}
              </option>
            ))}
          </select>
        </div>

        <div className="text-slate-500">
          Showing <strong>{filtered.length}</strong> of <strong>{logs.length}</strong> recorded audit events
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
              <tr>
                <th className="px-4 py-3">Timestamp</th>
                <th className="px-4 py-3">Action Type</th>
                <th className="px-4 py-3">Staff Member & Role</th>
                <th className="px-4 py-3">Target Entity</th>
                <th className="px-4 py-3">Audit Details & Rationale</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-slate-400">
                    No matching audit records found.
                  </td>
                </tr>
              ) : (
                filtered.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="px-4 py-3 font-mono text-slate-500 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString([], {
                        dateStyle: 'short',
                        timeStyle: 'medium',
                      })}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span
                        className={`inline-block px-2 py-0.5 rounded font-mono font-bold text-[10px] uppercase border ${getActionColor(
                          log.action
                        )}`}
                      >
                        {log.action}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="font-semibold text-slate-900">{log.userName}</div>
                      <div className="text-[10px] uppercase font-bold text-slate-400">
                        {log.userRole.replace('_', ' ')}
                      </div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap font-mono text-slate-700">
                      <span className="text-[10px] uppercase font-semibold text-slate-400 block">
                        {log.entityType}
                      </span>
                      {log.entityId}
                    </td>
                    <td className="px-4 py-3 text-slate-800 leading-relaxed">
                      {log.details}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
