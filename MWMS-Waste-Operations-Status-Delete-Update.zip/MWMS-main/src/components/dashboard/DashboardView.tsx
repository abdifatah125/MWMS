import React from 'react';
import { DashboardStats, AppUser, AuditLog } from '../../types/index.js';
import {
  Building2,
  DollarSign,
  AlertCircle,
  Clock,
  TrendingUp,
  Receipt,
  FilePlus,
  ArrowRight,
  ShieldAlert,
  MapPin,
  CheckCircle2,
  CreditCard,
  UserCheck,
} from 'lucide-react';

interface DashboardViewProps {
  stats: DashboardStats | null;
  currentUser: AppUser | null;
  recentAuditLogs: AuditLog[];
  onNavigateTab: (tab: any) => void;
  onOpenRecordPayment: () => void;
  onOpenBillingModal: () => void;
  onOpenAddProperty: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  stats,
  currentUser,
  recentAuditLogs,
  onNavigateTab,
  onOpenRecordPayment,
  onOpenBillingModal,
  onOpenAddProperty,
}) => {
  if (!stats) {
    return (
      <div className="p-8 text-center text-xs text-slate-500">
        Loading executive municipal metrics...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome & Context Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 rounded-xl text-white shadow-sm border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs uppercase font-bold tracking-wider text-emerald-400">
              Executive Municipal Overview
            </span>
            <span className="text-[11px] text-slate-400">· October 2026 Operational Period</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            Municipal Waste Management Administration
          </h1>
          <p className="text-xs text-slate-300 mt-1">
            Active logged-in staff: <strong className="text-white">{currentUser?.fullName}</strong> ({currentUser?.role.replace('_', ' ')})
          </p>
        </div>

        {/* Action shortcut buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenRecordPayment}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Receipt className="w-4 h-4" />
            Record Payment
          </button>
          <button
            onClick={onOpenBillingModal}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <FilePlus className="w-4 h-4" />
            Generate Bills
          </button>
          <button
            onClick={onOpenAddProperty}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold shadow-xs transition-colors"
          >
            <Building2 className="w-4 h-4" />
            + Property
          </button>
        </div>
      </div>

      {/* Pending Digital Payments Notification Banner (If Any) */}
      {stats.pendingDigitalCount > 0 && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-100 flex items-center justify-center text-amber-700 flex-shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-amber-950">
                {stats.pendingDigitalCount} Digital Payment{stats.pendingDigitalCount > 1 ? 's' : ''} Awaiting Manual Verification (${stats.pendingDigitalAmount.toFixed(2)})
              </p>
              <p className="text-amber-800 text-[11px] mt-0.5">
                Pursuant to financial regulations, pending digital funds remain strictly excluded from confirmed revenue until verified by an authorized officer.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('payments')}
            className="flex-shrink-0 inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-700 hover:bg-amber-800 text-white font-medium text-xs transition-colors shadow-xs"
          >
            Review Queue
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 6 Core Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {/* Metric 1: Confirmed Revenue */}
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Confirmed Revenue</span>
            <div className="w-7 h-7 rounded-md bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-900 tracking-tight">
            ${stats.confirmedRevenue.toFixed(2)}
          </div>
          <p className="text-[10px] text-emerald-700 font-medium mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            Bank & Cash Verified
          </p>
        </div>

        {/* Metric 2: Outstanding Balance / Arrears */}
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Arrears / Balance</span>
            <div className="w-7 h-7 rounded-md bg-rose-50 text-rose-700 flex items-center justify-center">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-900 tracking-tight">
            ${stats.outstandingBalance.toFixed(2)}
          </div>
          <p className="text-[10px] text-slate-500 mt-1">
            Unpaid bills across all cycles
          </p>
        </div>

        {/* Metric 3: Total Invoiced */}
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Total Invoiced</span>
            <div className="w-7 h-7 rounded-md bg-blue-50 text-blue-700 flex items-center justify-center">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-900 tracking-tight">
            ${stats.monthlyBilledTotal.toFixed(2)}
          </div>
          <p className="text-[10px] text-slate-500 mt-1">
            Cumulative billing records
          </p>
        </div>

        {/* Metric 4: Registered Properties */}
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Properties</span>
            <div className="w-7 h-7 rounded-md bg-slate-100 text-slate-700 flex items-center justify-center">
              <Building2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-900 tracking-tight">
            {stats.totalProperties}
          </div>
          <p className="text-[10px] text-slate-500 mt-1">
            {stats.residentialCount} Res ($6) · {stats.commercialCount} Com
          </p>
        </div>

        {/* Metric 5: Collection Coverage Rate */}
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Collection Rate</span>
            <div className="w-7 h-7 rounded-md bg-cyan-50 text-cyan-700 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-900 tracking-tight">
            {stats.collectionRatePercent}%
          </div>
          <p className="text-[10px] text-slate-500 mt-1">
            Completed truck route stops
          </p>
        </div>

        {/* Metric 6: Open Complaints */}
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Open Complaints</span>
            <div className="w-7 h-7 rounded-md bg-amber-50 text-amber-700 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-900 tracking-tight">
            {stats.openComplaintsCount}
          </div>
          <p className="text-[10px] text-slate-500 mt-1">
            Active resident tickets
          </p>
        </div>
      </div>

      {/* Mid-Row: Zone Revenue Distribution & Arrears Aging */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Zone Breakdown Table / Card */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900">
                Waste Collection Performance by Municipal Zone
              </h3>
              <p className="text-xs text-slate-500">
                5 Active zones with registered property counts, billing, and collections
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('zones')}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              Manage Zones
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="px-3 py-2.5">Zone & Sector</th>
                  <th className="px-3 py-2.5 text-center">Properties</th>
                  <th className="px-3 py-2.5 text-right">Billed (USD)</th>
                  <th className="px-3 py-2.5 text-right">Collected (USD)</th>
                  <th className="px-3 py-2.5 text-right">Outstanding</th>
                  <th className="px-3 py-2.5 text-right">Recovery Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {stats.zoneStats.map((z) => {
                  const rate = z.billed > 0 ? ((z.collected / z.billed) * 100).toFixed(0) : '0';
                  return (
                    <tr key={z.zoneId} className="hover:bg-slate-50/50">
                      <td className="px-3 py-2.5 font-medium text-slate-900 flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {z.zoneName}
                      </td>
                      <td className="px-3 py-2.5 text-center font-mono text-slate-600">
                        {z.propertyCount}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono">
                        ${z.billed.toFixed(2)}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono text-emerald-700 font-semibold">
                        ${z.collected.toFixed(2)}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono text-rose-700">
                        ${z.outstanding.toFixed(2)}
                      </td>
                      <td className="px-3 py-2.5 text-right font-medium">
                        <span className="inline-block px-1.5 py-0.5 rounded text-[11px] bg-slate-100 text-slate-800">
                          {rate}%
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Arrears Aging & Payment Methods breakdown */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-5">
          <div>
            <h3 className="font-bold text-sm text-slate-900">Arrears Aging Analysis</h3>
            <p className="text-xs text-slate-500">Aging brackets for unpaid monthly fees</p>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-600">Current (Within Due Date)</span>
                <span className="font-semibold text-slate-900 font-mono">
                  ${stats.arrearsAging.current.toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-500 h-full rounded-full"
                  style={{
                    width: `${Math.min(
                      100,
                      (stats.arrearsAging.current / (stats.outstandingBalance || 1)) * 100
                    )}%`,
                  }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-600">1 – 30 Days Overdue</span>
                <span className="font-semibold text-amber-700 font-mono">
                  ${stats.arrearsAging.days30.toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-amber-500 h-full rounded-full"
                  style={{
                    width: `${Math.min(
                      100,
                      (stats.arrearsAging.days30 / (stats.outstandingBalance || 1)) * 100
                    )}%`,
                  }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-600">31 – 60 Days Overdue</span>
                <span className="font-semibold text-orange-700 font-mono">
                  ${stats.arrearsAging.days60.toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-orange-500 h-full rounded-full"
                  style={{
                    width: `${Math.min(
                      100,
                      (stats.arrearsAging.days60 / (stats.outstandingBalance || 1)) * 100
                    )}%`,
                  }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-600">60+ Days Overdue (Arrears)</span>
                <span className="font-semibold text-rose-700 font-mono">
                  ${stats.arrearsAging.days90Plus.toFixed(2)}
                </span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-rose-500 h-full rounded-full"
                  style={{
                    width: `${Math.min(
                      100,
                      (stats.arrearsAging.days90Plus / (stats.outstandingBalance || 1)) * 100
                    )}%`,
                  }}
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
              Payment Methods Reconciled
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-slate-500 block text-[10px]">Cash Revenue</span>
                <span className="font-bold text-slate-900 font-mono text-sm">
                  ${stats.revenueByMethod.cash.toFixed(2)}
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                <span className="text-slate-500 block text-[10px]">Digital Confirmed</span>
                <span className="font-bold text-emerald-700 font-mono text-sm">
                  ${stats.revenueByMethod.digitalConfirmed.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section: Recent Audit Trail Events */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-sm text-slate-900">Recent Immutable Audit Activity</h3>
            <p className="text-xs text-slate-500">
              Audit trail of financial and administrative actions recorded across the municipality
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('audit')}
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
          >
            View Full Audit Log
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          {recentAuditLogs.slice(0, 5).map((log) => (
            <div key={log.id} className="py-2.5 flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 flex-shrink-0" />
                <div>
                  <span className="font-mono text-[11px] font-semibold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded mr-2">
                    {log.action}
                  </span>
                  <span className="text-slate-800 font-medium">{log.details}</span>
                  <span className="text-slate-400 text-[11px] block mt-0.5">
                    By {log.userName} ({log.userRole.replace('_', ' ')})
                  </span>
                </div>
              </div>
              <span className="text-slate-400 font-mono text-[11px] flex-shrink-0">
                {new Date(log.timestamp).toLocaleDateString()} {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
