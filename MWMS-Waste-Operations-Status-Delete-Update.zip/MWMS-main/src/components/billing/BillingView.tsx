import React, { useState } from 'react';
import { Invoice, Zone, AppUser } from '../../types/index.js';
import {
  FileText,
  Plus,
  Search,
  Filter,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  X,
  CreditCard,
  ShieldCheck,
} from 'lucide-react';

interface BillingViewProps {
  invoices: Invoice[];
  zones: Zone[];
  currentUser: AppUser | null;
  onGenerateBatch: (billingMonth: string, zoneId?: string) => Promise<{
    generatedCount: number;
    skippedDuplicates: number;
  }>;
  onOpenRecordPayment: (invoice: Invoice) => void;
}

export const BillingView: React.FC<BillingViewProps> = ({
  invoices,
  zones,
  currentUser,
  onGenerateBatch,
  onOpenRecordPayment,
}) => {
  const [search, setSearch] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('all');
  const [selectedZone, setSelectedZone] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  // Batch Generation Modal state
  const [isBatchModalOpen, setIsBatchModalOpen] = useState(false);
  const [batchMonth, setBatchMonth] = useState('2026-11');
  const [batchZoneId, setBatchZoneId] = useState('all');
  const [batchSubmitting, setBatchSubmitting] = useState(false);
  const [batchResult, setBatchResult] = useState<{
    generatedCount: number;
    skippedDuplicates: number;
  } | null>(null);
  const [batchError, setBatchError] = useState('');

  // Extract unique months for filtering
  const months = Array.from(new Set(invoices.map((i) => i.billingMonth))).sort().reverse();

  const filtered = invoices.filter((inv) => {
    if (selectedMonth !== 'all' && inv.billingMonth !== selectedMonth) return false;
    if (selectedZone !== 'all' && inv.zoneId !== selectedZone) return false;
    if (selectedStatus !== 'all' && inv.status !== selectedStatus) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        inv.invoiceNumber.toLowerCase().includes(q) ||
        inv.propertyNumber.toLowerCase().includes(q) ||
        inv.ownerName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleRunBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setBatchError('');
    setBatchResult(null);
    setBatchSubmitting(true);
    try {
      const result = await onGenerateBatch(batchMonth, batchZoneId === 'all' ? undefined : batchZoneId);
      setBatchResult(result);
    } catch (err: any) {
      setBatchError(err.message || 'Batch generation failed');
    } finally {
      setBatchSubmitting(false);
    }
  };

  const getStatusBadge = (status: Invoice['status']) => {
    switch (status) {
      case 'paid':
        return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'partially_paid':
        return 'bg-blue-50 text-blue-800 border-blue-200';
      case 'unpaid':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'overdue':
        return 'bg-rose-50 text-rose-800 border-rose-200';
    }
  };

  const getZoneCode = (zoneId: string) => {
    return zones.find((z) => z.id === zoneId)?.code || zoneId;
  };

  const canGenerateBatch = currentUser?.role === 'admin' || currentUser?.role === 'finance_officer';

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-700" />
            Monthly Billing & Invoice Management
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Generate monthly billing cycles, prevent duplicate invoices, monitor balances and overdue accounts
          </p>
        </div>

        {canGenerateBatch ? (
          <button
            onClick={() => {
              setBatchResult(null);
              setBatchError('');
              setIsBatchModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            Generate Monthly Billing Cycle
          </button>
        ) : (
          <div
            title="Batch billing generation is restricted to Finance Officers and System Administrators"
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-100 text-slate-500 text-xs border border-slate-200 cursor-not-allowed self-start sm:self-auto"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
            <span>Billing Generation Restricted (Finance/Admin Only)</span>
          </div>
        )}
      </div>

      {!canGenerateBatch && (
        <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg text-xs text-slate-600 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-slate-500 shrink-0" />
          <span>
            <strong>Role Separation (Subration):</strong> Logged in as <em>{currentUser?.fullName} ({currentUser?.role})</em>. You have query access to review invoices, search properties, and accept payments; batch billing execution is reserved for Treasury Finance Officers and System Admins.
          </span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search invoice #, prop #, owner..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Month Filter */}
          <div>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
            >
              <option value="all">All Billing Months</option>
              {months.map((m) => (
                <option key={m} value={m}>
                  Billing Period: {m}
                </option>
              ))}
            </select>
          </div>

          {/* Zone Filter */}
          <div>
            <select
              value={selectedZone}
              onChange={(e) => setSelectedZone(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
            >
              <option value="all">All Collection Zones</option>
              {zones.map((z) => (
                <option key={z.id} value={z.id}>
                  {z.code}: {z.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
            >
              <option value="all">All Payment Statuses</option>
              <option value="unpaid">Unpaid</option>
              <option value="partially_paid">Partially Paid</option>
              <option value="paid">Fully Paid</option>
              <option value="overdue">Overdue</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
          <span>
            Displaying <strong className="text-slate-800">{filtered.length}</strong> of{' '}
            <strong className="text-slate-800">{invoices.length}</strong> issued municipal invoices
          </span>
          {(search || selectedMonth !== 'all' || selectedZone !== 'all' || selectedStatus !== 'all') && (
            <button
              onClick={() => {
                setSearch('');
                setSelectedMonth('all');
                setSelectedZone('all');
                setSelectedStatus('all');
              }}
              className="text-emerald-700 hover:text-emerald-800 font-medium"
            >
              Reset filters
            </button>
          )}
        </div>
      </div>

      {/* Invoices Ledger Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
              <tr>
                <th className="px-4 py-3">Invoice No.</th>
                <th className="px-4 py-3">Property</th>
                <th className="px-4 py-3">Zone & Category</th>
                <th className="px-4 py-3">Billing Cycle</th>
                <th className="px-4 py-3">Due Date</th>
                <th className="px-4 py-3 text-right">Invoiced (USD)</th>
                <th className="px-4 py-3 text-right">Paid (USD)</th>
                <th className="px-4 py-3 text-right">Balance Due</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={10} className="px-4 py-8 text-center text-slate-400">
                    No invoices matching current filter criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/50">
                    <td className="px-4 py-3 font-mono font-bold text-slate-900">
                      {inv.invoiceNumber}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-slate-900">{inv.propertyNumber}</div>
                      <div className="text-[11px] text-slate-500">{inv.ownerName}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-mono text-[11px] text-slate-600">
                        {getZoneCode(inv.zoneId)}
                      </div>
                      <div className="text-[10px] uppercase font-semibold text-slate-500">
                        {inv.propertyType} (${inv.rateApplied.toFixed(2)})
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono font-medium text-slate-800">
                      {inv.billingMonth}
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-600">
                      {inv.dueDate}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-semibold text-slate-900">
                      ${inv.amountDue.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-emerald-700 font-semibold">
                      ${inv.amountPaid.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold">
                      <span className={inv.balanceDue > 0 ? 'text-rose-700' : 'text-emerald-700'}>
                        ${inv.balanceDue.toFixed(2)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${getStatusBadge(
                          inv.status
                        )}`}
                      >
                        {inv.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {inv.balanceDue > 0 ? (
                        <button
                          onClick={() => onOpenRecordPayment(inv)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold text-[11px] transition-colors"
                        >
                          <DollarSign className="w-3 h-3 text-emerald-700" />
                          Pay
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400 font-medium">Settled</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Batch Generation Modal */}
      {isBatchModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm">Batch Monthly Invoice Generation</h3>
              </div>
              <button
                onClick={() => setIsBatchModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleRunBatch} className="p-6 space-y-4 text-xs">
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-950 space-y-1">
                <div className="flex items-center gap-1.5 font-bold">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Mandatory Duplicate Prevention Invariant
                </div>
                <p className="text-[11px] text-emerald-900 leading-relaxed">
                  The system strictly verifies that only one invoice per active property is generated per billing month.
                  Properties that have already been billed for the selected cycle will be safely skipped.
                </p>
              </div>

              {batchError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg">
                  {batchError}
                </div>
              )}

              {batchResult && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 space-y-2">
                  <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                    Billing Cycle Generation Completed
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2 bg-white rounded border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">New Invoices Generated</span>
                      <span className="font-bold font-mono text-base text-slate-900">
                        {batchResult.generatedCount}
                      </span>
                    </div>
                    <div className="p-2 bg-white rounded border border-slate-200">
                      <span className="text-slate-500 block text-[10px]">Duplicates Skipped</span>
                      <span className="font-bold font-mono text-base text-amber-700">
                        {batchResult.skippedDuplicates}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Billing Cycle Month (YYYY-MM) *
                </label>
                <input
                  type="month"
                  required
                  value={batchMonth}
                  onChange={(e) => setBatchMonth(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Target Municipal Zone
                </label>
                <select
                  value={batchZoneId}
                  onChange={(e) => setBatchZoneId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                >
                  <option value="all">All 5 Collection Zones</option>
                  {zones.map((z) => (
                    <option key={z.id} value={z.id}>
                      {z.code}: {z.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsBatchModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  {batchResult ? 'Done' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={batchSubmitting}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {batchSubmitting ? 'Generating Invoices...' : 'Execute Batch Generation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
