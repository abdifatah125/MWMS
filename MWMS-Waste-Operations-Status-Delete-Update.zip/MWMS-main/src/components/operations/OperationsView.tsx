import React, { useState } from 'react';
import {
  Truck,
  Route,
  CollectionSchedule,
  CollectionRecord,
  CustomerComplaint,
  Property,
  Zone,
  AppUser,
} from '../../types/index.js';
import {
  Truck as TruckIcon,
  Navigation,
  Calendar,
  ClipboardList,
  AlertOctagon,
  CheckCircle2,
  XCircle,
  Plus,
  Clock,
  Check,
  Search,
  Filter,
  X,
  FileCheck,
} from 'lucide-react';

interface OperationsViewProps {
  trucks: Truck[];
  routes: Route[];
  schedules: CollectionSchedule[];
  records: CollectionRecord[];
  complaints: CustomerComplaint[];
  properties: Property[];
  zones: Zone[];
  currentUser: AppUser | null;
  onAddTruck: (truck: Omit<Truck, 'id'>) => Promise<void>;
  onAddRoute: (route: Omit<Route, 'id'>) => Promise<void>;
  onAddSchedule: (schedule: Omit<CollectionSchedule, 'id' | 'stopsCompleted'>) => Promise<void>;
  onLogCollection: (record: {
    scheduleId: string;
    propertyId: string;
    status: 'collected' | 'missed';
    missedReason?: string;
    notes?: string;
    wasteWeightKg?: number;
  }) => Promise<void>;
  onAddComplaint: (complaint: {
    propertyId: string;
    complainantName: string;
    phone: string;
    category: CustomerComplaint['category'];
    description: string;
    priority: CustomerComplaint['priority'];
  }) => Promise<void>;
  onResolveComplaint: (id: string, notes: string) => Promise<void>;
  onOperationAction: (action: string, id: string, status?: string) => Promise<void>;
}

export const OperationsView: React.FC<OperationsViewProps> = ({
  trucks,
  routes,
  schedules,
  records,
  complaints,
  properties,
  zones,
  currentUser,
  onAddTruck,
  onAddRoute,
  onAddSchedule,
  onLogCollection,
  onAddComplaint,
  onResolveComplaint,
  onOperationAction,
}) => {
  const [activeTab, setActiveTab] = useState<'schedules' | 'trucks' | 'routes' | 'fieldLogs' | 'complaints'>('schedules');

  const canManageOps = currentUser?.role === 'admin' || currentUser?.role === 'collection_manager';
  const runOperationAction = async (action: string, id: string, status?: string) => { try { await onOperationAction(action, id, status); } catch (err: any) { alert(err.message || 'Operation failed'); } };
  const deleteOperation = (action: string, id: string, label: string) => { if (window.confirm(`Delete ${label}? This action will be recorded in the Audit Trail.`)) void runOperationAction(action, id); };
  const canLogCollection = currentUser?.role === 'admin' || currentUser?.role === 'collection_manager' || currentUser?.role === 'field_collector';

  // Field log modal state
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [selectedScheduleId, setSelectedScheduleId] = useState(schedules[0]?.id || '');
  const [selectedPropertyId, setSelectedPropertyId] = useState(properties[0]?.id || '');
  const [logStatus, setLogStatus] = useState<'collected' | 'missed'>('collected');
  const [missedReason, setMissedReason] = useState('Gate locked / curb inaccessible');
  const [wasteWeight, setWasteWeight] = useState<number>(20.0);
  const [logNotes, setLogNotes] = useState('');
  const [loggingSubmitting, setLoggingSubmitting] = useState(false);

  // New Complaint modal state
  const [isComplaintModalOpen, setIsComplaintModalOpen] = useState(false);
  const [compPropertyId, setCompPropertyId] = useState(properties[0]?.id || '');
  const [compName, setCompName] = useState('');
  const [compPhone, setCompPhone] = useState('+1 (555) ');
  const [compCategory, setCompCategory] = useState<CustomerComplaint['category']>('missed_collection');
  const [compPriority, setCompPriority] = useState<CustomerComplaint['priority']>('medium');
  const [compDesc, setCompDesc] = useState('');
  const [compSubmitting, setCompSubmitting] = useState(false);

  // Resolve Complaint modal
  const [resolvingComp, setResolvingComp] = useState<CustomerComplaint | null>(null);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [resolvingSubmitting, setResolvingSubmitting] = useState(false);

  // New Schedule modal
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);

  // New truck and route forms
  const [isTruckModalOpen, setIsTruckModalOpen] = useState(false);
  const [truckPlate, setTruckPlate] = useState('');
  const [truckModel, setTruckModel] = useState('');
  const [truckCapacity, setTruckCapacity] = useState('10');
  const [truckZone, setTruckZone] = useState(zones[0]?.id || '');
  const [truckDriver, setTruckDriver] = useState('');
  const [truckStatus, setTruckStatus] = useState<Truck['status']>('active');
  const [truckSubmitting, setTruckSubmitting] = useState(false);

  const [isRouteModalOpen, setIsRouteModalOpen] = useState(false);
  const [routeName, setRouteName] = useState('');
  const [routeZone, setRouteZone] = useState(zones[0]?.id || '');
  const [routeStart, setRouteStart] = useState('');
  const [routeEnd, setRouteEnd] = useState('');
  const [routeStops, setRouteStops] = useState('20');
  const [routeFrequency, setRouteFrequency] = useState('Daily');
  const [routeSubmitting, setRouteSubmitting] = useState(false);
  const [newSchDate, setNewSchDate] = useState('2026-10-21');
  const [newSchZone, setNewSchZone] = useState(zones[0]?.id || 'zone-1');
  const [newSchRoute, setNewSchRoute] = useState(routes[0]?.id || '');
  const [newSchTruck, setNewSchTruck] = useState(trucks[0]?.id || '');
  const [newSchCollector, setNewSchCollector] = useState('usr-5');
  const [newSchStops, setNewSchStops] = useState(45);
  const [newSchNotes, setNewSchNotes] = useState('');

  const handleCreateTruck = async (e: React.FormEvent) => {
    e.preventDefault();
    setTruckSubmitting(true);
    try {
      await onAddTruck({
        plateNumber: truckPlate.trim().toUpperCase(),
        model: truckModel.trim(),
        capacityTons: Number(truckCapacity),
        assignedZoneId: truckZone || undefined,
        driverName: truckDriver.trim() || undefined,
        status: truckStatus,
      });
      setIsTruckModalOpen(false);
      setTruckPlate(''); setTruckModel(''); setTruckCapacity('10'); setTruckDriver('');
      alert('Truck added successfully.');
    } catch (err: any) {
      alert(err.message || 'Failed to add truck');
    } finally {
      setTruckSubmitting(false);
    }
  };

  const handleCreateRoute = async (e: React.FormEvent) => {
    e.preventDefault();
    setRouteSubmitting(true);
    try {
      await onAddRoute({
        name: routeName.trim(), zoneId: routeZone,
        startPoint: routeStart.trim(), endPoint: routeEnd.trim(),
        estimatedStops: Number(routeStops), frequency: routeFrequency,
      });
      setIsRouteModalOpen(false);
      setRouteName(''); setRouteStart(''); setRouteEnd(''); setRouteStops('20');
      alert('Collection route added successfully.');
    } catch (err: any) {
      alert(err.message || 'Failed to add route');
    } finally {
      setRouteSubmitting(false);
    }
  };

  const handleCreateSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onAddSchedule({
        date: newSchDate,
        zoneId: newSchZone,
        zoneName: zones.find((z) => z.id === newSchZone)?.name || 'Zone',
        routeId: newSchRoute,
        routeName: routes.find((r) => r.id === newSchRoute)?.name || 'Route',
        truckId: newSchTruck,
        truckPlate: trucks.find((t) => t.id === newSchTruck)?.plateNumber || 'Truck',
        collectorId: newSchCollector,
        collectorName: 'Tariq Al-Mansoor',
        status: 'scheduled',
        totalStops: Number(newSchStops),
        notes: newSchNotes,
      });
      setIsScheduleModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Failed to create schedule');
    }
  };

  const handleSaveLog = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoggingSubmitting(true);
    try {
      await onLogCollection({
        scheduleId: selectedScheduleId,
        propertyId: selectedPropertyId,
        status: logStatus,
        missedReason: logStatus === 'missed' ? missedReason : undefined,
        notes: logNotes,
        wasteWeightKg: logStatus === 'collected' ? Number(wasteWeight) : 0,
      });
      setIsLogModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Failed to log record');
    } finally {
      setLoggingSubmitting(false);
    }
  };

  const handleSaveComplaint = async (e: React.FormEvent) => {
    e.preventDefault();
    setCompSubmitting(true);
    try {
      await onAddComplaint({
        propertyId: compPropertyId,
        complainantName: compName,
        phone: compPhone,
        category: compCategory,
        priority: compPriority,
        description: compDesc,
      });
      setIsComplaintModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Failed to register complaint');
    } finally {
      setCompSubmitting(false);
    }
  };

  const handleExecuteResolve = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resolvingComp) return;
    setResolvingSubmitting(true);
    try {
      await onResolveComplaint(resolvingComp.id, resolutionNotes);
      setResolvingComp(null);
      setResolutionNotes('');
    } catch (err: any) {
      alert(err.message || 'Failed to resolve complaint');
    } finally {
      setResolvingSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <TruckIcon className="w-5 h-5 text-emerald-700" />
            Waste Collection Operations & Logistics Hub
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage dispatch schedules, compactor trucks, collection routes, field completion logs, and citizen complaints
          </p>
        </div>

        <div className="flex items-center gap-2">
          {canLogCollection ? (
            <button
              onClick={() => setIsLogModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors"
            >
              <ClipboardList className="w-4 h-4" />
              Log Field Collection
            </button>
          ) : (
            <div
              title="Only Sanitation Field Crews and Operations Managers can log waste collections"
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-100 text-slate-500 text-xs border border-slate-200 cursor-not-allowed"
            >
              <ClipboardList className="w-3.5 h-3.5 text-slate-400" />
              <span>Field Logs (Field Crew Only)</span>
            </div>
          )}
          <button
            onClick={() => setIsComplaintModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <AlertOctagon className="w-4 h-4 text-rose-400" />
            Log Complaint
          </button>
        </div>
      </div>

      {!canManageOps && (
        <div className="p-3 bg-slate-100 border border-slate-200 rounded-lg text-xs text-slate-600 flex items-center gap-2">
          <TruckIcon className="w-4 h-4 text-slate-500 shrink-0" />
          <span>
            <strong>Role Separation (Subration):</strong> Logged in as <em>{currentUser?.fullName} ({currentUser?.role})</em>. Fleet compactor modifications, route configurations, and schedule dispatches are managed by the Collection Logistics Department and System Administrators.
          </span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-2 overflow-x-auto pb-1 text-xs">
        <button
          onClick={() => setActiveTab('schedules')}
          className={`px-3.5 py-2 font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
            activeTab === 'schedules'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          Collection Schedules & Dispatch ({schedules.length})
        </button>

        <button
          onClick={() => setActiveTab('trucks')}
          className={`px-3.5 py-2 font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
            activeTab === 'trucks'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <TruckIcon className="w-3.5 h-3.5" />
          Fleet Compactor Trucks ({trucks.length})
        </button>

        <button
          onClick={() => setActiveTab('routes')}
          className={`px-3.5 py-2 font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
            activeTab === 'routes'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Navigation className="w-3.5 h-3.5" />
          Collection Routes ({routes.length})
        </button>

        <button
          onClick={() => setActiveTab('fieldLogs')}
          className={`px-3.5 py-2 font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
            activeTab === 'fieldLogs'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <FileCheck className="w-3.5 h-3.5" />
          Completed / Missed Logs ({records.length})
        </button>

        <button
          onClick={() => setActiveTab('complaints')}
          className={`px-3.5 py-2 font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
            activeTab === 'complaints'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <AlertOctagon className="w-3.5 h-3.5 text-rose-500" />
          Customer Complaints ({complaints.length})
        </button>
      </div>

      {/* Tab 1: Schedules */}
      {activeTab === 'schedules' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-sm text-slate-900">Weekly Route Dispatch Timetable</h3>
            {canManageOps && <button
              onClick={() => setIsScheduleModalOpen(true)}
              className="inline-flex items-center gap-1 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Schedule
            </button>}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {schedules.map((sch) => {
              const pct = sch.totalStops > 0 ? Math.round((sch.stopsCompleted / sch.totalStops) * 100) : 0;
              return (
                <div
                  key={sch.id}
                  className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[11px] font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                      {sch.date}
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${
                        sch.status === 'completed'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : sch.status === 'in_progress'
                          ? 'bg-blue-50 text-blue-800 border-blue-200'
                          : 'bg-amber-50 text-amber-800 border-amber-200'
                      }`}
                    >
                      {sch.status.replace('_', ' ')}
                    </span>
                  </div>
                  {canManageOps && <div className="flex items-center gap-2"><label className="text-[10px] text-slate-500">Edit status</label><select aria-label={`Edit schedule ${sch.id} status`} value={sch.status} onChange={(e) => void runOperationAction('schedule-status', sch.id, e.target.value)} className="text-[11px] border rounded px-2 py-1"><option value="scheduled">Scheduled</option><option value="in_progress">In Progress</option><option value="completed">Completed</option><option value="delayed">Delayed</option></select><button onClick={() => deleteOperation('schedule-delete', sch.id, 'this schedule')} className="text-rose-600 hover:text-rose-800 text-[11px] font-semibold">Delete</button></div>}

                  <div>
                    <h4 className="font-bold text-xs text-slate-900">{sch.routeName}</h4>
                    <p className="text-[11px] text-emerald-700 font-medium">{sch.zoneName}</p>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-600 pt-2 border-t border-slate-100">
                    <div className="flex justify-between">
                      <span>Compactor Truck:</span>
                      <strong className="font-mono text-slate-900">{sch.truckPlate}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Field Collector:</span>
                      <strong className="text-slate-900">{sch.collectorName}</strong>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100">
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="text-slate-500">Pick-up Progress</span>
                      <span className="font-bold text-slate-900">
                        {sch.stopsCompleted} / {sch.totalStops} stops ({pct}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-emerald-600 h-full rounded-full transition-all"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Trucks */}
      {activeTab === 'trucks' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-3">
            <h3 className="font-bold text-sm text-slate-900">Fleet Compactor Truck Register</h3>
            {canManageOps && <button onClick={() => setIsTruckModalOpen(true)} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold"><Plus className="w-4 h-4" /> Add Truck</button>}
          </div>
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
              <tr>
                <th className="px-4 py-3">Plate No.</th>
                <th className="px-4 py-3">Compactor Model</th>
                <th className="px-4 py-3 text-right">Capacity (Tons)</th>
                <th className="px-4 py-3">Assigned Zone</th>
                <th className="px-4 py-3">Designated Driver</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {trucks.map((t) => (
                <tr key={t.id} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 font-mono font-bold text-slate-900">
                    {t.plateNumber}
                  </td>
                  <td className="px-4 py-3 font-medium text-slate-900">{t.model}</td>
                  <td className="px-4 py-3 text-right font-mono font-semibold">
                    {t.capacityTons.toFixed(1)}t
                  </td>
                  <td className="px-4 py-3 text-slate-600 font-mono">
                    {zones.find((z) => z.id === t.assignedZoneId)?.name || 'Fleet Reserve'}
                  </td>
                  <td className="px-4 py-3">{t.driverName || 'Rotational Crew'}</td>
                  <td className="px-4 py-3 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                        t.status === 'active'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-amber-50 text-amber-800 border-amber-200'
                      }`}
                    >
                      {t.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center"><div className="flex items-center justify-center gap-2">{canManageOps && <select aria-label={`Edit truck ${t.plateNumber} status`} value={t.status} onChange={(e) => void runOperationAction('truck-status', t.id, e.target.value)} className="border rounded px-2 py-1 text-[11px]"><option value="active">Active</option><option value="maintenance">Maintenance</option><option value="deputed">Deputed</option></select>}{canManageOps && <button onClick={() => deleteOperation('truck-delete', t.id, `truck ${t.plateNumber}`)} className="text-rose-600 hover:text-rose-800 font-semibold">Delete</button>}</div></td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </div>
      )}

      {/* Tab 3: Routes */}
      {activeTab === 'routes' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-3">
            <h3 className="font-bold text-sm text-slate-900">Collection Route Register</h3>
            {canManageOps && <button onClick={() => setIsRouteModalOpen(true)} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold"><Plus className="w-4 h-4" /> Add Route</button>}
          </div>
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
              <tr>
                <th className="px-4 py-3">Route Name</th>
                <th className="px-4 py-3">Zone</th>
                <th className="px-4 py-3">Start & End Depot</th>
                <th className="px-4 py-3 text-center">Estimated Stops</th>
                <th className="px-4 py-3">Frequency</th>
                <th className="px-4 py-3 text-center">Status</th><th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {routes.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 font-bold text-slate-900">{r.name}</td>
                  <td className="px-4 py-3 font-mono text-emerald-800">
                    {zones.find((z) => z.id === r.zoneId)?.name || r.zoneId}
                  </td>
                  <td className="px-4 py-3 text-slate-600">
                    {r.startPoint} ➔ {r.endPoint}
                  </td>
                  <td className="px-4 py-3 text-center font-mono font-bold text-slate-900">
                    {r.estimatedStops}
                  </td>
                  <td className="px-4 py-3 font-medium text-slate-700">{r.frequency}</td>
                  <td className="px-4 py-3 text-center">{canManageOps ? <select aria-label={`Edit route ${r.name} status`} value={r.status || 'active'} onChange={(e) => void runOperationAction('route-status', r.id, e.target.value)} className="border rounded px-2 py-1 text-[11px]"><option value="active">Active</option><option value="inactive">Inactive</option></select> : (r.status || 'active')}</td>
                  <td className="px-4 py-3 text-center">{canManageOps && <button onClick={() => deleteOperation('route-delete', r.id, `route ${r.name}`)} className="text-rose-600 hover:text-rose-800 font-semibold">Delete</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </div>
      )}

      {/* Tab 4: Field Logs */}
      {activeTab === 'fieldLogs' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-3">
            <h3 className="font-bold text-sm text-slate-900">Completed / Missed Collection Records</h3>
            {canLogCollection && <button onClick={() => setIsLogModalOpen(true)} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold"><Plus className="w-4 h-4" /> Add Collection Log</button>}
          </div>
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
              <tr>
                <th className="px-4 py-3">Property No.</th>
                <th className="px-4 py-3">Address</th>
                <th className="px-4 py-3 text-center">Collection Status</th>
                <th className="px-4 py-3 text-right">Waste (Kg)</th>
                <th className="px-4 py-3">Collector Notes & Reasons</th>
                <th className="px-4 py-3">Logged By</th>
                <th className="px-4 py-3">Time</th><th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {records.map((rec) => (
                <tr key={rec.id} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 font-mono font-bold text-slate-900">
                    {rec.propertyNumber}
                  </td>
                  <td className="px-4 py-3 text-slate-700">{rec.address}</td>
                  <td className="px-4 py-3 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                        rec.status === 'collected'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-rose-50 text-rose-800 border-rose-200'
                      }`}
                    >
                      {rec.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-semibold">
                    {rec.wasteWeightKg ? `${rec.wasteWeightKg.toFixed(1)} kg` : '—'}
                  </td>
                  <td className="px-4 py-3 text-slate-600 max-w-xs">
                    {rec.missedReason && (
                      <span className="font-semibold text-rose-700 block">
                        Reason: {rec.missedReason}
                      </span>
                    )}
                    {rec.notes}
                  </td>
                  <td className="px-4 py-3 text-slate-600">{rec.recordedBy}</td>
                  <td className="px-4 py-3 text-slate-400 font-mono text-[11px]">
                    {new Date(rec.recordedAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                  </td>
                  <td className="px-4 py-3 text-center"><div className="flex items-center justify-center gap-2">{canManageOps && <select aria-label={`Edit collection status ${rec.id}`} value={rec.status} onChange={(e) => void runOperationAction('record-status', rec.id, e.target.value)} className="border rounded px-2 py-1 text-[11px]"><option value="collected">Collected</option><option value="missed">Missed</option></select>}{canManageOps && <button onClick={() => deleteOperation('record-delete', rec.id, `collection log for ${rec.propertyNumber}`)} className="text-rose-600 hover:text-rose-800 font-semibold">Delete</button>}</div></td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </div>
      )}

      {/* Tab 5: Customer Complaints */}
      {activeTab === 'complaints' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-3">
            <h3 className="font-bold text-sm text-slate-900">Customer Complaint Register</h3>
            <button onClick={() => setIsComplaintModalOpen(true)} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold"><Plus className="w-4 h-4" /> Add Complaint</button>
          </div>
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
              <tr>
                <th className="px-4 py-3">Ticket #</th>
                <th className="px-4 py-3">Property</th>
                <th className="px-4 py-3">Complainant</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Description</th>
                <th className="px-4 py-3 text-center">Priority</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {complaints.map((c) => (
                <tr key={c.id} className="hover:bg-slate-50/50">
                  <td className="px-4 py-3 font-mono font-bold text-slate-900">
                    {c.complaintNumber}
                  </td>
                  <td className="px-4 py-3 font-mono text-slate-800">{c.propertyNumber}</td>
                  <td className="px-4 py-3">
                    <div className="font-semibold text-slate-900">{c.complainantName}</div>
                    <div className="text-[11px] text-slate-400">{c.phone}</div>
                  </td>
                  <td className="px-4 py-3 capitalize text-slate-700 font-medium">
                    {c.category.replace('_', ' ')}
                  </td>
                  <td className="px-4 py-3 text-slate-600 max-w-xs">
                    {c.description}
                    {c.resolutionNotes && (
                      <div className="text-[11px] text-emerald-800 bg-emerald-50 p-1 rounded mt-1 border border-emerald-200">
                        Resolved: {c.resolutionNotes}
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span
                      className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                        c.priority === 'urgent'
                          ? 'bg-rose-100 text-rose-800'
                          : c.priority === 'high'
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {c.priority}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">{canManageOps ? <select aria-label={`Edit complaint ${c.complaintNumber} status`} value={c.status} onChange={(e) => void runOperationAction('complaint-status', c.id, e.target.value)} className="border rounded px-2 py-1 text-[11px]"><option value="open">Open</option><option value="in_progress">In Progress</option><option value="resolved">Resolved</option></select> : <span>{c.status.replace('_', ' ')}</span>}</td>
                  <td className="px-4 py-3 text-center">
                    {c.status !== 'resolved' ? (
                      <button
                        onClick={() => {
                          setResolvingComp(c);
                          setResolutionNotes('');
                        }}
                        className="px-2.5 py-1 rounded bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-[11px] transition-colors"
                      >
                        Resolve
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-400">Closed</span>
                    )}
                    {canManageOps && <button onClick={() => deleteOperation('complaint-delete', c.id, `complaint ${c.complaintNumber}`)} className="ml-2 text-rose-600 hover:text-rose-800 font-semibold text-[11px]">Delete</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </div>
      )}

      {/* Add Truck Modal */}
      {isTruckModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white"><h3 className="font-bold text-sm">Register Compactor Truck</h3><button type="button" onClick={() => setIsTruckModalOpen(false)} className="p-1 text-slate-400 hover:text-white rounded"><X className="w-4 h-4" /></button></div>
            <form onSubmit={handleCreateTruck} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><label className="block font-semibold text-slate-700 mb-1">Plate Number *</label><input required value={truckPlate} onChange={e => setTruckPlate(e.target.value)} placeholder="e.g. MOG-SAN-105" className="w-full px-3 py-2 rounded-lg border border-slate-300" /></div>
                <div><label className="block font-semibold text-slate-700 mb-1">Compactor Model *</label><input required value={truckModel} onChange={e => setTruckModel(e.target.value)} placeholder="Manufacturer / model" className="w-full px-3 py-2 rounded-lg border border-slate-300" /></div>
                <div><label className="block font-semibold text-slate-700 mb-1">Capacity (tons) *</label><input required type="number" min="0.1" step="0.1" value={truckCapacity} onChange={e => setTruckCapacity(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300" /></div>
                <div><label className="block font-semibold text-slate-700 mb-1">Assigned Zone</label><select value={truckZone} onChange={e => setTruckZone(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"><option value="">Fleet Reserve / Unassigned</option>{zones.map(z => <option key={z.id} value={z.id}>{z.code}: {z.name}</option>)}</select></div>
                <div><label className="block font-semibold text-slate-700 mb-1">Designated Driver</label><input value={truckDriver} onChange={e => setTruckDriver(e.target.value)} placeholder="Driver name" className="w-full px-3 py-2 rounded-lg border border-slate-300" /></div>
                <div><label className="block font-semibold text-slate-700 mb-1">Status *</label><select value={truckStatus} onChange={e => setTruckStatus(e.target.value as Truck['status'])} className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"><option value="active">Active</option><option value="maintenance">Maintenance</option><option value="deputed">Deputed</option></select></div>
              </div>
              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2"><button type="button" onClick={() => setIsTruckModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button><button disabled={truckSubmitting} type="submit" className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white rounded-lg font-semibold">{truckSubmitting ? 'Saving...' : 'Save Truck'}</button></div>
            </form>
          </div>
        </div>
      )}

      {/* Add Route Modal */}
      {isRouteModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white"><h3 className="font-bold text-sm">Create Collection Route</h3><button type="button" onClick={() => setIsRouteModalOpen(false)} className="p-1 text-slate-400 hover:text-white rounded"><X className="w-4 h-4" /></button></div>
            <form onSubmit={handleCreateRoute} className="p-6 space-y-4 text-xs">
              <div><label className="block font-semibold text-slate-700 mb-1">Route Name *</label><input required value={routeName} onChange={e => setRouteName(e.target.value)} placeholder="e.g. Hodan Express Route" className="w-full px-3 py-2 rounded-lg border border-slate-300" /></div>
              <div><label className="block font-semibold text-slate-700 mb-1">Zone *</label><select required value={routeZone} onChange={e => setRouteZone(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white">{zones.map(z => <option key={z.id} value={z.id}>{z.code}: {z.name}</option>)}</select></div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3"><div><label className="block font-semibold text-slate-700 mb-1">Start Depot / Point *</label><input required value={routeStart} onChange={e => setRouteStart(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300" /></div><div><label className="block font-semibold text-slate-700 mb-1">End Depot / Point *</label><input required value={routeEnd} onChange={e => setRouteEnd(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300" /></div></div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3"><div><label className="block font-semibold text-slate-700 mb-1">Estimated Stops *</label><input required type="number" min="1" value={routeStops} onChange={e => setRouteStops(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300" /></div><div><label className="block font-semibold text-slate-700 mb-1">Collection Frequency *</label><select value={routeFrequency} onChange={e => setRouteFrequency(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"><option>Daily</option><option>Every weekday</option><option>Weekly</option><option>Twice weekly</option><option>Monthly</option></select></div></div>
              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2"><button type="button" onClick={() => setIsRouteModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button><button disabled={routeSubmitting} type="submit" className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-60 text-white rounded-lg font-semibold">{routeSubmitting ? 'Saving...' : 'Save Route'}</button></div>
            </form>
          </div>
        </div>
      )}

      {/* Log Field Collection Modal */}
      {isLogModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <h3 className="font-bold text-sm">Record Field Collection Event</h3>
              <button
                onClick={() => setIsLogModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveLog} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Assigned Collection Schedule *
                </label>
                <select
                  value={selectedScheduleId}
                  onChange={(e) => setSelectedScheduleId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                >
                  {schedules.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.date} · {s.routeName} ({s.truckPlate})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Target Municipal Property *
                </label>
                <select
                  value={selectedPropertyId}
                  onChange={(e) => setSelectedPropertyId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                >
                  {properties.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.propertyNumber} — {p.address} ({p.ownerName})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Collection Status *</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setLogStatus('collected')}
                    className={`p-2.5 rounded-lg border text-center font-semibold transition-all ${
                      logStatus === 'collected'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    ✓ Successfully Collected
                  </button>
                  <button
                    type="button"
                    onClick={() => setLogStatus('missed')}
                    className={`p-2.5 rounded-lg border text-center font-semibold transition-all ${
                      logStatus === 'missed'
                        ? 'bg-rose-50 border-rose-500 text-rose-800'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    ✕ Missed / Inaccessible
                  </button>
                </div>
              </div>

              {logStatus === 'collected' ? (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Waste Scale Weight (Kg)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={wasteWeight}
                    onChange={(e) => setWasteWeight(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              ) : (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Reason for Missed Collection *
                  </label>
                  <select
                    value={missedReason}
                    onChange={(e) => setMissedReason(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                  >
                    <option value="Gate locked / private alley inaccessible">Gate locked / private alley inaccessible</option>
                    <option value="Bin obstructed by parked vehicles">Bin obstructed by parked vehicles</option>
                    <option value="Contaminated hazardous items in waste">Contaminated hazardous items in waste</option>
                    <option value="Bin not placed out by resident">Bin not placed out by resident</option>
                    <option value="Severe road construction blockage">Severe road construction blockage</option>
                  </select>
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Field Collector Notes</label>
                <input
                  type="text"
                  value={logNotes}
                  onChange={(e) => setLogNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  placeholder="e.g. Card placed in post box"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsLogModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loggingSubmitting}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {loggingSubmitting ? 'Logging...' : 'Save Collection Record'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Log Complaint Modal */}
      {isComplaintModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <h3 className="font-bold text-sm">Register Resident Complaint</h3>
              <button
                onClick={() => setIsComplaintModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveComplaint} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Associated Property *
                </label>
                <select
                  value={compPropertyId}
                  onChange={(e) => setCompPropertyId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                >
                  {properties.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.propertyNumber} — {p.ownerName} ({p.address})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Complainant Name *</label>
                  <input
                    type="text"
                    required
                    value={compName}
                    onChange={(e) => setCompName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                    placeholder="Resident name"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={compPhone}
                    onChange={(e) => setCompPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={compCategory}
                    onChange={(e) => setCompCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                  >
                    <option value="missed_collection">Missed Collection</option>
                    <option value="damaged_bin">Damaged Bin</option>
                    <option value="illegal_dumping">Illegal Dumping</option>
                    <option value="staff_conduct">Staff Conduct</option>
                    <option value="billing_query">Billing Query</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Priority</label>
                  <select
                    value={compPriority}
                    onChange={(e) => setCompPriority(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description *</label>
                <textarea
                  required
                  rows={3}
                  value={compDesc}
                  onChange={(e) => setCompDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  placeholder="Detail the issue reported by the citizen..."
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsComplaintModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={compSubmitting}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {compSubmitting ? 'Logging...' : 'Register Complaint'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Resolve Complaint Modal */}
      {resolvingComp && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <h3 className="font-bold text-sm">Resolve Ticket {resolvingComp.complaintNumber}</h3>
              <button
                onClick={() => setResolvingComp(null)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleExecuteResolve} className="p-6 space-y-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <div>Property: <strong>{resolvingComp.propertyNumber}</strong></div>
                <div>Category: <span className="capitalize">{resolvingComp.category.replace('_', ' ')}</span></div>
                <div className="text-slate-600 mt-1">"{resolvingComp.description}"</div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Resolution Action & Outcome Notes *
                </label>
                <textarea
                  required
                  rows={3}
                  value={resolutionNotes}
                  onChange={(e) => setResolutionNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  placeholder="e.g. Sent secondary compaction truck for morning pickup; resident notified."
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setResolvingComp(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={resolvingSubmitting}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {resolvingSubmitting ? 'Resolving...' : 'Mark Complaint as Resolved'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Schedule Modal */}
      {isScheduleModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <h3 className="font-bold text-sm">Schedule Collection Dispatch</h3>
              <button
                onClick={() => setIsScheduleModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSchedule} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Dispatch Date *</label>
                  <input
                    type="date"
                    required
                    value={newSchDate}
                    onChange={(e) => setNewSchDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target Zone *</label>
                  <select
                    value={newSchZone}
                    onChange={(e) => setNewSchZone(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                  >
                    {zones.map((z) => (
                      <option key={z.id} value={z.id}>
                        {z.code}: {z.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Collection Route *</label>
                <select
                  value={newSchRoute}
                  onChange={(e) => setNewSchRoute(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                >
                  {routes.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Assigned Truck *</label>
                  <select
                    value={newSchTruck}
                    onChange={(e) => setNewSchTruck(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                  >
                    {trucks.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.plateNumber} ({t.capacityTons}t)
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Planned Stops</label>
                  <input
                    type="number"
                    min="5"
                    value={newSchStops}
                    onChange={(e) => setNewSchStops(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Shift Instructions</label>
                <input
                  type="text"
                  value={newSchNotes}
                  onChange={(e) => setNewSchNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  placeholder="e.g. Prioritize high-street commercial roll-off units"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsScheduleModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold shadow-xs"
                >
                  Save Dispatch Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
