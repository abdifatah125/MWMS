import React, { useState } from 'react';
import { X, Database, ShieldCheck, Check, Copy, Code, FileText, Server } from 'lucide-react';

interface ArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureModal: React.FC<ArchitectureModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'schema' | 'roles' | 'localSetup'>('overview');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const copySqlSnippet = () => {
    navigator.clipboard.writeText(`psql -U mwms_admin -d mwms_db -f migrations/001_initial_schema.sql`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full overflow-hidden border border-slate-200 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white border-b border-slate-800 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-sm text-white">MWMS System Architecture & Disclosures</h3>
              <p className="text-xs text-slate-400">
                Phase 2 local testing environment, zero AWS costs, PostgreSQL schema & roles
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-200 px-6 pt-3 bg-slate-50 gap-4 flex-shrink-0">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-2.5 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'overview'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Architecture Overview
          </button>
          <button
            onClick={() => setActiveTab('schema')}
            className={`pb-2.5 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'schema'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Database Schema & Migrations
          </button>
          <button
            onClick={() => setActiveTab('roles')}
            className={`pb-2.5 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'roles'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Role Permissions Matrix
          </button>
          <button
            onClick={() => setActiveTab('localSetup')}
            className={`pb-2.5 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'localSetup'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Zero-Cost Hosting Policy
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs text-slate-700">
          {activeTab === 'overview' && (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                <h4 className="font-bold text-slate-900 text-sm mb-1">
                  Full-Stack Architecture Specification
                </h4>
                <p className="text-slate-600 leading-relaxed">
                  The application is built with a decoupled React + TypeScript frontend, an Express REST API backend, and transactional storage with strict relational integrity.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="font-bold text-slate-900 block mb-1">1. Frontend Layer</span>
                  <p className="text-slate-600">
                    React 19 + TypeScript + Tailwind CSS. Responsive municipal administrative interface, printable vector receipts, role-based view controls, and modal workflows.
                  </p>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="font-bold text-slate-900 block mb-1">2. Backend Layer</span>
                  <p className="text-slate-600">
                    Node.js + Express with parameterized validation, duplicate bill prevention, balance locks, and audit logging.
                  </p>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="font-bold text-slate-900 block mb-1">3. Storage & Integrity</span>
                  <p className="text-slate-600">
                    Includes ready-to-run PostgreSQL DDL (<code className="bg-slate-200 px-1 py-0.5 rounded">migrations/001_initial_schema.sql</code>) and self-contained persistent JSON storage for instant zero-dependency execution.
                  </p>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="font-bold text-slate-900 block mb-1">4. Financial Safety Controls</span>
                  <p className="text-slate-600">
                    Locking against double billing, unique transaction references, pending verification segregation, and immutable reversal audit logs.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'schema' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-900">PostgreSQL Migration 001</h4>
                  <p className="text-slate-500 text-[11px]">Located in <code className="font-mono text-emerald-700">migrations/001_initial_schema.sql</code></p>
                </div>
                <button
                  onClick={copySqlSnippet}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 border border-slate-300 font-mono text-[11px] text-slate-700 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copied Command' : 'Copy psql command'}
                </button>
              </div>

              <div className="bg-slate-900 text-slate-100 p-3 rounded-lg font-mono text-[11px] overflow-x-auto max-h-60 leading-relaxed">
                <pre>{`-- Normalized Core Entities:
1. zones (id, code, name, description, coverage_area, active)
2. app_users (id, username, password_hash, full_name, role, email)
3. fee_rates (id, property_type, monthly_fee, status, effective_date)
4. properties (id, property_number UNIQUE, owner, address, zone_id, type)
5. invoices (id, invoice_number, property_id, billing_month, balance_due)
   -> CONSTRAINT uq_property_billing_month UNIQUE (property_id, billing_month)
6. payments (id, receipt_number, invoice_id, amount, payment_method, verification_status)
   -> CONSTRAINT uq_digital_reference UNIQUE (digital_reference)
7. trucks, routes, collection_schedules, collection_records, complaints
8. audit_logs (id, timestamp, user_id, action, entity_type, details)`}</pre>
              </div>

              <p className="text-[11px] text-slate-500">
                To connect MWMS to an external PostgreSQL server, simply update the <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">DATABASE_URL</code> variable in <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">.env</code>.
              </p>
            </div>
          )}

          {activeTab === 'roles' && (
            <div className="space-y-3">
              <h4 className="font-bold text-slate-900">Enforced Role Matrix</h4>
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-slate-100 text-slate-700">
                    <tr>
                      <th className="px-3 py-2">Role</th>
                      <th className="px-3 py-2">Primary Permissions</th>
                      <th className="px-3 py-2">Restricted Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800">
                    <tr>
                      <td className="px-3 py-2 font-semibold text-amber-900">System Admin</td>
                      <td className="px-3 py-2">All configuration, zones, fee rate approval, user roles, system tests</td>
                      <td className="px-3 py-2 text-slate-400">None</td>
                    </tr>
                    <tr>
                      <td className="px-3 py-2 font-semibold text-emerald-900">Finance Officer</td>
                      <td className="px-3 py-2">Propose/approve rates, batch billing, verify digital payments, audited reversals, financial reports</td>
                      <td className="px-3 py-2 text-slate-500">Cannot edit zone boundaries</td>
                    </tr>
                    <tr>
                      <td className="px-3 py-2 font-semibold text-blue-900">Cashier</td>
                      <td className="px-3 py-2">Record cash payments, input digital transaction references, print receipts</td>
                      <td className="px-3 py-2 text-slate-500">Cannot approve digital payments, cannot reverse transactions, cannot generate batch bills</td>
                    </tr>
                    <tr>
                      <td className="px-3 py-2 font-semibold text-purple-900">Collection Manager</td>
                      <td className="px-3 py-2">Manage trucks, create routes, schedule collection dispatches, review complaints</td>
                      <td className="px-3 py-2 text-slate-500">Cannot alter financial rates or invoice records</td>
                    </tr>
                    <tr>
                      <td className="px-3 py-2 font-semibold text-orange-900">Field Collector</td>
                      <td className="px-3 py-2">View assigned collection run, mark completed/missed pick-ups, log field weights</td>
                      <td className="px-3 py-2 text-slate-500">Read-only on billing and fees</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'localSetup' && (
            <div className="space-y-3">
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h4 className="font-bold text-blue-950 text-sm mb-1">
                  Compliance with Document Mandate
                </h4>
                <p className="text-blue-900 leading-relaxed">
                  "Development approach: build and test locally first, then evaluate deployment options. No AWS resources or paid cloud services should be created without explicit approval."
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <p>
                    <strong>Zero Incurred AWS or Cloud Charges:</strong> All APIs, database persistence, and invariant checks run entirely on the local development server.
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <p>
                    <strong>Portable Data Architecture:</strong> File storage in <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">data/mwms_data.json</code> mirrors normalized tables, ensuring seamless migration to PostgreSQL without code rewrites.
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <p>
                    <strong>Environment Separation:</strong> Configuration is strictly decoupled in <code className="bg-slate-100 px-1 py-0.5 rounded font-mono">.env.example</code> with placeholders for host, port, credentials, and municipality branding.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end flex-shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Close Documentation
          </button>
        </div>
      </div>
    </div>
  );
};
