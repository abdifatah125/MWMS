import React, { useState, useEffect } from 'react';
import { api } from '../../api/client.js';
import { CheckCircle2, XCircle, RefreshCw, X, ShieldAlert, Sparkles } from 'lucide-react';

interface TestRunnerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TestRunnerModal: React.FC<TestRunnerModalProps> = ({ isOpen, onClose }) => {
  const [loading, setLoading] = useState(false);
  const [testData, setTestData] = useState<{
    suite: string;
    executedAt: string;
    results: Array<{ name: string; description: string; passed: boolean; details: string }>;
    allPassed: boolean;
  } | null>(null);

  const runTests = async () => {
    setLoading(true);
    try {
      const data = await api.runSystemTests();
      setTestData(data);
    } catch (err) {
      console.error('Failed to run system test suite:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      runTests();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-sm text-white">MWMS Financial Invariants Verification Suite</h3>
              <p className="text-xs text-slate-400">
                Automated tests for billing duplicate prevention, balance locks, and audit rules
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Header Status Bar */}
          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-50 border border-slate-200">
            <div>
              <span className="text-xs font-semibold text-slate-500 block uppercase">Suite Status</span>
              {testData ? (
                <div className="flex items-center gap-2 mt-0.5">
                  <span
                    className={`font-bold text-sm ${
                      testData.allPassed ? 'text-emerald-700' : 'text-rose-700'
                    }`}
                  >
                    {testData.allPassed
                      ? 'All 5 Financial Invariants Passed (100%)'
                      : 'Some Invariant Tests Failed'}
                  </span>
                  <span className="text-xs text-slate-400">
                    · Executed {new Date(testData.executedAt).toLocaleTimeString()}
                  </span>
                </div>
              ) : (
                <span className="text-xs text-slate-500">Executing verification tests...</span>
              )}
            </div>
            <button
              onClick={runTests}
              disabled={loading}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-medium transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Re-run Tests
            </button>
          </div>

          {/* Test List */}
          <div className="space-y-3">
            {loading && !testData && (
              <div className="py-8 text-center text-xs text-slate-500">
                Running transactional database checks...
              </div>
            )}

            {testData?.results.map((res, i) => (
              <div
                key={i}
                className={`p-3.5 rounded-lg border text-xs transition-colors ${
                  res.passed
                    ? 'bg-emerald-50/50 border-emerald-200 text-slate-800'
                    : 'bg-rose-50/50 border-rose-200 text-slate-800'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    {res.passed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-600 mt-0.5 flex-shrink-0" />
                    )}
                    <div>
                      <div className="font-semibold text-slate-900">{res.name}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{res.description}</div>
                      <div className="text-[11px] font-mono mt-1.5 text-slate-700 bg-white/80 p-1.5 rounded border border-slate-200/80">
                        {res.details}
                      </div>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                      res.passed
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : 'bg-rose-100 text-rose-800 border border-rose-200'
                    }`}
                  >
                    {res.passed ? 'PASSED' : 'FAILED'}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Standards Disclosure */}
          <div className="text-[11px] text-slate-500 bg-slate-100 p-3 rounded-lg border border-slate-200">
            <strong>Specification Compliance:</strong> All rules in the MWMS Project Idea Document
            (Section 5 & 8: Duplicate bill prevention, overpayment bounds, digital reference uniqueness,
            pending revenue exclusion, and audited reversals) are verified directly against backend business logic.
          </div>
        </div>

        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
