import React, { useState } from 'react';
import { District, SubDistrict, Zone, Route, Truck } from '../../types/index.js';
import {
  MapPin,
  Building,
  Truck as TruckIcon,
  Navigation,
  CheckCircle2,
  Plus,
  Search,
  Filter,
  ChevronRight,
  Layers,
  ArrowRight,
  X,
  Building2,
  FolderTree,
  Trash2,
} from 'lucide-react';

interface ZonesViewProps {
  districts: District[];
  subDistricts: SubDistrict[];
  zones: Zone[];
  routes: Route[];
  trucks: Truck[];
  onSelectZoneForProperties?: (zoneId: string) => void;
  onAddSubDistrict: (data: Omit<SubDistrict, 'id' | 'zonesCount'>) => Promise<void>;
  onAddZone: (data: Omit<Zone, 'id' | 'propertyCount'>) => Promise<void>;
  onDeleteSubDistrict: (id: string) => Promise<void>;
  onDeleteZone: (id: string) => Promise<void>;
}

export const ZonesView: React.FC<ZonesViewProps> = ({
  districts,
  subDistricts,
  zones,
  routes,
  trucks,
  onSelectZoneForProperties,
  onAddSubDistrict,
  onAddZone,
  onDeleteSubDistrict,
  onDeleteZone,
}) => {
  const [viewMode, setViewMode] = useState<'districts' | 'hierarchy' | 'zones'>('districts');
  const [selectedDistrictId, setSelectedDistrictId] = useState<string>(districts[0]?.id || 'dist-hodan');
  const [search, setSearch] = useState('');

  // Modals
  const [isAddSubModalOpen, setIsAddSubModalOpen] = useState(false);
  const [isAddZoneModalOpen, setIsAddZoneModalOpen] = useState(false);

  // Form states
  const [formDistId, setFormDistId] = useState(districts[0]?.id || '');
  const [formSubCode, setFormSubCode] = useState('');
  const [formSubName, setFormSubName] = useState('');
  const [formSubSomali, setFormSubSomali] = useState('');
  const [formSubDesc, setFormSubDesc] = useState('');

  const [formZoneCode, setFormZoneCode] = useState('');
  const [formZoneName, setFormZoneName] = useState('');
  const [formZoneDistId, setFormZoneDistId] = useState(districts[0]?.id || '');
  const [formZoneSubId, setFormZoneSubId] = useState('');
  const [formZoneCoverage, setFormZoneCoverage] = useState('');
  const [formZoneDesc, setFormZoneDesc] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  const handleDeleteSubDistrict = async (sub: SubDistrict) => {
    if (!window.confirm(`Delete waax "${sub.name}"? It can only be deleted when it has no collection zones or properties.`)) return;
    try { await onDeleteSubDistrict(sub.id); } catch (err: any) { window.alert(err.message || 'Failed to delete waax'); }
  };

  const handleDeleteZone = async (zone: Zone) => {
    if (!window.confirm(`Delete collection zone "${zone.name}" (${zone.code})? It can only be deleted when it has no properties, routes, or collection schedules.`)) return;
    try { await onDeleteZone(zone.id); } catch (err: any) { window.alert(err.message || 'Failed to delete zone'); }
  };

  // Filtered districts
  const filteredDistricts = districts.filter((d) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      d.name.toLowerCase().includes(q) ||
      d.somaliName.toLowerCase().includes(q) ||
      d.code.toLowerCase().includes(q)
    );
  });

  const activeDistrict = districts.find((d) => d.id === selectedDistrictId) || districts[0];
  const activeSubDistricts = subDistricts.filter((sd) => sd.districtId === activeDistrict?.id);

  // Handlers
  const handleOpenAddSub = (distId?: string) => {
    setFormDistId(distId || selectedDistrictId || districts[0]?.id || '');
    setFormSubCode('');
    setFormSubName('');
    setFormSubSomali('');
    setFormSubDesc('');
    setFormError('');
    setIsAddSubModalOpen(true);
  };

  const handleOpenAddZone = (distId?: string, subId?: string) => {
    const dId = distId || selectedDistrictId || districts[0]?.id || '';
    setFormZoneDistId(dId);
    const availableSubs = subDistricts.filter((s) => s.districtId === dId);
    setFormZoneSubId(subId || availableSubs[0]?.id || '');
    setFormZoneCode('');
    setFormZoneName('');
    setFormZoneCoverage('3.5 sq km (Urban Sector)');
    setFormZoneDesc('');
    setFormError('');
    setIsAddZoneModalOpen(true);
  };

  const handleDistrictChangeForZone = (dId: string) => {
    setFormZoneDistId(dId);
    const availableSubs = subDistricts.filter((s) => s.districtId === dId);
    setFormZoneSubId(availableSubs[0]?.id || '');
  };

  const handleSaveSubDistrict = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSubmitting(true);
    try {
      await onAddSubDistrict({
        districtId: formDistId,
        code: formSubCode,
        name: formSubName,
        somaliName: formSubSomali || formSubName,
        description: formSubDesc,
      });
      setIsAddSubModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to create sub-district');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSaveZone = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSubmitting(true);
    try {
      await onAddZone({
        code: formZoneCode,
        name: formZoneName,
        districtId: formZoneDistId,
        subDistrictId: formZoneSubId,
        description: formZoneDesc,
        coverageArea: formZoneCoverage,
        active: true,
      });
      setIsAddZoneModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Failed to create zone');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-700" />
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Mogadishu Municipal Zones Management
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Hierarchical partitioning of Mogadishu (20 Official Districts ➔ Sub-Districts / Waaxyaha ➔ Operational Collection Zones)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleOpenAddSub()}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            + Sub-District (Waax)
          </button>
          <button
            onClick={() => handleOpenAddZone()}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            + Collection Zone
          </button>
        </div>
      </div>

      {/* View Switcher Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode('districts')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              viewMode === 'districts'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            20 Mogadishu Districts ({districts.length})
          </button>

          <button
            onClick={() => setViewMode('hierarchy')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              viewMode === 'hierarchy'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <FolderTree className="w-3.5 h-3.5" />
            District ➔ Sub-District ➔ Zone Explorer
          </button>

          <button
            onClick={() => setViewMode('zones')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              viewMode === 'zones'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            All Collection Zones ({zones.length})
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          <input
            type="text"
            placeholder="Search district, sub-district, or zone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 w-56 sm:w-64"
          />
        </div>
      </div>

      {/* VIEW 1: 20 Mogadishu Districts Grid */}
      {viewMode === 'districts' && (
        <div className="space-y-4">
          <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-950 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse" />
              <span>
                <strong>Banaadir Regional Administration (BRA):</strong> 20 Recognized Mogadishu Districts including newly ratified Gubadley, Daarusalaam, and Garasbaaley.
              </span>
            </div>
            <span className="font-semibold text-emerald-800">
              {filteredDistricts.length} Districts Displayed
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {filteredDistricts.map((d) => (
              <div
                key={d.id}
                className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:border-emerald-500 transition-all flex flex-col justify-between space-y-3 cursor-pointer group"
                onClick={() => {
                  setSelectedDistrictId(d.id);
                  setViewMode('hierarchy');
                }}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                      {d.code}
                    </span>
                    {d.name.includes('Newly') && (
                      <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300">
                        New District
                      </span>
                    )}
                  </div>
                  <h3 className="font-bold text-sm text-slate-900 group-hover:text-emerald-700 transition-colors">
                    {d.name}
                  </h3>
                  <div className="text-[11px] font-medium text-emerald-700">
                    {d.somaliName}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1.5 line-clamp-2">
                    {d.description}
                  </p>
                </div>

                <div className="pt-2.5 border-t border-slate-100 space-y-1 text-[11px] text-slate-600">
                  <div className="flex justify-between">
                    <span>Sub-Districts (Waax):</span>
                    <strong className="text-slate-900">{d.subDistrictsCount || 0}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Collection Zones:</span>
                    <strong className="text-slate-900">{d.zonesCount || 0}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Active Properties:</span>
                    <strong className="text-emerald-700">{d.propertiesCount || 0}</strong>
                  </div>

                  <div className="pt-1.5 flex items-center justify-between text-emerald-700 font-semibold group-hover:translate-x-0.5 transition-transform">
                    <span>Explore Zones</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW 2: Hierarchy Explorer: District ➔ Sub-Districts (Waaxyaha) ➔ Operational Collection Zones */}
      {viewMode === 'hierarchy' && activeDistrict && (
        <div className="space-y-6">
          {/* District Selector Tabs */}
          <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block px-1">
              Select Mogadishu District
            </span>
            <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs">
              {districts.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setSelectedDistrictId(d.id)}
                  className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-all ${
                    selectedDistrictId === d.id
                      ? 'bg-emerald-700 text-white font-bold shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {d.name}
                </button>
              ))}
            </div>
          </div>

          {/* District Detail Banner */}
          <div className="p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-xl shadow-xs border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {activeDistrict.code}
                </span>
                <span className="text-xs text-slate-300">
                  {activeDistrict.somaliName} · Banaadir Region
                </span>
              </div>
              <h3 className="text-xl font-extrabold text-white mt-1">
                {activeDistrict.name} District
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                {activeDistrict.description}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleOpenAddSub(activeDistrict.id)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-xs transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Sub-District (Waax)
              </button>
              <button
                onClick={() => handleOpenAddZone(activeDistrict.id)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold shadow-xs transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Zone
              </button>
            </div>
          </div>

          {/* Sub-Districts & Zones Tree */}
          <div className="space-y-4">
            {activeSubDistricts.length === 0 ? (
              <div className="p-8 bg-white rounded-xl border border-slate-200 text-center text-xs text-slate-500">
                <p>No sub-districts (waaxyaha) registered for {activeDistrict.name} yet.</p>
                <button
                  onClick={() => handleOpenAddSub(activeDistrict.id)}
                  className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 text-white font-semibold text-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Register First Sub-District
                </button>
              </div>
            ) : (
              activeSubDistricts.map((sub) => {
                const subZones = zones.filter((z) => z.subDistrictId === sub.id);
                return (
                  <div
                    key={sub.id}
                    className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden"
                  >
                    {/* Sub-District Header */}
                    <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <span className="w-2 h-2 rounded-full bg-emerald-600" />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900">
                              {sub.name}
                            </span>
                            <span className="text-xs text-slate-500 font-medium">
                              ({sub.somaliName})
                            </span>
                            <span className="font-mono text-[10px] font-bold bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-700">
                              {sub.code}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {sub.description}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleOpenAddZone(activeDistrict.id, sub.id)}
                          className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 bg-white px-2.5 py-1 rounded border border-slate-200 shadow-xs"
                        >
                          <Plus className="w-3 h-3" />
                          Add Collection Zone
                        </button>
                        <button
                          onClick={() => handleDeleteSubDistrict(sub)}
                          className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 hover:text-rose-800 bg-white px-2.5 py-1 rounded border border-rose-200 shadow-xs"
                          title="Delete waax"
                        >
                          <Trash2 className="w-3 h-3" /> Delete Waax
                        </button>
                      </div>
                    </div>

                    {/* Collection Zones List inside Sub-District */}
                    <div className="p-4">
                      {subZones.length === 0 ? (
                        <div className="py-4 text-center text-xs text-slate-400">
                          No collection zones configured in this sub-district yet.
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                          {subZones.map((z) => (
                            <div
                              key={z.id}
                              className="p-3.5 bg-slate-50/70 rounded-lg border border-slate-200 hover:border-emerald-300 transition-colors flex flex-col justify-between space-y-2"
                            >
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <span className="font-mono font-bold text-xs text-emerald-800 bg-emerald-100/70 px-2 py-0.5 rounded border border-emerald-200">
                                    {z.code}
                                  </span>
                                  <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                                    <CheckCircle2 className="w-3 h-3" />
                                    Active Run
                                  </span>
                                </div>
                                <h5 className="font-bold text-xs text-slate-900 mt-1">
                                  {z.name}
                                </h5>
                                <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                                  {z.description}
                                </p>
                              </div>

                              <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-[11px] text-slate-600">
                                <span>{z.coverageArea}</span>
                                <span className="font-mono font-bold text-slate-900">
                                  {z.propertyCount || 0} props
                                </span>
                              </div>

                              {onSelectZoneForProperties && (
                                <button
                                  onClick={() => onSelectZoneForProperties(z.id)}
                                  className="w-full mt-1 py-1 rounded bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-medium text-[11px] transition-colors"
                                >
                                  View Zone Properties
                                </button>
                              )}
                              <button
                                onClick={() => handleDeleteZone(z)}
                                className="w-full mt-1 py-1 rounded bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold text-[11px] transition-colors inline-flex items-center justify-center gap-1"
                                title="Delete collection zone"
                              >
                                <Trash2 className="w-3 h-3" /> Delete Collection Zone
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* VIEW 3: All Collection Zones Table */}
      {viewMode === 'zones' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900">
              Mogadishu Sanitation Collection Zones Master Table
            </h3>
            <span className="text-xs text-slate-500">
              Total {zones.length} active collection zones across 20 districts
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 font-semibold">
                <tr>
                  <th className="px-4 py-3">Zone Code</th>
                  <th className="px-4 py-3">Zone Name</th>
                  <th className="px-4 py-3">District (Degmada)</th>
                  <th className="px-4 py-3">Sub-District (Waaxda)</th>
                  <th className="px-4 py-3">Coverage Sector</th>
                  <th className="px-4 py-3 text-center">Properties</th>
                  <th className="px-4 py-3 text-center">Status</th>
                  <th className="px-4 py-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {zones.map((z) => (
                  <tr key={z.id} className="hover:bg-slate-50/50">
                    <td className="px-4 py-3 font-mono font-bold text-slate-900">{z.code}</td>
                    <td className="px-4 py-3 font-semibold text-slate-900">{z.name}</td>
                    <td className="px-4 py-3 font-medium text-emerald-800">
                      {z.districtName || 'Mogadishu'}
                    </td>
                    <td className="px-4 py-3 text-slate-700 font-medium">
                      {z.subDistrictName || 'General Waax'}
                    </td>
                    <td className="px-4 py-3 text-slate-500">{z.coverageArea}</td>
                    <td className="px-4 py-3 text-center font-mono font-bold text-slate-900">
                      {z.propertyCount || 0}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-50 text-emerald-800 border border-emerald-200">
                        Operational
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button onClick={() => handleDeleteZone(z)} className="inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold text-rose-700 hover:bg-rose-50 border border-rose-200" title="Delete collection zone">
                        <Trash2 className="w-3 h-3" /> Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Sub-District Modal */}
      {isAddSubModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <h3 className="font-bold text-sm">Register New Sub-District (Waax)</h3>
              <button
                onClick={() => setIsAddSubModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSubDistrict} className="p-6 space-y-4 text-xs">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg">
                  {formError}
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Target Mogadishu District *
                </label>
                <select
                  value={formDistId}
                  onChange={(e) => setFormDistId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                >
                  {districts.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.somaliName})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Sub-District Code *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. HOD-TLX-2"
                    value={formSubCode}
                    onChange={(e) => setFormSubCode(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Sub-District Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Taleex East"
                    value={formSubName}
                    onChange={(e) => setFormSubName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Somali Name (Magaca Soomaaliga)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Waaxda Taleex Bariga"
                  value={formSubSomali}
                  onChange={(e) => setFormSubSomali(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Description / Boundaries
                </label>
                <textarea
                  rows={2}
                  value={formSubDesc}
                  onChange={(e) => setFormSubDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  placeholder="e.g. Covers secondary paved streets connecting to KM5."
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddSubModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {submitting ? 'Registering...' : 'Register Sub-District'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Zone Modal */}
      {isAddZoneModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <h3 className="font-bold text-sm">Create Waste Collection Zone</h3>
              <button
                onClick={() => setIsAddZoneModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveZone} className="p-6 space-y-4 text-xs">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg">
                  {formError}
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  1. Mogadishu District *
                </label>
                <select
                  value={formZoneDistId}
                  onChange={(e) => handleDistrictChangeForZone(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                >
                  {districts.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.somaliName})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  2. Sub-District (Waax) *
                </label>
                <select
                  value={formZoneSubId}
                  onChange={(e) => setFormZoneSubId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 bg-white"
                >
                  {subDistricts
                    .filter((s) => s.districtId === formZoneDistId)
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.code})
                      </option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Zone Identifier Code *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Z-HOD-TLX-03"
                    value={formZoneCode}
                    onChange={(e) => setFormZoneCode(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Coverage Area
                  </label>
                  <input
                    type="text"
                    value={formZoneCoverage}
                    onChange={(e) => setFormZoneCoverage(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                    placeholder="e.g. 3.0 sq km"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Collection Zone Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Taleex Commercial North Extension"
                  value={formZoneName}
                  onChange={(e) => setFormZoneName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Operational Description
                </label>
                <textarea
                  rows={2}
                  value={formZoneDesc}
                  onChange={(e) => setFormZoneDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500"
                  placeholder="e.g. High-density commercial restaurants and retail strip."
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddZoneModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white rounded-lg font-semibold shadow-xs"
                >
                  {submitting ? 'Creating...' : 'Create Collection Zone'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
