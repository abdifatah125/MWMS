import React, { useState, useEffect, useCallback } from 'react';
import {
  AppUser,
  AuditLog,
  CollectionRecord,
  CollectionSchedule,
  CustomerComplaint,
  DashboardStats,
  District,
  FeeRate,
  Invoice,
  Payment,
  Property,
  Route,
  SubDistrict,
  Truck,
  Zone,
} from './types/index.js';
import { api } from './api/client.js';
import { Header } from './components/layout/Header.js';
import { Sidebar, NavTab } from './components/layout/Sidebar.js';
import { DashboardView } from './components/dashboard/DashboardView.js';
import { PropertiesView } from './components/properties/PropertiesView.js';
import { ZonesView } from './components/zones/ZonesView.js';
import { FeeConfigView } from './components/fees/FeeConfigView.js';
import { BillingView } from './components/billing/BillingView.js';
import { PaymentsView } from './components/payments/PaymentsView.js';
import { OperationsView } from './components/operations/OperationsView.js';
import { ReportsView } from './components/reports/ReportsView.js';
import { AuditLogsView } from './components/audit/AuditLogsView.js';
import { UsersView } from './components/users/UsersView.js';
import { PrintableReceiptModal } from './components/payments/PrintableReceiptModal.js';
import { TestRunnerModal } from './components/system/TestRunnerModal.js';
import { ArchitectureModal } from './components/system/ArchitectureModal.js';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);
  const [users, setUsers] = useState<AppUser[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [districts, setDistricts] = useState<District[]>([]);
  const [subDistricts, setSubDistricts] = useState<SubDistrict[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [feeRates, setFeeRates] = useState<FeeRate[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [routes, setRoutes] = useState<Route[]>([]);
  const [schedules, setSchedules] = useState<CollectionSchedule[]>([]);
  const [records, setRecords] = useState<CollectionRecord[]>([]);
  const [complaints, setComplaints] = useState<CustomerComplaint[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try { return localStorage.getItem('mwms-theme') === 'dark' ? 'dark' : 'light'; } catch { return 'light'; }
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('mwms-theme', theme); } catch { /* storage may be disabled */ }
  }, [theme]);
  const [loading, setLoading] = useState(true);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginBusy, setLoginBusy] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Modals state
  const [receiptPayment, setReceiptPayment] = useState<Payment | null>(null);
  const [isTestsModalOpen, setIsTestsModalOpen] = useState(false);
  const [isArchitectureModalOpen, setIsArchitectureModalOpen] = useState(false);
  const [initialInvoiceForPayment, setInitialInvoiceForPayment] = useState<Invoice | null>(null);

  // Toast notice
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4500);
  };

  // Main data loader
  const loadAllData = useCallback(async (quiet = false) => {
    if (!quiet) setIsRefreshing(true);
    try {
      const [
        loadedUsers,
        loadedCurrent,
        loadedStats,
        loadedDistricts,
        loadedSubDistricts,
        loadedZones,
        loadedProps,
        loadedFees,
        loadedInvoices,
        loadedPayments,
        loadedOps,
        loadedLogs,
      ] = await Promise.all([
        api.getUsers(),
        api.getCurrentUser(),
        api.getDashboardStats(),
        api.getDistricts(),
        api.getSubDistricts(),
        api.getZones(),
        api.getProperties(),
        api.getFees(),
        api.getInvoices(),
        api.getPayments(),
        api.getOperationsData(),
        api.getAuditLogs(),
      ]);

      setUsers(loadedUsers);
      setCurrentUser(loadedCurrent);
      setStats(loadedStats);
      setDistricts(loadedDistricts);
      setSubDistricts(loadedSubDistricts);
      setZones(loadedZones);
      setProperties(loadedProps);
      setFeeRates(loadedFees);
      setInvoices(loadedInvoices);
      setPayments(loadedPayments);
      setTrucks(loadedOps.trucks);
      setRoutes(loadedOps.routes);
      setSchedules(loadedOps.schedules);
      setRecords(loadedOps.records);
      setComplaints(loadedOps.complaints);
      setAuditLogs(loadedLogs);
    } catch (err: any) {
      console.error('Failed to load application data:', err);
      showToast('Error syncing with municipal database server', 'error');
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  const handleLogin = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoginBusy(true); setLoginError('');
    try {
      await api.login(loginUsername, loginPassword);
      setLoginPassword('');
      await loadAllData(true);
    } catch (err: any) { setLoginError(err.message || 'Sign-in failed'); }
    finally { setLoginBusy(false); }
  };

  const handleLogout = async () => {
    await api.logout();
    setCurrentUser(null);
    setUsers([]);
    setStats(null);
    setLoading(false);
  };

  // Mutations
  const handleAddProperty = async (propData: Omit<Property, 'id' | 'registeredAt'>) => {
    await api.createProperty(propData);
    showToast(`Property ${propData.propertyNumber} registered successfully`);
    await loadAllData(true);
  };

  const handleUpdateProperty = async (id: string, updates: Partial<Property>) => {
    await api.updateProperty(id, updates);
    showToast('Property details updated successfully');
    await loadAllData(true);
  };

  const handleDeleteProperty = async (id: string) => {
    await api.deleteProperty(id);
    showToast('Property deleted successfully');
    await loadAllData(true);
  };

  const handleDeleteSubDistrict = async (id: string) => {
    await api.deleteSubDistrict(id);
    showToast('Sub-district (waax) deleted successfully');
    await loadAllData(true);
  };

  const handleDeleteZone = async (id: string) => {
    await api.deleteZone(id);
    showToast('Collection zone deleted successfully');
    await loadAllData(true);
  };

  const handleAddSubDistrict = async (data: Omit<SubDistrict, 'id' | 'zonesCount'>) => {
    await api.createSubDistrict(data);
    showToast(`Sub-district ${data.name} (${data.code}) created successfully`);
    await loadAllData(true);
  };

  const handleAddZone = async (data: Omit<Zone, 'id' | 'propertyCount'>) => {
    await api.createZone(data);
    showToast(`Collection Zone ${data.name} (${data.code}) created successfully`);
    await loadAllData(true);
  };

  const handleProposeFee = async (payload: {
    propertyType: 'residential' | 'commercial';
    monthlyFee: number;
    effectiveDate: string;
    notes: string;
  }) => {
    await api.proposeFee(payload);
    showToast(`Proposed ${payload.propertyType} rate of $${payload.monthlyFee.toFixed(2)} submitted`);
    await loadAllData(true);
  };

  const handleApproveFee = async (id: string) => {
    await api.approveFee(id);
    showToast('Municipal fee rate approved and ratified into effect');
    await loadAllData(true);
  };

  const handleGenerateBatchBilling = async (billingMonth: string, zoneId?: string) => {
    const result = await api.generateBatchBilling(billingMonth, zoneId);
    showToast(
      `Generated ${result.generatedCount} invoices for ${billingMonth}. Skipped ${result.skippedDuplicates} duplicates.`
    );
    await loadAllData(true);
    return result;
  };

  const handleRecordPayment = async (payload: {
    invoiceId: string;
    amount: number;
    paymentMethod: 'cash' | 'digital';
    digitalReference?: string;
    digitalProvider?: string;
    notes?: string;
  }) => {
    const result = await api.recordPayment(payload);
    if (result.payment.verificationStatus === 'confirmed') {
      showToast(
        `Cash payment of $${result.payment.amount.toFixed(2)} confirmed. Receipt ${result.payment.receiptNumber} issued.`
      );
    } else {
      showToast(
        `Digital transaction ${result.payment.digitalReference} recorded as PENDING manual verification.`
      );
    }
    await loadAllData(true);
    return result;
  };

  const handleVerifyPayment = async (
    id: string,
    action: 'approve' | 'reject',
    notes?: string
  ) => {
    const result = await api.verifyPayment(id, action, notes);
    if (action === 'approve') {
      showToast(`Digital payment verified & confirmed. Receipt ${result.payment.receiptNumber} issued.`);
    } else {
      showToast(`Digital transaction ${result.payment.digitalReference} rejected.`);
    }
    await loadAllData(true);
    return result;
  };

  const handleReversePayment = async (id: string, reason: string) => {
    const result = await api.reversePayment(id, reason);
    showToast(`Transaction ${result.payment.receiptNumber} reversed. Balance restored to invoice.`);
    await loadAllData(true);
    return result;
  };

  const handleAddTruck = async (truck: Omit<Truck, 'id'>) => {
    await api.createTruck(truck);
    showToast(`Added compactor truck ${truck.plateNumber}`);
    await loadAllData(true);
  };

  const handleAddRoute = async (route: Omit<Route, 'id'>) => {
    await api.createRoute(route);
    showToast(`Route ${route.name} registered`);
    await loadAllData(true);
  };

  const handleAddSchedule = async (
    schedule: Omit<CollectionSchedule, 'id' | 'stopsCompleted'>
  ) => {
    await api.createSchedule(schedule);
    showToast(`Collection scheduled for ${schedule.date}`);
    await loadAllData(true);
  };

  const handleLogCollection = async (record: {
    scheduleId: string;
    propertyId: string;
    status: 'collected' | 'missed';
    missedReason?: string;
    notes?: string;
    wasteWeightKg?: number;
  }) => {
    await api.logCollectionRecord(record);
    showToast(`Logged collection status as ${record.status.toUpperCase()}`);
    await loadAllData(true);
  };

  const handleAddComplaint = async (complaint: {
    propertyId: string;
    complainantName: string;
    phone: string;
    category: CustomerComplaint['category'];
    description: string;
    priority: CustomerComplaint['priority'];
  }) => {
    await api.createComplaint(complaint);
    showToast('Customer complaint registered and assigned ticket number');
    await loadAllData(true);
  };

  const handleResolveComplaint = async (id: string, notes: string) => {
    await api.resolveComplaint(id, notes);
    showToast('Customer complaint marked as resolved');
    await loadAllData(true);
  };

  const handleOperationAction = async (action: string, id: string, status?: string) => {
    switch (action) {
      case 'truck-status': await api.updateTruck(id, { status: status as Truck['status'] }); break;
      case 'truck-delete': await api.deleteTruck(id); break;
      case 'route-status': await api.updateRoute(id, { status: status as Route['status'] }); break;
      case 'route-delete': await api.deleteRoute(id); break;
      case 'schedule-status': await api.updateScheduleStatus(id, status as CollectionSchedule['status']); break;
      case 'schedule-delete': await api.deleteSchedule(id); break;
      case 'record-status': await api.updateCollectionRecordStatus(id, status as CollectionRecord['status']); break;
      case 'record-delete': await api.deleteCollectionRecord(id); break;
      case 'complaint-status': await api.updateComplaintStatus(id, status as CustomerComplaint['status']); break;
      case 'complaint-delete': await api.deleteComplaint(id); break;
      default: throw new Error('Unknown operations action');
    }
    showToast(action.endsWith('delete') ? 'Record deleted successfully.' : 'Status updated successfully.');
    await loadAllData(true);
  };

  const handleCreateUser = async (userData: Omit<AppUser, 'id'>) => {
    await api.createUser(userData);
    showToast(`Staff member ${userData.fullName} registered with role '${userData.role}'`);
    await loadAllData(true);
  };

  const handleUpdateUser = async (id: string, updates: Partial<AppUser>) => {
    await api.updateUser(id, updates);
    showToast('Staff profile and role updated');
    await loadAllData(true);
  };

  const handleDeleteUser = async (id: string) => {
    await api.deleteUser(id);
    showToast('Staff user account removed');
    await loadAllData(true);
  };

  // Shortcut triggers
  const handleDirectInvoicePay = (invoice: Invoice) => {
    setInitialInvoiceForPayment(invoice);
    setCurrentTab('payments');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <h2 className="text-white font-bold text-base tracking-tight">
            Municipal Waste Management System
          </h2>
          <p className="text-xs text-slate-400">
            Initializing local database engine & verifying transactional constraints...
          </p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <form onSubmit={handleLogin} className="w-full max-w-md rounded-2xl border border-slate-700 bg-slate-900 p-8 shadow-2xl space-y-5">
          <div className="text-center">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-600 text-white text-xl font-black">MW</div>
            <h1 className="text-2xl font-bold text-white">MWMS Sign in</h1>
            <p className="mt-2 text-sm text-slate-400">Banaadir Regional Administration · Municipal Waste Management</p>
          </div>
          <label className="block text-sm text-slate-300">Username
            <input autoComplete="username" required value={loginUsername} onChange={e => setLoginUsername(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2.5 text-white outline-none focus:border-emerald-500" />
          </label>
          <label className="block text-sm text-slate-300">Password
            <input type="password" autoComplete="current-password" required value={loginPassword} onChange={e => setLoginPassword(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2.5 text-white outline-none focus:border-emerald-500" />
          </label>
          {loginError && <p role="alert" className="rounded-lg bg-rose-950/60 p-3 text-sm text-rose-300">{loginError}</p>}
          <button disabled={loginBusy} className="w-full rounded-lg bg-emerald-600 px-4 py-3 font-semibold text-white hover:bg-emerald-500 disabled:opacity-60">{loginBusy ? 'Signing in…' : 'Sign in securely'}</button>
          <p className="text-xs leading-relaxed text-slate-500">Accounts require an administrator-provisioned password. If this is a fresh setup, run the password initialization command in the setup guide.</p>
        </form>
      </div>
    );
  }

  return (
    <div className="mwms-app h-screen overflow-hidden bg-slate-100 flex flex-col font-sans text-slate-900 antialiased">
      {/* Toast Banner */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg border text-xs font-medium animate-in fade-in slide-in-from-bottom-2 bg-slate-900 text-white border-slate-700">
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
          )}
          <span>{toast.message}</span>
          <button
            onClick={() => setToast(null)}
            className="p-1 text-slate-400 hover:text-white ml-2 rounded"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top Header */}
      <Header
        currentUser={currentUser}
        users={users}
        onLogout={handleLogout}
        onOpenTests={() => setIsTestsModalOpen(true)}
        onOpenArchitecture={() => setIsArchitectureModalOpen(true)}
        onRefreshData={() => loadAllData(false)}
        isRefreshing={isRefreshing}
        theme={theme}
        onToggleTheme={() => setTheme((value) => value === 'light' ? 'dark' : 'light')}
      />

      {/* Main Layout: Sidebar + View Content */}
      <div className="flex-1 min-h-0 flex w-full min-w-0 mx-0 overflow-hidden">
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          pendingDigitalCount={stats?.pendingDigitalCount || 0}
          openComplaintsCount={stats?.openComplaintsCount || 0}
          currentUser={currentUser}
        />

        <main className="flex-1 min-w-0 min-h-0 p-3 sm:p-4 lg:p-5 overflow-y-auto overflow-x-auto max-w-full">
          {currentTab === 'dashboard' && (
            <DashboardView
              stats={stats}
              currentUser={currentUser}
              recentAuditLogs={auditLogs}
              onNavigateTab={(tab) => setCurrentTab(tab)}
              onOpenRecordPayment={() => {
                setInitialInvoiceForPayment(null);
                setCurrentTab('payments');
              }}
              onOpenBillingModal={() => setCurrentTab('billing')}
              onOpenAddProperty={() => setCurrentTab('properties')}
            />
          )}

          {currentTab === 'properties' && (
            <PropertiesView
              properties={properties}
              districts={districts}
              subDistricts={subDistricts}
              zones={zones}
              currentUser={currentUser}
              onAddProperty={handleAddProperty}
              onUpdateProperty={handleUpdateProperty}
              onDeleteProperty={handleDeleteProperty}
              allInvoices={invoices}
              allPayments={payments}
              onOpenRecordPaymentWithInvoice={handleDirectInvoicePay}
            />
          )}

          {currentTab === 'zones' && (
            <ZonesView
              districts={districts}
              subDistricts={subDistricts}
              zones={zones}
              routes={routes}
              trucks={trucks}
              onSelectZoneForProperties={(zId) => {
                setCurrentTab('properties');
              }}
              onAddSubDistrict={handleAddSubDistrict}
              onAddZone={handleAddZone}
              onDeleteSubDistrict={handleDeleteSubDistrict}
              onDeleteZone={handleDeleteZone}
            />
          )}

          {currentTab === 'fees' && (
            <FeeConfigView
              feeRates={feeRates}
              currentUser={currentUser}
              onProposeFee={handleProposeFee}
              onApproveFee={handleApproveFee}
            />
          )}

          {currentTab === 'billing' && (
            <BillingView
              invoices={invoices}
              zones={zones}
              currentUser={currentUser}
              onGenerateBatch={handleGenerateBatchBilling}
              onOpenRecordPayment={handleDirectInvoicePay}
            />
          )}

          {currentTab === 'payments' && (
            <PaymentsView
              payments={payments}
              invoices={invoices}
              currentUser={currentUser}
              onRecordPayment={handleRecordPayment}
              onVerifyPayment={handleVerifyPayment}
              onReversePayment={handleReversePayment}
              onOpenReceipt={(payment) => setReceiptPayment(payment)}
              initialInvoiceForPayment={initialInvoiceForPayment}
              onClearInitialInvoice={() => setInitialInvoiceForPayment(null)}
            />
          )}

          {currentTab === 'operations' && (
            <OperationsView
              trucks={trucks}
              routes={routes}
              schedules={schedules}
              records={records}
              complaints={complaints}
              properties={properties}
              zones={zones}
              currentUser={currentUser}
              onAddTruck={handleAddTruck}
              onAddRoute={handleAddRoute}
              onAddSchedule={handleAddSchedule}
              onLogCollection={handleLogCollection}
              onAddComplaint={handleAddComplaint}
              onResolveComplaint={handleResolveComplaint}
              onOperationAction={handleOperationAction}
            />
          )}

          {currentTab === 'reports' && (
            <ReportsView
              stats={stats}
              payments={payments}
              invoices={invoices}
              zones={zones}
              currentUser={currentUser}
            />
          )}

          {currentTab === 'audit' && (
            <AuditLogsView logs={auditLogs} currentUser={currentUser} />
          )}

          {currentTab === 'users' && (
            <UsersView
              users={users}
              currentUser={currentUser}
              districts={districts}
              zones={zones}
              auditLogs={auditLogs}
              onCreateUser={handleCreateUser}
              onUpdateUser={handleUpdateUser}
              onDeleteUser={handleDeleteUser}
            />
          )}
        </main>
      </div>

      {/* Global Modals */}
      <PrintableReceiptModal
        payment={receiptPayment}
        invoice={invoices.find((i) => i.id === receiptPayment?.invoiceId)}
        onClose={() => setReceiptPayment(null)}
      />

      <TestRunnerModal
        isOpen={isTestsModalOpen}
        onClose={() => setIsTestsModalOpen(false)}
      />

      <ArchitectureModal
        isOpen={isArchitectureModalOpen}
        onClose={() => setIsArchitectureModalOpen(false)}
      />
    </div>
  );
}
