import {
  AppUser,
  AuditLog,
  CollectionRecord,
  CollectionSchedule,
  CustomerComplaint,
  DashboardStats,
  District,
  FeeRate,
  Invoice,
  Payment,
  PermissionItem,
  Property,
  RoleDefinition,
  Route,
  SubDistrict,
  Truck,
  Zone,
} from '../types/index.js';

export const api = {
  // Auth & Roles
  async login(username: string, password: string): Promise<AppUser> {
    const res = await fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, password }), credentials: 'same-origin' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Sign-in failed');
    return data.user;
  },
  async logout(): Promise<void> {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
  },
  async getUsers(): Promise<AppUser[]> {
    const res = await fetch('/api/auth/users');
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to load users');
    return data.users;
  },
  async getCurrentUser(): Promise<AppUser | null> {
    const res = await fetch('/api/auth/current');
    if (res.status === 401) return null;
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to get current user');
    return data.user;
  },

  async createUser(userData: Omit<AppUser, 'id'>): Promise<AppUser> {
    const res = await fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to create user');
    return data.user;
  },

  async updateUser(id: string, updates: Partial<AppUser>): Promise<AppUser> {
    const res = await fetch(`/api/users/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update user');
    return data.user;
  },

  async deleteUser(id: string): Promise<void> {
    const res = await fetch(`/api/users/${id}`, {
      method: 'DELETE',
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete user');
  },

  async getRoles(): Promise<{ roles: RoleDefinition[]; permissions: PermissionItem[] }> {
    const res = await fetch('/api/roles');
    if (!res.ok) throw new Error('Failed to load roles and permissions');
    return res.json();
  },

  // Dashboard Stats
  async getDashboardStats(): Promise<DashboardStats> {
    const res = await fetch('/api/dashboard/stats');
    if (!res.ok) throw new Error('Failed to load dashboard statistics');
    return res.json();
  },

  // Mogadishu Districts
  async getDistricts(): Promise<District[]> {
    const res = await fetch('/api/districts');
    const data = await res.json();
    return data.districts;
  },

  async createDistrict(district: Omit<District, 'id' | 'subDistrictsCount' | 'zonesCount' | 'propertiesCount'>): Promise<District> {
    const res = await fetch('/api/districts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(district),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to create district');
    return data.district;
  },

  // Mogadishu Sub-Districts (Waaxyaha)
  async getSubDistricts(districtId?: string): Promise<SubDistrict[]> {
    const query = districtId && districtId !== 'all' ? `?districtId=${districtId}` : '';
    const res = await fetch(`/api/sub-districts${query}`);
    const data = await res.json();
    return data.subDistricts;
  },

  async createSubDistrict(subDistrict: Omit<SubDistrict, 'id' | 'zonesCount'>): Promise<SubDistrict> {
    const res = await fetch('/api/sub-districts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(subDistrict),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to create sub-district');
    return data.subDistrict;
  },

  async deleteSubDistrict(id: string): Promise<void> {
    const res = await fetch(`/api/sub-districts/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete sub-district');
  },

  // Zones
  async getZones(params?: { districtId?: string; subDistrictId?: string }): Promise<Zone[]> {
    const query = new URLSearchParams();
    if (params?.districtId && params.districtId !== 'all') query.set('districtId', params.districtId);
    if (params?.subDistrictId && params.subDistrictId !== 'all') query.set('subDistrictId', params.subDistrictId);
    const res = await fetch(`/api/zones?${query.toString()}`);
    const data = await res.json();
    return data.zones;
  },

  async createZone(zone: Omit<Zone, 'id' | 'propertyCount'>): Promise<Zone> {
    const res = await fetch('/api/zones', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(zone),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to create zone');
    return data.zone;
  },

  async deleteZone(id: string): Promise<void> {
    const res = await fetch(`/api/zones/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete zone');
  },

  // Properties
  async getProperties(params?: {
    districtId?: string;
    subDistrictId?: string;
    zoneId?: string;
    type?: string;
    status?: string;
    search?: string;
  }): Promise<Property[]> {
    const query = new URLSearchParams();
    if (params?.districtId && params.districtId !== 'all') query.set('districtId', params.districtId);
    if (params?.subDistrictId && params.subDistrictId !== 'all') query.set('subDistrictId', params.subDistrictId);
    if (params?.zoneId && params.zoneId !== 'all') query.set('zoneId', params.zoneId);
    if (params?.type && params.type !== 'all') query.set('type', params.type);
    if (params?.status && params.status !== 'all') query.set('status', params.status);
    if (params?.search) query.set('search', params.search);

    const res = await fetch(`/api/properties?${query.toString()}`);
    const data = await res.json();
    return data.properties;
  },

  async createProperty(property: Omit<Property, 'id' | 'registeredAt'>): Promise<Property> {
    const res = await fetch('/api/properties', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(property),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to create property');
    return data.property;
  },

  async updateProperty(id: string, updates: Partial<Property>): Promise<Property> {
    const res = await fetch(`/api/properties/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update property');
    return data.property;
  },

  async deleteProperty(id: string): Promise<void> {
    const res = await fetch(`/api/properties/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete property');
  },

  // Fees
  async getFees(): Promise<FeeRate[]> {
    const res = await fetch('/api/fees');
    const data = await res.json();
    return data.feeRates;
  },

  async proposeFee(payload: {
    propertyType: 'residential' | 'commercial';
    monthlyFee: number;
    effectiveDate: string;
    notes: string;
  }): Promise<FeeRate> {
    const res = await fetch('/api/fees/propose', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to propose fee rate');
    return data.feeRate;
  },

  async approveFee(id: string): Promise<FeeRate> {
    const res = await fetch(`/api/fees/${id}/approve`, { method: 'POST' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to approve fee');
    return data.feeRate;
  },

  // Invoices & Billing
  async getInvoices(params?: {
    month?: string;
    districtId?: string;
    zoneId?: string;
    status?: string;
    search?: string;
  }): Promise<Invoice[]> {
    const query = new URLSearchParams();
    if (params?.month) query.set('month', params.month);
    if (params?.districtId && params.districtId !== 'all') query.set('districtId', params.districtId);
    if (params?.zoneId && params.zoneId !== 'all') query.set('zoneId', params.zoneId);
    if (params?.status && params.status !== 'all') query.set('status', params.status);
    if (params?.search) query.set('search', params.search);

    const res = await fetch(`/api/invoices?${query.toString()}`);
    const data = await res.json();
    return data.invoices;
  },

  async generateBatchBilling(
    billingMonth: string,
    zoneId?: string,
    districtId?: string
  ): Promise<{ generatedCount: number; skippedDuplicates: number; invoices: Invoice[] }> {
    const res = await fetch('/api/invoices/generate-batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ billingMonth, zoneId, districtId }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to generate billing cycle');
    return data;
  },

  async createSingleInvoice(propertyId: string, billingMonth: string): Promise<Invoice> {
    const res = await fetch('/api/invoices/single', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ propertyId, billingMonth }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to generate invoice');
    return data.invoice;
  },

  // Payments & Receipts
  async getPayments(params?: {
    method?: string;
    verificationStatus?: string;
    search?: string;
  }): Promise<Payment[]> {
    const query = new URLSearchParams();
    if (params?.method) query.set('method', params.method);
    if (params?.verificationStatus) query.set('verificationStatus', params.verificationStatus);
    if (params?.search) query.set('search', params.search);

    const res = await fetch(`/api/payments?${query.toString()}`);
    const data = await res.json();
    return data.payments;
  },

  async recordPayment(payload: {
    invoiceId: string;
    amount: number;
    paymentMethod: 'cash' | 'digital';
    digitalReference?: string;
    digitalProvider?: string;
    notes?: string;
  }): Promise<{ payment: Payment; invoice: Invoice }> {
    const res = await fetch('/api/payments/record', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to record payment');
    return data;
  },

  async verifyPayment(
    id: string,
    action: 'approve' | 'reject',
    notes?: string
  ): Promise<{ payment: Payment; invoice: Invoice }> {
    const res = await fetch(`/api/payments/${id}/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, notes }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update payment status');
    return data;
  },

  async reversePayment(
    id: string,
    reason: string
  ): Promise<{ payment: Payment; invoice: Invoice }> {
    const res = await fetch(`/api/payments/${id}/reverse`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to reverse payment');
    return data;
  },

  // Operations
  async getOperationsData(): Promise<{
    trucks: Truck[];
    routes: Route[];
    schedules: CollectionSchedule[];
    records: CollectionRecord[];
    complaints: CustomerComplaint[];
  }> {
    const res = await fetch('/api/operations/all');
    return res.json();
  },

  async createTruck(truck: Omit<Truck, 'id'>): Promise<Truck> {
    const res = await fetch('/api/operations/trucks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(truck),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add truck');
    return data.truck;
  },

  async updateTruck(id: string, updates: Partial<Truck>): Promise<Truck> {
    const res = await fetch(`/api/operations/trucks/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(updates) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Failed to update truck'); return data.truck;
  },
  async deleteTruck(id: string): Promise<void> {
    const res = await fetch(`/api/operations/trucks/${id}`, { method: 'DELETE' }); const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Failed to delete truck');
  },
  async createRoute(route: Omit<Route, 'id'>): Promise<Route> {
    const res = await fetch('/api/operations/routes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(route),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add route');
    return data.route;
  },

  async updateRoute(id: string, updates: Partial<Route>): Promise<Route> {
    const res = await fetch(`/api/operations/routes/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(updates) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Failed to update route'); return data.route;
  },
  async deleteRoute(id: string): Promise<void> {
    const res = await fetch(`/api/operations/routes/${id}`, { method: 'DELETE' }); const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Failed to delete route');
  },
  async updateScheduleStatus(id: string, status: CollectionSchedule['status']): Promise<CollectionSchedule> {
    const res = await fetch(`/api/operations/schedules/${id}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Failed to update schedule status'); return data.schedule;
  },
  async deleteSchedule(id: string): Promise<void> {
    const res = await fetch(`/api/operations/schedules/${id}`, { method: 'DELETE' }); const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Failed to delete schedule');
  },
  async updateCollectionRecordStatus(id: string, status: CollectionRecord['status']): Promise<CollectionRecord> {
    const res = await fetch(`/api/operations/records/${id}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Failed to update collection status'); return data.record;
  },
  async deleteCollectionRecord(id: string): Promise<void> {
    const res = await fetch(`/api/operations/records/${id}`, { method: 'DELETE' }); const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Failed to delete collection log');
  },
  async createSchedule(
    schedule: Omit<CollectionSchedule, 'id' | 'stopsCompleted'>
  ): Promise<CollectionSchedule> {
    const res = await fetch('/api/operations/schedules', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(schedule),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to create schedule');
    return data.schedule;
  },

  async logCollectionRecord(record: {
    scheduleId: string;
    propertyId: string;
    status: 'collected' | 'missed';
    missedReason?: string;
    notes?: string;
    wasteWeightKg?: number;
  }): Promise<CollectionRecord> {
    const res = await fetch('/api/operations/records', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to record collection log');
    return data.record;
  },

  async createComplaint(complaint: {
    propertyId: string;
    complainantName: string;
    phone: string;
    category: CustomerComplaint['category'];
    description: string;
    priority: CustomerComplaint['priority'];
  }): Promise<CustomerComplaint> {
    const res = await fetch('/api/operations/complaints', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(complaint),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to register complaint');
    return data.complaint;
  },

  async updateComplaintStatus(id: string, status: CustomerComplaint['status']): Promise<CustomerComplaint> {
    const res = await fetch(`/api/operations/complaints/${id}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Failed to update complaint status'); return data.complaint;
  },
  async deleteComplaint(id: string): Promise<void> {
    const res = await fetch(`/api/operations/complaints/${id}`, { method: 'DELETE' }); const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Failed to delete complaint');
  },
  async resolveComplaint(id: string, resolutionNotes: string): Promise<CustomerComplaint> {
    const res = await fetch(`/api/operations/complaints/${id}/resolve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resolutionNotes }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to resolve complaint');
    return data.complaint;
  },

  // Audit Logs
  async getAuditLogs(): Promise<AuditLog[]> {
    const res = await fetch('/api/audit-logs');
    const data = await res.json();
    return data.logs;
  },

  // Test Suite
  async runSystemTests(): Promise<{
    suite: string;
    executedAt: string;
    results: Array<{ name: string; description: string; passed: boolean; details: string }>;
    allPassed: boolean;
  }> {
    const res = await fetch('/api/system/tests');
    return res.json();
  },
};
