export type UserRole =
  | 'admin'
  | 'finance_officer'
  | 'cashier'
  | 'collection_manager'
  | 'field_collector';

export type UserStatus = 'active' | 'suspended';

export interface AppUser {
  id: string;
  username: string;
  fullName: string;
  role: UserRole;
  email: string;
  phone?: string;
  department: string;
  status?: UserStatus;
  assignedDistrictId?: string;
  assignedZoneId?: string;
  createdAt?: string;
  lastLoginAt?: string;
}

export interface RoleDefinition {
  role: UserRole;
  title: string;
  department: string;
  description: string;
  badgeColor: string;
  scopeSummary: string;
  level: number;
  responsibilities: string[];
  restrictedActions: string[];
}

export interface PermissionItem {
  id: string;
  name: string;
  description: string;
  category: string;
  allowedRoles: UserRole[];
}

export type PropertyType = 'residential' | 'commercial';
export type ServiceStatus = 'active' | 'suspended' | 'inactive';

export interface District {
  id: string;
  code: string;
  name: string;
  somaliName: string;
  description: string;
  subDistrictsCount?: number;
  zonesCount?: number;
  propertiesCount?: number;
}

export interface SubDistrict {
  id: string;
  districtId: string;
  code: string;
  name: string;
  somaliName: string;
  description: string;
  zonesCount?: number;
}

export interface Zone {
  id: string;
  code: string;
  name: string;
  districtId: string;
  districtName?: string;
  subDistrictId: string;
  subDistrictName?: string;
  description: string;
  coverageArea: string;
  active: boolean;
  propertyCount?: number;
}

export interface Property {
  id: string;
  propertyNumber: string;
  ownerName: string;
  occupantName: string;
  phone: string;
  address: string;
  districtId: string;
  districtName?: string;
  subDistrictId: string;
  subDistrictName?: string;
  zoneId: string;
  zoneCode?: string;
  propertyType: PropertyType;
  serviceStatus: ServiceStatus;
  registeredAt: string;
  notes?: string;
  totalBilled?: number;
  totalPaid?: number;
  currentBalance?: number;
}

export type FeeStatus = 'draft' | 'pending_approval' | 'approved' | 'superseded';

export interface FeeRate {
  id: string;
  propertyType: PropertyType;
  monthlyFee: number;
  currency: string;
  effectiveDate: string;
  status: FeeStatus;
  proposedBy: string;
  approvedBy?: string;
  approvedAt?: string;
  notes: string;
}

export type InvoiceStatus = 'unpaid' | 'partially_paid' | 'paid' | 'overdue';

export interface Invoice {
  id: string;
  invoiceNumber: string;
  propertyId: string;
  propertyNumber: string;
  ownerName: string;
  districtId?: string;
  districtName?: string;
  subDistrictId?: string;
  subDistrictName?: string;
  zoneId: string;
  zoneCode?: string;
  propertyType: PropertyType;
  billingMonth: string; // YYYY-MM
  rateApplied: number;
  amountDue: number;
  amountPaid: number;
  balanceDue: number;
  status: InvoiceStatus;
  dueDate: string;
  createdAt: string;
  createdBy: string;
}

export type PaymentMethod = 'cash' | 'digital';
export type VerificationStatus = 'pending' | 'confirmed' | 'rejected';

export interface Payment {
  id: string;
  receiptNumber: string;
  invoiceId: string;
  invoiceNumber: string;
  propertyId: string;
  propertyNumber: string;
  ownerName: string;
  amount: number;
  paymentMethod: PaymentMethod;
  digitalReference?: string;
  digitalProvider?: string;
  verificationStatus: VerificationStatus;
  recordedBy: string;
  recordedByName: string;
  recordedAt: string;
  verifiedBy?: string;
  verifiedByName?: string;
  verifiedAt?: string;
  verificationNotes?: string;
  isReversed?: boolean;
  reversalReason?: string;
  reversedAt?: string;
  reversedBy?: string;
  reversedByName?: string;
}

export interface Truck {
  id: string;
  plateNumber: string;
  model: string;
  capacityTons: number;
  status: 'active' | 'maintenance' | 'deputed';
  assignedZoneId?: string;
  driverName?: string;
}

export interface Route {
  id: string;
  name: string;
  zoneId: string;
  startPoint: string;
  endPoint: string;
  estimatedStops: number;
  frequency: string;
  status?: 'active' | 'inactive';
}

export interface CollectionSchedule {
  id: string;
  date: string;
  zoneId: string;
  zoneName: string;
  routeId: string;
  routeName: string;
  truckId: string;
  truckPlate: string;
  collectorId: string;
  collectorName: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'delayed';
  stopsCompleted: number;
  totalStops: number;
  notes?: string;
}

export interface CollectionRecord {
  id: string;
  scheduleId: string;
  propertyId: string;
  propertyNumber: string;
  address: string;
  status: 'collected' | 'missed';
  missedReason?: string;
  notes?: string;
  recordedAt: string;
  recordedBy: string;
  wasteWeightKg?: number;
}

export interface CustomerComplaint {
  id: string;
  complaintNumber: string;
  propertyId: string;
  propertyNumber: string;
  complainantName: string;
  phone: string;
  category: 'missed_collection' | 'damaged_bin' | 'illegal_dumping' | 'staff_conduct' | 'billing_query' | 'other';
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in_progress' | 'resolved';
  resolutionNotes?: string;
  createdAt: string;
  resolvedAt?: string;
  resolvedBy?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
}

export interface DistrictStat {
  districtId: string;
  districtName: string;
  somaliName: string;
  subDistrictsCount: number;
  zonesCount: number;
  propertyCount: number;
  billed: number;
  collected: number;
  outstanding: number;
}

export interface DashboardStats {
  totalProperties: number;
  residentialCount: number;
  commercialCount: number;
  monthlyBilledTotal: number;
  confirmedRevenue: number;
  outstandingBalance: number;
  pendingDigitalCount: number;
  pendingDigitalAmount: number;
  collectionRatePercent: number;
  openComplaintsCount: number;
  zoneStats: Array<{
    zoneId: string;
    zoneName: string;
    districtName?: string;
    propertyCount: number;
    billed: number;
    collected: number;
    outstanding: number;
  }>;
  districtStats: DistrictStat[];
  arrearsAging: {
    current: number;
    days30: number;
    days60: number;
    days90Plus: number;
  };
  revenueByMethod: {
    cash: number;
    digitalConfirmed: number;
    digitalPending: number;
  };
}
