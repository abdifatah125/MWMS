# MWMS local MySQL + secure login setup

## Important storage note
This version stores the full MWMS application dataset as a JSON document in a MySQL 8 table named `mwms_app_state` (InnoDB/utf8mb4). It does **not** use the old PostgreSQL-specific migration. The original `data/mwms_data.json` remains as a local recovery/bootstrap copy. Keep regular backups of both MySQL and the JSON file.

## 1. Create a local MySQL database and least-privilege account
Run in MySQL as an administrator (choose your own strong password):

```sql
CREATE DATABASE mwms_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'mwms_admin'@'localhost' IDENTIFIED BY 'REPLACE_WITH_A_STRONG_PASSWORD';
GRANT SELECT, INSERT, UPDATE, CREATE ON mwms_db.* TO 'mwms_admin'@'localhost';
FLUSH PRIVILEGES;
```

## 2. Configure environment
Copy `.env.example` to `.env` and set `DB_PASSWORD` and a unique `JWT_SECRET` of at least 32 random characters. Never share or commit `.env`.

## 3. Install dependencies
On Windows PowerShell, use `npm.cmd` (avoids the `npm.ps1` execution-policy issue):

```powershell
npm.cmd install
```

## 4. Initialize passwords for existing staff
The source dataset intentionally has no passwords. You must assign each account a separate password; no default/shared password is created. Run:

```powershell
npm.cmd run init-passwords
```

The script prompts for a minimum 12-character password and confirmation for each original user. Hashes use bcrypt cost 12 and are stored in `data/auth_credentials.json`; protect that file and back it up securely. Existing names/usernames/roles are preserved.

## 5. Start MWMS
```powershell
npm.cmd run dev
```
Open `http://localhost:3000`. Sign in with one of the original usernames and the password you assigned in step 4. Each user has their own signed, expiring JWT in an HttpOnly cookie. The old persona/role switcher has been removed. API routes require a valid session; sign out clears the cookie.

## 6. Data migration
On first startup, if the MySQL state table is empty, MWMS seeds it from `data/mwms_data.json`. If it already contains a snapshot, that MySQL copy is loaded. The separate migration command refuses to overwrite an existing snapshot:

```powershell
npm.cmd run migrate-mysql
```

Before using production data, verify a backup/restore procedure and test with a copy. For production, use HTTPS so the session cookie is Secure, and configure `NODE_ENV=production`.
